package app.sharkwrt.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.sharkwrt.ui.theme.Wrt

// Orbit glass: a lavender-tinted translucent fill over the purple backdrop, a soft top sheen
// with a faint accent glow at the far corner, and a hairline rim brighter at the top-left.

fun Modifier.glassBg(shape: Shape, fill: Color = Wrt.BgCard): Modifier =
    this
        .background(fill, shape)
        .background(
            Brush.linearGradient(listOf(Wrt.GlassSheen, Wrt.GlassSheen.copy(alpha = 0f), Wrt.Accent.copy(alpha = 0.05f))),
            shape,
        )

fun Modifier.glassBorder(shape: Shape, width: Dp = 1.dp): Modifier =
    this.border(
        width,
        Brush.linearGradient(listOf(Wrt.GlassEdgeHi, Wrt.GlassEdgeLo, Wrt.GlassEdgeHi.copy(alpha = Wrt.GlassEdgeHi.alpha * 0.4f))),
        shape,
    )

fun Modifier.glassPanel(shape: Shape, fill: Color = Wrt.BgCard): Modifier =
    this.glassBorder(shape).glassBg(shape, fill)

/** A full-width bar: translucent fill and a sheen, no corners. */
fun Modifier.glassBar(): Modifier =
    this
        .background(Wrt.BgBar)
        .background(Brush.verticalGradient(listOf(Wrt.GlassSheen, Wrt.GlassSheen.copy(alpha = 0f))))
