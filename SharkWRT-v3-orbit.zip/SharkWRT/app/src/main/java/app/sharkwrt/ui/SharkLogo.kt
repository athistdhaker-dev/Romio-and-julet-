package app.sharkwrt.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.sharkwrt.ui.theme.DisplayFamily
import app.sharkwrt.ui.theme.Wrt

private val Cyan = Color(0xFF35E0FF)
private val Violet = Color(0xFFFF4FD8)

/** The SharkWRT mark: a fin cutting through sonar waves, on a dark glass tile. */
@Composable
fun SharkMark(size: Dp = 44.dp, tile: Boolean = true) {
    Canvas(Modifier.size(size)) { drawShark(tile) }
}

private fun DrawScope.drawShark(tile: Boolean) {
    val w = this.size.width
    val h = this.size.height
    fun p(x: Float, y: Float) = Offset(x * w, y * h)
    if (tile) {
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFF2A0F5C), Color(0xFF0E0422))),
            cornerRadius = CornerRadius(w * 0.28f),
        )
        drawRoundRect(
            Brush.linearGradient(listOf(Cyan.copy(alpha = 0.9f), Cyan.copy(alpha = 0.05f), Violet.copy(alpha = 0.7f))),
            cornerRadius = CornerRadius(w * 0.28f), style = Stroke(w * 0.025f),
        )
    }
    drawCircle(Cyan.copy(alpha = 0.18f), radius = w * 0.40f, center = p(.5f, .5f), style = Stroke(w * 0.012f))
    val fin = Path().apply {
        moveTo(.18f * w, .66f * h)
        cubicTo(.34f * w, .60f * h, .44f * w, .36f * h, .52f * w, .12f * h)
        cubicTo(.56f * w, .30f * h, .70f * w, .52f * h, .84f * w, .66f * h)
        close()
    }
    drawPath(fin, Cyan.copy(alpha = 0.30f), style = Stroke(w * 0.06f, join = StrokeJoin.Round))
    drawPath(fin, Brush.linearGradient(listOf(Cyan, Violet), start = p(.3f, .2f), end = p(.8f, .7f)))
    fun wave(y: Float, a: Float, x0: Float, x1: Float, alpha: Float) {
        val path = Path().apply {
            moveTo(x0 * w, y * h)
            val seg = (x1 - x0) / 4f
            for (i in 0 until 4) {
                val xs = x0 + seg * i
                cubicTo((xs + seg * .35f) * w, (y - a) * h, (xs + seg * .65f) * w, (y + a) * h, (xs + seg) * w, y * h)
            }
        }
        drawPath(path, Cyan.copy(alpha = alpha), style = Stroke(w * 0.028f, cap = StrokeCap.Round))
    }
    wave(.76f, .05f, .10f, .90f, 1f)
    wave(.88f, .04f, .22f, .76f, .55f)
}

/** "SHARK" in white, "WRT" in the accent, in the display face. */
@Composable
fun SharkWordmark(size: Float = 18f) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("SHARK", style = TextStyle(fontFamily = DisplayFamily, fontWeight = FontWeight.Bold, fontSize = size.sp, color = Wrt.TextPrimary, letterSpacing = 2.sp))
        Text("WRT", style = TextStyle(fontFamily = DisplayFamily, fontWeight = FontWeight.Bold, fontSize = size.sp, color = Wrt.Accent, letterSpacing = 2.sp))
    }
}
