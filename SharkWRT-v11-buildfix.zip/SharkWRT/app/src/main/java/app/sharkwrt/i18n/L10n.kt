package app.sharkwrt.i18n

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** The Indian languages the interface can be shown in. The code `en` means the strings as written. */
enum class AppLang(val code: String, val native: String) {
    En("en", "English"), Hi("hi", "हिन्दी"), Bn("bn", "বাংলা"), Mr("mr", "मराठी"), Ta("ta", "தமிழ்"),
    Te("te", "తెలుగు"), Gu("gu", "ગુજરાતી"), Kn("kn", "ಕನ್ನಡ"), Ml("ml", "മലയാളം"), Pa("pa", "ਪੰਜਾਬੀ"),
    Or("or", "ଓଡ଼ିଆ"), Ur("ur", "اردو"), As("as", "অসমীয়া"),
    Ne("ne", "नेपाली"), Kok("kok", "कोंकणी"), Mai("mai", "मैथिली"), Doi("doi", "डोगरी"), Brx("brx", "बर'"),
    Sa("sa", "संस्कृतम्"), Sd("sd", "سنڌي"), Ks("ks", "کٲشُر"), Sat("sat", "ᱥᱟᱱᱛᱟᱲᱤ"), Mni("mni", "ꯃꯤꯇꯩꯂꯣꯟ"),
    Hg("hg", "Hinglish");

    companion object { fun byCode(c: String?) = entries.firstOrNull { it.code == c } ?: En }
}

/**
 * Looks a string up in [TABLE] for the chosen language. [lang] is Compose state, so every `Text`
 * that calls [tr] repaints when the language changes. Anything not in the table stays English.
 */
object L10n {
    private const val PREFS = "sharkwrt_lang"
    var lang: AppLang by mutableStateOf(AppLang.En)
        private set

    /** english (lowercase) -> language code -> translation, from both tables. */
    private val index: Map<String, Map<String, String>> by lazy {
        val map = HashMap<String, MutableMap<String, String>>()
        fun feed(table: String, order: String) {
            val cols = order.split(',')
            table.lineSequence().filter { it.isNotBlank() }.forEach { line ->
                val p = line.split('|')
                if (p.size < 2) return@forEach
                val row = map.getOrPut(p[0].trim().lowercase()) { HashMap() }
                for (i in 1 until p.size) {
                    val code = cols.getOrNull(i - 1) ?: break
                    if (p[i].isNotBlank()) row[code] = p[i].trim()
                }
            }
        }
        feed(TABLE, TABLE_ORDER)
        feed(TABLE2, TABLE2_ORDER)
        map
    }

    fun load(context: Context) {
        val code = runCatching { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lang", null) }.getOrNull()
        lang = AppLang.byCode(code)
    }

    fun set(context: Context, value: AppLang) {
        lang = value
        runCatching { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lang", value.code).apply() }
    }

    fun tr(text: String): String {
        val l = lang
        if (l == AppLang.En || text.isEmpty()) return text
        val t = index[text.trim().lowercase()]?.get(l.code) ?: return text
        val lead = text.takeWhile { it.isWhitespace() }
        val tail = text.takeLastWhile { it.isWhitespace() }
        return lead + t + tail
    }
}
