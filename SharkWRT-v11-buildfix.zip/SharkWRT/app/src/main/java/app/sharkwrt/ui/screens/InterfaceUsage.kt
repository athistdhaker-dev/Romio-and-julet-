package app.sharkwrt.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import app.sharkwrt.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.sharkwrt.data.RouterOps
import app.sharkwrt.data.Telemetry
import app.sharkwrt.data.UsageState
import app.sharkwrt.ops.NetCounters
import app.sharkwrt.ops.NetUsage
import app.sharkwrt.ui.GhostButton
import app.sharkwrt.ui.SectionLabel
import app.sharkwrt.ui.glassBorder
import app.sharkwrt.ui.mono
import app.sharkwrt.ui.sans
import app.sharkwrt.ui.theme.Wrt
import kotlinx.coroutines.delay

/**
 * Data usage for any interface the router has — wan, wan6, lan, guest, iot, wwan… Pick one at
 * the top: it shows the live rate and the since-boot counters from /proc/net/dev, and the
 * saved daily/monthly history from vnstat (which this starts counting for that device if it
 * was not already).
 */
@Composable
fun InterfaceUsageDialog(ops: RouterOps, onDismiss: () -> Unit) {
    var ifaces by remember { mutableStateOf<List<NetUsage.IfaceInfo>?>(null) }
    var selected by remember { mutableStateOf<String?>(null) }
    var counters by remember { mutableStateOf<Map<String, NetCounters>>(emptyMap()) }
    var rate by remember { mutableStateOf(0f to 0f) }
    var history by remember { mutableStateOf<UsageState>(UsageState.Loading) }

    LaunchedEffect(ops) {
        val list = ops.interfaces()
        ifaces = list
        selected = (list.firstOrNull { it.name == "wan" } ?: list.firstOrNull())?.name
    }
    val current = ifaces?.firstOrNull { it.name == selected }

    // Live counters every 2 s; the rate is the difference between two reads of the same device.
    LaunchedEffect(ops, current?.device) {
        val dev = current?.device ?: return@LaunchedEffect
        rate = 0f to 0f
        var prev: NetCounters? = null
        var prevAt = 0L
        while (true) {
            val all = ops.netCounters()
            counters = all
            val now = all[dev]
            val at = System.nanoTime()
            val p = prev
            if (now != null && p != null && at > prevAt) {
                val dt = (at - prevAt) / 1e9
                val down = ((now.rxBytes - p.rxBytes).coerceAtLeast(0) * 8 / 1e6 / dt).toFloat()
                val up = ((now.txBytes - p.txBytes).coerceAtLeast(0) * 8 / 1e6 / dt).toFloat()
                rate = down to up
            }
            prev = now; prevAt = at
            delay(2_000)
        }
    }
    LaunchedEffect(ops, current?.device) {
        val dev = current?.device ?: return@LaunchedEffect
        history = UsageState.Loading
        while (true) {
            history = ops.usageFor(dev)
            delay(60_000)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .glassBorder(RoundedCornerShape(Wrt.r(16f)))
                .background(Wrt.BgDialog, RoundedCornerShape(Wrt.r(16f)))
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("Usage by interface", style = sans(15f, 650))
            val list = ifaces
            when {
                list == null -> Text("Reading interfaces…", style = sans(12f, 400, Wrt.TextDim), modifier = Modifier.padding(top = 10.dp))
                list.isEmpty() -> Text("The router listed no interfaces.", style = sans(12f, 400, Wrt.TextDim), modifier = Modifier.padding(top = 10.dp))
                else -> {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 12.dp).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        list.forEach { i ->
                            val on = i.name == selected
                            Text(
                                i.name,
                                style = mono(11.5f, 600, if (on) Wrt.Accent else Wrt.TextSecondary),
                                modifier = Modifier
                                    .border(1.dp, if (on) Wrt.Accent else Wrt.BorderCard, RoundedCornerShape(Wrt.r(9f)))
                                    .clickable { selected = i.name }
                                    .padding(horizontal = 12.dp, vertical = 7.dp),
                            )
                        }
                    }
                    current?.let { i ->
                        Text(
                            "${i.device}${if (i.proto.isNotBlank()) " · ${i.proto}" else ""} · ${if (i.up) "up" else "down"}",
                            style = mono(10f, 500, Wrt.TextDim),
                            modifier = Modifier.padding(top = 8.dp),
                        )
                        val c = counters[i.device]
                        SectionLabel("LIVE", size = 9.5f, modifier = Modifier.padding(top = 14.dp))
                        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                            val (d, du) = speedParts(rate.first)
                            val (u, uu) = speedParts(rate.second)
                            Text("↓ $d $du", style = mono(15f, 600, Wrt.Accent))
                            Text("↑ $u $uu", style = mono(15f, 600, Wrt.Blue))
                        }
                        Text(
                            if (c != null) "since boot · ↓ ${Telemetry.bytesLabel(c.rxBytes)} · ↑ ${Telemetry.bytesLabel(c.txBytes)}"
                            else "No counters for ${i.device}.",
                            style = mono(10.5f, 500, Wrt.TextSecondary),
                            modifier = Modifier.padding(top = 6.dp),
                        )
                        Spacer(Modifier.height(14.dp))
                        SectionLabel("HISTORY", size = 9.5f)
                        Spacer(Modifier.height(4.dp))
                        when (val h = history) {
                            UsageState.Loading -> Text("Reading history…", style = sans(11.5f, 400, Wrt.TextDim))
                            UsageState.NotInstalled, UsageState.NoVnstat -> Text(
                                "History needs vnstat. Use “Keep usage across reboots” on the dashboard card to install it, then pick this interface again.",
                                style = sans(11.5f, 400, Wrt.TextDim, lineHeight = 17.sp),
                            )
                            is UsageState.Failed -> Text(
                                h.message + " (A newly tracked interface needs a few minutes before vnstat has data.)",
                                style = sans(11.5f, 400, Wrt.TextDim, lineHeight = 17.sp),
                            )
                            is UsageState.Ready -> UsageHistory(h.summary, null)
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            GhostButton("Close", onClick = onDismiss)
        }
    }
}
