package app.sharkwrt.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** How the five tabs are reached. */
enum class NavKind { Dock, PillBar, Rail, Radial, Drawer, Neo, Top, Boxed, Index, Pad }

/** How a card is built: glass, glass with glowing corners, flat outlined, or hard-shadowed. */
enum class Surface { Glass, Brackets, Flat, Brutal, Neo, Dashed, Rule, Pixel }

/** Soft surfaces get gradient fills and white-on-accent chips; heavy ones get thick borders and a hard shadow. */
val Surface.soft: Boolean get() = this == Surface.Glass || this == Surface.Brackets || this == Surface.Neo
val Surface.heavy: Boolean get() = this == Surface.Brutal || this == Surface.Pixel

/** What is painted behind everything. */
enum class Backdrop { Grid, Pastel, Scan, Blooms, Flat, Ember, Blue }

/**
 * The five complete looks. A style decides the palette, the fonts, how round things are, how
 * cards are made, how you move between tabs and how the home screen's speed card is drawn.
 * Light / dark mode and the accent colour sit on top of it.
 */
enum class UiStyle(
    val id: String,
    val label: String,
    val blurb: String,
    val nav: NavKind,
    val surface: Surface,
    val backdrop: Backdrop,
    /** Multiplies every corner radius in the app. 0 is square. */
    val radius: Float,
    val ring: Boolean,
    val round: Boolean,
    val defaultAccent: String,
    val labelPrefix: String,
    val defaultDark: Boolean,
) {
    Abyss("abyss", "Abyss HUD", "Neon sci-fi glass, floating dock", NavKind.Dock, Surface.Brackets, Backdrop.Grid, 0.8f, false, false, "cyan", "", true),
    Aurora("aurora", "Aurora Glass", "Light liquid glass, pill tab bar", NavKind.PillBar, Surface.Glass, Backdrop.Pastel, 1.1f, false, true, "violet", "", false),
    Deck("deck", "Command Deck", "Terminal look, side rail", NavKind.Rail, Surface.Flat, Backdrop.Scan, 0f, false, false, "solar", "┤ ", true),
    Orbit("orbit", "Orbit", "Radial menu, ring gauge", NavKind.Radial, Surface.Glass, Backdrop.Blooms, 1f, true, true, "orbit", "", true),
    Paper("paper", "Bold Paper", "Hard shadows, drawer menu", NavKind.Drawer, Surface.Brutal, Backdrop.Flat, 0f, false, false, "rose", "", false),
    Glacier("glacier", "Glacier", "Soft neumorphic, raised bar", NavKind.Neo, Surface.Neo, Backdrop.Flat, 1.2f, false, true, "azure", "", false),
    Ember("ember", "Ember", "Warm dark, top tab strip", NavKind.Top, Surface.Flat, Backdrop.Ember, 1f, false, false, "ember", "", true),
    Blueprint("blueprint", "Blueprint", "Dashed blueprint, boxed tabs", NavKind.Boxed, Surface.Dashed, Backdrop.Blue, 0f, false, false, "chalk", "// ", true),
    Swiss("swiss", "Swiss", "Editorial minimal, index nav", NavKind.Index, Surface.Rule, Backdrop.Flat, 0f, false, false, "signal", "", false),
    Arcade("arcade", "Arcade", "Pixel retro, controller pad", NavKind.Pad, Surface.Pixel, Backdrop.Scan, 0f, false, false, "arcade", "▶ ", true);

    companion object {
        fun byId(id: String?): UiStyle = entries.firstOrNull { it.id == id } ?: Orbit
    }

    val sansFamily: FontFamily
        get() = when (this) {
            Abyss -> AbyssSans
            Aurora -> AuroraSans
            Deck -> DeckMono
            Orbit, Paper -> GroteskSans
            Glacier -> DmSans
            Ember -> OutfitSans
            Blueprint -> PlexMono
            Swiss -> InterTight
            Arcade -> Vt323
        }
    val displayFamily: FontFamily
        get() = when (this) {
            Abyss -> AbyssDisplay
            Aurora -> AuroraDisplay
            Deck -> DeckMono
            Orbit -> SoraDisplay
            Paper -> ArchivoDisplay
            Glacier -> DmSans
            Ember -> OutfitSans
            Blueprint -> PlexMono
            Swiss -> InterTight
            Arcade -> PressStart
        }
    val monoFamily: FontFamily get() = when (this) { Deck -> DeckMono; Blueprint -> PlexMono; Arcade -> Vt323; else -> MonoFamily }

    /** Rajdhani and JetBrains Mono run small next to the others. */
    val sansScale: Float get() = when (this) { Abyss -> 1.1f; Deck -> 0.94f; Blueprint -> 0.92f; Arcade -> 1.3f; else -> 1f }

    /** Press Start 2P is very wide, so headings in the Arcade look are set smaller. */
    val displayScale: Float get() = when (this) { Arcade -> 0.55f; Blueprint -> 0.9f; Swiss -> 1.05f; else -> 1f }
}

/** The current style's helpers, read like the colours: they follow the user's choice. */
val WrtStyle: UiStyle get() = ThemeStore.style

fun WrtR(n: Float): Dp = (n * ThemeStore.style.radius).dp
fun WrtPill(): Shape = if (ThemeStore.style.radius <= 0f) RectangleShape else RoundedCornerShape(50)
fun WrtIconShape(): Shape = when {
    ThemeStore.style.round -> CircleShape
    ThemeStore.style.radius > 0f -> RoundedCornerShape((12 * ThemeStore.style.radius).dp)
    else -> RectangleShape
}
