package app.sharkwrt.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/**
 * Every colour the UI paints with, for one theme.
 *
 * The screens never read this directly: they read [Wrt], whose properties forward to the
 * palette that is current. [Wrt.palette] is Compose state, so switching theme repaints whatever
 * read a colour, with no screen having to be told.
 *
 * All themes are "liquid glass": the surfaces are translucent whites (or inks, on the light
 * theme) laid over the aurora backdrop that [SharkWrtTheme] paints, so what shows through a card
 * is the theme's own colour. The solid `bgSolid`, `bgSheet` and `bgDialog` exist for the few
 * places that must not show what is behind them.
 */
@Immutable
class WrtPalette(
    val id: String,
    val label: String,
    val isLight: Boolean,
    val auroraTop: Color,
    val auroraBottom: Color,
    val blobA: Color,
    val blobB: Color,
    val blobC: Color,
    val bgScreen: Color,
    val bgSolid: Color,
    val bgBar: Color,
    val bgDeep: Color,
    val bgCard: Color,
    val bgCardDim: Color,
    val bgSheet: Color,
    val bgDialog: Color,
    val bgCode: Color,
    val bgPendingBar: Color,
    val glassEdgeHi: Color,
    val glassEdgeLo: Color,
    val glassSheen: Color,
    val scrim: Color,
    val borderHair: Color,
    val borderCard: Color,
    val borderInput: Color,
    val borderIcon: Color,
    val borderRow: Color,
    val borderFaint: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val textDim: Color,
    val textFaint: Color,
    val textLogToken: Color,
    val accent: Color,
    val accent2: Color,
    val onAccent: Color,
    val green: Color,
    val amber: Color,
    val amberText: Color,
    val red: Color,
    val blue: Color,
    val knobOff: Color,
    val trackOff: Color,
    val trackOffBorder: Color,
    val dotOff: Color,
    val progressTrack: Color,
    val sparkDim: Color,
    val termBg: Color,
    val termBarBg: Color,
    val termBorder: Color,
    val termText: Color,
    val termTabActive: Color,
    val termTabBorder: Color,
    val termKeyBg: Color,
    val termKeyAltBg: Color,
    val termExtraKeyBg: Color,
    val termExtraKeyBorder: Color,
    val termKeyText: Color,
    val termExtraKeyText: Color,
    val termRowBg: Color,
    val termRowBorder: Color,
    val dangerBg: Color,
    val dangerCode: Color,
    val dangerCodeBg: Color,
    val dangerCodeBorder: Color,
    val dangerText: Color,
    val dangerBody: Color,
    val dangerDim: Color,
    val dangerMono: Color,
    val dangerSub: Color,
    val dangerOutlineText: Color,
    val dangerLoss: Color,
    val accentBody: Color,
    val onRed: Color,
)

/** The colour the current theme paints with. Properties keep the names the screens already use. */
object Wrt {
    /**
     * The palette in force: the mode (light / dark / follow the system) and the accent the user
     * chose. It reads Compose state inside [ThemeStore], so a change recomposes every reader.
     */
    val palette: WrtPalette get() = ThemeStore.current()

    // ---- the style the palette sits in (fonts, corners, nav) ----
    val style: UiStyle get() = ThemeStore.style
    val sansFamily get() = ThemeStore.style.sansFamily
    val displayFamily get() = ThemeStore.style.displayFamily
    val monoFamily get() = ThemeStore.style.monoFamily
    fun r(n: Float) = WrtR(n)
    fun pill() = WrtPill()
    fun iconShape() = WrtIconShape()

    val AuroraTop: Color get() = palette.auroraTop
    val AuroraBottom: Color get() = palette.auroraBottom
    val BlobA: Color get() = palette.blobA
    val BlobB: Color get() = palette.blobB
    val BlobC: Color get() = palette.blobC
    val BgScreen: Color get() = palette.bgScreen
    val BgSolid: Color get() = palette.bgSolid
    val BgBar: Color get() = palette.bgBar
    val BgDeep: Color get() = palette.bgDeep
    val BgCard: Color get() = palette.bgCard
    val BgCardDim: Color get() = palette.bgCardDim
    val BgSheet: Color get() = palette.bgSheet
    val BgDialog: Color get() = palette.bgDialog
    val BgCode: Color get() = palette.bgCode
    val BgPendingBar: Color get() = palette.bgPendingBar
    val GlassEdgeHi: Color get() = palette.glassEdgeHi
    val GlassEdgeLo: Color get() = palette.glassEdgeLo
    val GlassSheen: Color get() = palette.glassSheen
    val Scrim: Color get() = palette.scrim
    val BorderHair: Color get() = palette.borderHair
    val BorderCard: Color get() = palette.borderCard
    val BorderInput: Color get() = palette.borderInput
    val BorderIcon: Color get() = palette.borderIcon
    val BorderRow: Color get() = palette.borderRow
    val BorderFaint: Color get() = palette.borderFaint
    val TextPrimary: Color get() = palette.textPrimary
    val TextSecondary: Color get() = palette.textSecondary
    val TextTertiary: Color get() = palette.textTertiary
    val TextDim: Color get() = palette.textDim
    val TextFaint: Color get() = palette.textFaint
    val TextLogToken: Color get() = palette.textLogToken
    val Accent: Color get() = palette.accent
    val OnAccent: Color get() = palette.onAccent
    val Green: Color get() = palette.green
    val Amber: Color get() = palette.amber
    val AmberText: Color get() = palette.amberText
    val Red: Color get() = palette.red
    val Blue: Color get() = palette.blue
    val KnobOff: Color get() = palette.knobOff
    val TrackOff: Color get() = palette.trackOff
    val TrackOffBorder: Color get() = palette.trackOffBorder
    val DotOff: Color get() = palette.dotOff
    val ProgressTrack: Color get() = palette.progressTrack
    val SparkDim: Color get() = palette.sparkDim
    val TermBg: Color get() = palette.termBg
    val TermBarBg: Color get() = palette.termBarBg
    val TermBorder: Color get() = palette.termBorder
    val TermText: Color get() = palette.termText
    val TermTabActive: Color get() = palette.termTabActive
    val TermTabBorder: Color get() = palette.termTabBorder
    val TermKeyBg: Color get() = palette.termKeyBg
    val TermKeyAltBg: Color get() = palette.termKeyAltBg
    val TermExtraKeyBg: Color get() = palette.termExtraKeyBg
    val TermExtraKeyBorder: Color get() = palette.termExtraKeyBorder
    val TermKeyText: Color get() = palette.termKeyText
    val TermExtraKeyText: Color get() = palette.termExtraKeyText
    val TermRowBg: Color get() = palette.termRowBg
    val TermRowBorder: Color get() = palette.termRowBorder
    val DangerBg: Color get() = palette.dangerBg
    val DangerCode: Color get() = palette.dangerCode
    val DangerCodeBg: Color get() = palette.dangerCodeBg
    val DangerCodeBorder: Color get() = palette.dangerCodeBorder
    val DangerText: Color get() = palette.dangerText
    val DangerBody: Color get() = palette.dangerBody
    val DangerDim: Color get() = palette.dangerDim
    val DangerMono: Color get() = palette.dangerMono
    val DangerSub: Color get() = palette.dangerSub
    val DangerOutlineText: Color get() = palette.dangerOutlineText
    val DangerLoss: Color get() = palette.dangerLoss
    val Accent2: Color get() = palette.accent2
    val AccentBody: Color get() = palette.accentBody
    val OnRed: Color get() = palette.onRed
}

// ---- building a palette: a style's skin, in light or dark, with the chosen accent ------------

private val Ink = Color(0xFF0F172A)
private val White = Color.White
private val Black = Color.Black

/** One accent colour, in the shade that suits each mode (the dark mode's is brighter). */
@Immutable
class WrtAccent(val id: String, val label: String, val onDark: Color, val onLight: Color)

/** The colours that differ from one style to the next. Everything else is shared. */
private data class Skin(
    val top: Color, val bottom: Color,
    val blobA: Color, val blobB: Color, val blobC: Color,
    val bar: Color, val card: Color, val cardDim: Color, val deep: Color,
    val sheet: Color, val dialog: Color, val code: Color,
    val edgeHi: Color, val edgeLo: Color, val sheen: Color, val scrim: Color,
    /** The colour hairlines and outlines are drawn in, and how strong each kind is. */
    val line: Color, val aHair: Float, val aCard: Float, val aInput: Float, val aIcon: Float, val aRow: Float,
    val tp: Color, val ts: Color, val tt: Color, val td: Color, val tf: Color,
    val green: Color, val amber: Color, val amberText: Color, val red: Color, val blue: Color,
    val accent2: Color, val onAccent: Color,
)

private fun skinOf(style: UiStyle, dark: Boolean, a: Color): Skin {
    val clear = Color.Transparent
    return when (style) {
        UiStyle.Orbit -> if (dark) Skin(
            Color(0xFF1B0A3F), Color(0xFF0E0422), Color(0xFF7C3AED).copy(alpha = 0.50f), a.copy(alpha = 0.30f), Color(0xFF35E0FF).copy(alpha = 0.16f),
            Color(0xFF12062A).copy(alpha = 0.70f), Color(0xFFE7DCFF).copy(alpha = 0.07f), White.copy(alpha = 0.04f), Black.copy(alpha = 0.28f),
            Color(0xFF1A0C3A).copy(alpha = 0.98f), Color(0xFF1E0F42).copy(alpha = 0.99f), Black.copy(alpha = 0.36f),
            lerp(White, a, 0.25f).copy(alpha = 0.32f), White.copy(alpha = 0.06f), White.copy(alpha = 0.06f), Color(0xB30A0220),
            White, 0.07f, 0.12f, 0.18f, 0.14f, 0.07f,
            Color(0xFFF5EEFF), Color(0xFFCBBDF0), Color(0xFFB8A8E3), Color(0xFFA995D6), Color(0xFF6F5FA0),
            Color(0xFF3CF2A5), Color(0xFFFFC857), Color(0xFFEBD9B0), Color(0xFFFF5C7A), Color(0xFF35E0FF),
            Color(0xFF7C5CFF), Color(0xFF1A0838),
        ) else Skin(
            Color(0xFFF7F1FF), Color(0xFFE9E3FA), Color(0xFF7C3AED).copy(alpha = 0.14f), a.copy(alpha = 0.14f), Color(0xFF35E0FF).copy(alpha = 0.12f),
            White.copy(alpha = 0.80f), White.copy(alpha = 0.78f), White.copy(alpha = 0.5f), Ink.copy(alpha = 0.045f),
            Color(0xFFFAF7FF).copy(alpha = 0.99f), White.copy(alpha = 0.99f), Ink.copy(alpha = 0.06f),
            White, Ink.copy(alpha = 0.07f), White.copy(alpha = 0.30f), Color(0x590F172A),
            Ink, 0.07f, 0.10f, 0.18f, 0.14f, 0.06f,
            Color(0xFF1B1140), Color(0xFF3F3470), Color(0xFF5A5190), Color(0xFF7A72A8), Color(0xFFA29BC8),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFDC2626), Color(0xFF0891B2),
            Color(0xFF7C5CFF), White,
        )
        UiStyle.Abyss -> if (dark) Skin(
            Color(0xFF061224), Color(0xFF02060D), a.copy(alpha = 0.26f), Color(0xFF8B5CF6).copy(alpha = 0.16f), a.copy(alpha = 0.12f),
            Color(0xFF040C18).copy(alpha = 0.72f), Color(0xFFBFE9FF).copy(alpha = 0.06f), White.copy(alpha = 0.03f), Black.copy(alpha = 0.28f),
            Color(0xFF0A1626).copy(alpha = 0.98f), Color(0xFF0C1A2D).copy(alpha = 0.99f), Black.copy(alpha = 0.36f),
            lerp(White, a, 0.45f).copy(alpha = 0.42f), a.copy(alpha = 0.05f), lerp(White, a, 0.3f).copy(alpha = 0.07f), Color(0xB3020409),
            White, 0.07f, 0.10f, 0.16f, 0.13f, 0.06f,
            Color(0xFFEAF6FF), Color(0xFFA9C3D8), Color(0xFF9AA7B9), Color(0xFF7886A0), Color(0xFF52607A),
            Color(0xFF3CF2A5), Color(0xFFFFC857), Color(0xFFEBD9B0), Color(0xFFFF5C7A), Color(0xFF5AA9FF),
            Color(0xFF8B5CF6), Color(0xFF04121A),
        ) else Skin(
            Color(0xFFF4F8FC), Color(0xFFE6EEF6), a.copy(alpha = 0.14f), a.copy(alpha = 0.07f), Color(0xFF3B82F6).copy(alpha = 0.08f),
            White.copy(alpha = 0.80f), White.copy(alpha = 0.78f), White.copy(alpha = 0.5f), Ink.copy(alpha = 0.045f),
            Color(0xFFFAFBFE).copy(alpha = 0.99f), White.copy(alpha = 0.99f), Ink.copy(alpha = 0.06f),
            White, Ink.copy(alpha = 0.07f), White.copy(alpha = 0.30f), Color(0x590F172A),
            Ink, 0.07f, 0.10f, 0.18f, 0.14f, 0.06f,
            Color(0xFF0F172A), Color(0xFF334155), Color(0xFF475569), Color(0xFF64748B), Color(0xFF94A3B8),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFDC2626), Color(0xFF2563EB),
            Color(0xFF7C3AED), White,
        )
        UiStyle.Aurora -> if (dark) Skin(
            Color(0xFF1A1636), Color(0xFF0F0C26), a.copy(alpha = 0.32f), Color(0xFFFF6AA8).copy(alpha = 0.20f), Color(0xFF4D9FFF).copy(alpha = 0.22f),
            Color(0xFF14102E).copy(alpha = 0.78f), White.copy(alpha = 0.09f), White.copy(alpha = 0.05f), Black.copy(alpha = 0.25f),
            Color(0xFF1C1740).copy(alpha = 0.98f), Color(0xFF211B49).copy(alpha = 0.99f), Black.copy(alpha = 0.34f),
            White.copy(alpha = 0.34f), White.copy(alpha = 0.06f), White.copy(alpha = 0.08f), Color(0xB30A0820),
            White, 0.08f, 0.14f, 0.20f, 0.15f, 0.07f,
            Color(0xFFF2EFFF), Color(0xFFC9C3EE), Color(0xFFADA6D8), Color(0xFF8F88BF), Color(0xFF665F98),
            Color(0xFF3CE0A0), Color(0xFFFFC857), Color(0xFFEBD9B0), Color(0xFFFF6B8A), Color(0xFF6AB4FF),
            Color(0xFFFF6AA8), Color(0xFF1A1636),
        ) else Skin(
            Color(0xFFF3F1FB), Color(0xFFEDE9FB), Color(0xFFFFC7E2).copy(alpha = 0.85f), Color(0xFFB9D8FF).copy(alpha = 0.80f), Color(0xFFC8F5E0).copy(alpha = 0.70f),
            White.copy(alpha = 0.72f), White.copy(alpha = 0.72f), White.copy(alpha = 0.45f), Ink.copy(alpha = 0.045f),
            Color(0xFFFBFAFF).copy(alpha = 0.99f), White.copy(alpha = 0.99f), Ink.copy(alpha = 0.06f),
            White, Color(0xFF1B1740).copy(alpha = 0.06f), White.copy(alpha = 0.35f), Color(0x591B1740),
            Color(0xFF1B1740), 0.06f, 0.08f, 0.18f, 0.14f, 0.05f,
            Color(0xFF1B1740), Color(0xFF4A4670), Color(0xFF6F6C92), Color(0xFF8A87A8), Color(0xFFB0AECB),
            Color(0xFF18A86B), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFE11D48), Color(0xFF2F7DE1),
            Color(0xFFFF6AA8), White,
        )
        UiStyle.Deck -> if (dark) Skin(
            Color(0xFF050805), Color(0xFF050805), clear, clear, clear,
            Color(0xFF0A0D0A), Color(0xFF0B0F0B), Color(0xFF080B08), Black.copy(alpha = 0.4f),
            Color(0xFF0A0D0A), Color(0xFF0C100C), Black,
            a.copy(alpha = 0.55f), a.copy(alpha = 0.30f), clear, Color(0xCC000000),
            a, 0.22f, 0.40f, 0.55f, 0.45f, 0.20f,
            lerp(a, White, 0.35f), a, a.copy(alpha = 0.80f), a.copy(alpha = 0.58f), a.copy(alpha = 0.38f),
            Color(0xFF3DFF7A), Color(0xFFFFB000), Color(0xFFFFD27A), Color(0xFFFF4D4D), Color(0xFF3DFF7A),
            Color(0xFF3DFF7A), Color(0xFF050805),
        ) else Skin(
            Color(0xFFF1ECD2), Color(0xFFF1ECD2), clear, clear, clear,
            Color(0xFFE6E0C2), Color(0xFFFBF7E4), Color(0xFFF5F0DA), Ink.copy(alpha = 0.06f),
            Color(0xFFF8F4DE), Color(0xFFFBF7E4), Ink.copy(alpha = 0.07f),
            Color(0xFF1A1400).copy(alpha = 0.55f), Color(0xFF1A1400).copy(alpha = 0.30f), clear, Color(0x661A1400),
            Color(0xFF1A1400), 0.20f, 0.45f, 0.60f, 0.50f, 0.20f,
            Color(0xFF1A1400), Color(0xFF3A2E00), Color(0xFF5A4800), Color(0xFF7A6500), Color(0xFFA08C3C),
            Color(0xFF147A3C), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFC81E1E), Color(0xFF147A3C),
            Color(0xFF147A3C), Color(0xFFFBF7E4),
        )
        UiStyle.Glacier -> if (dark) Skin(
            Color(0xFF1E2430), Color(0xFF1E2430), clear, clear, clear,
            Color(0xFF1E2430), Color(0xFF1E2430), Color(0xFF191E29), Black.copy(alpha = 0.25f),
            Color(0xFF232A38), Color(0xFF262D3D), Black.copy(alpha = 0.30f),
            clear, clear, clear, Color(0xB30A0E16),
            White, 0.08f, 0.07f, 0.14f, 0.10f, 0.08f,
            Color(0xFFEAF0FF), Color(0xFFB8C3DC), Color(0xFF98A5C2), Color(0xFF7F8CAA), Color(0xFF59647F),
            Color(0xFF3CE0A0), Color(0xFFFFC857), Color(0xFFEBD9B0), Color(0xFFFF6B8A), Color(0xFF6AB4FF),
            Color(0xFF8A5CFF), White,
        ) else Skin(
            Color(0xFFE4EBF5), Color(0xFFE4EBF5), clear, clear, clear,
            Color(0xFFE4EBF5), Color(0xFFE4EBF5), Color(0xFFD9E1EE), Ink.copy(alpha = 0.05f),
            Color(0xFFE9EFF8), Color(0xFFEDF2FA), Ink.copy(alpha = 0.06f),
            clear, clear, clear, Color(0x59263248),
            Color(0xFF26324D), 0.10f, 0.08f, 0.14f, 0.10f, 0.10f,
            Color(0xFF26324D), Color(0xFF4A5878), Color(0xFF66748F), Color(0xFF7A88A6), Color(0xFFA5B0C6),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFDC2626), Color(0xFF2563EB),
            Color(0xFF8A5CFF), White,
        )
        UiStyle.Ember -> if (dark) Skin(
            Color(0xFF1A1310), Color(0xFF110C0A), a.copy(alpha = 0.22f), clear, clear,
            Color(0xFF14100E).copy(alpha = 0.94f), Color(0xFF201815), Color(0xFF1A1311), Black.copy(alpha = 0.30f),
            Color(0xFF241B17), Color(0xFF281E19), Black.copy(alpha = 0.35f),
            clear, clear, clear, Color(0xB3080504),
            Color(0xFFFFD2B8), 0.08f, 0.13f, 0.20f, 0.14f, 0.09f,
            Color(0xFFFBEFE6), Color(0xFFD9C3B3), Color(0xFFB8A090), Color(0xFFA8917F), Color(0xFF7A6558),
            Color(0xFF3CE0A0), Color(0xFFFFC857), Color(0xFFEBD9B0), Color(0xFFFF5C6A), Color(0xFF6AB4FF),
            Color(0xFFFF3D54), White,
        ) else Skin(
            Color(0xFFFFF4EC), Color(0xFFFFEADB), a.copy(alpha = 0.14f), clear, clear,
            Color(0xFFFFF1E6).copy(alpha = 0.94f), White, Color(0xFFFFF8F3), Ink.copy(alpha = 0.04f),
            Color(0xFFFFF8F3), White, Ink.copy(alpha = 0.06f),
            clear, clear, clear, Color(0x592A1710),
            Color(0xFF3A1F10), 0.08f, 0.12f, 0.20f, 0.14f, 0.08f,
            Color(0xFF2A1710), Color(0xFF5A3A2A), Color(0xFF7A5A48), Color(0xFF94705C), Color(0xFFB89A88),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFE11D48), Color(0xFF2563EB),
            Color(0xFFE11D48), White,
        )
        UiStyle.Blueprint -> if (dark) Skin(
            Color(0xFF0D45A5), Color(0xFF0A3578), clear, clear, clear,
            Color(0xFF0B3D91).copy(alpha = 0.96f), White.copy(alpha = 0.05f), White.copy(alpha = 0.03f), Black.copy(alpha = 0.20f),
            Color(0xFF0C3F96), Color(0xFF0C419A), Black.copy(alpha = 0.30f),
            clear, clear, clear, Color(0xB3041B44),
            Color(0xFF9DC0F5), 0.30f, 0.70f, 0.60f, 0.60f, 0.35f,
            Color(0xFFEAF3FF), Color(0xFFC8DCFB), Color(0xFF9DC0F5), Color(0xFF8FB3EE), Color(0xFF6A92D6),
            Color(0xFF6BFFB0), Color(0xFFFFE066), Color(0xFFFFF0A8), Color(0xFFFF8A8A), Color(0xFF9DC0F5),
            Color(0xFFFFE066), Color(0xFF0B3D91),
        ) else Skin(
            Color(0xFFF4F8FF), Color(0xFFE8F0FF), clear, clear, clear,
            Color(0xFFEAF1FF), White.copy(alpha = 0.55f), White.copy(alpha = 0.35f), Ink.copy(alpha = 0.04f),
            Color(0xFFF0F5FF), Color(0xFFF7FAFF), Ink.copy(alpha = 0.06f),
            clear, clear, clear, Color(0x590B2C66),
            Color(0xFF0B3D91), 0.25f, 0.65f, 0.60f, 0.60f, 0.30f,
            Color(0xFF0B2C66), Color(0xFF244B8F), Color(0xFF3F66AE), Color(0xFF5A7FC0), Color(0xFF8AA5D4),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFDC2626), Color(0xFF2563EB),
            Color(0xFF0B3D91), White,
        )
        UiStyle.Swiss -> if (dark) Skin(
            Color(0xFF0D0D0D), Color(0xFF0D0D0D), clear, clear, clear,
            Color(0xFF0D0D0D), clear, White.copy(alpha = 0.05f), Black.copy(alpha = 0.30f),
            Color(0xFF161614), Color(0xFF1A1A18), Black.copy(alpha = 0.40f),
            clear, clear, clear, Color(0xCC000000),
            Color(0xFFF2F2EE), 0.20f, 1f, 0.70f, 0.70f, 0.22f,
            Color(0xFFF2F2EE), Color(0xFFCFCFC8), Color(0xFFA5A59D), Color(0xFF8A8A82), Color(0xFF5E5E58),
            Color(0xFF3CE08A), Color(0xFFFFC857), Color(0xFFEBD9B0), Color(0xFFFF5C42), Color(0xFF6AA8FF),
            Color(0xFFF2F2EE), Color(0xFF0D0D0D),
        ) else Skin(
            Color(0xFFF2F2EE), Color(0xFFF2F2EE), clear, clear, clear,
            Color(0xFFF2F2EE), clear, Color(0xFF0D0D0D).copy(alpha = 0.04f), Ink.copy(alpha = 0.05f),
            Color(0xFFF7F7F3), Color(0xFFF7F7F3), Ink.copy(alpha = 0.06f),
            clear, clear, clear, Color(0x990D0D0D),
            Color(0xFF0D0D0D), 0.20f, 1f, 0.70f, 0.70f, 0.20f,
            Color(0xFF0D0D0D), Color(0xFF3A3A36), Color(0xFF55554F), Color(0xFF77776F), Color(0xFFA5A59D),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFE11D00), Color(0xFF2563EB),
            Color(0xFF0D0D0D), White,
        )
        UiStyle.Arcade -> if (dark) Skin(
            Color(0xFF1B1034), Color(0xFF120A26), clear, clear, clear,
            Color(0xFF0A0618), Color(0xFF2A1A52), Color(0xFF22143F), Black.copy(alpha = 0.35f),
            Color(0xFF2A1A52), Color(0xFF2E1D5A), Black.copy(alpha = 0.50f),
            clear, clear, clear, Color(0xCC050210),
            White, 0.25f, 1f, 1f, 1f, 0.30f,
            Color(0xFFFFF7DC), Color(0xFFD8CCF5), Color(0xFFB7A5EE), Color(0xFF9A89D6), Color(0xFF6F5FA0),
            Color(0xFF6BFF6B), Color(0xFFFFE14D), Color(0xFFFFF0A8), Color(0xFFFF4DA6), Color(0xFF4DF3FF),
            Color(0xFFFF4DA6), Color(0xFF000000),
        ) else Skin(
            Color(0xFFFFF3C4), Color(0xFFFFE79A), clear, clear, clear,
            Color(0xFFFFE14D), White, Color(0xFFFFF8DC), Color(0x141B1034),
            White, White, Color(0x141B1034),
            clear, clear, clear, Color(0x991B1034),
            Color(0xFF1B1034), 0.25f, 1f, 1f, 1f, 0.30f,
            Color(0xFF1B1034), Color(0xFF3A2A66), Color(0xFF55468A), Color(0xFF75689F), Color(0xFFA095C4),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFD10037), Color(0xFF2563EB),
            Color(0xFFFF4DA6), Color(0xFF000000),
        )
        UiStyle.Paper -> if (dark) Skin(
            Color(0xFF16130E), Color(0xFF16130E), clear, clear, clear,
            Color(0xFF2A2410), Color(0xFF231F17), Color(0xFF1C1912), Black.copy(alpha = 0.3f),
            Color(0xFF231F17), Color(0xFF2A2519), Black.copy(alpha = 0.4f),
            Color(0xFFFFF4D6), Color(0xFFFFF4D6), clear, Color(0xCC000000),
            Color(0xFFFFF4D6), 0.22f, 0.95f, 0.95f, 0.8f, 0.35f,
            Color(0xFFFFF4D6), Color(0xFFE6DDBC), Color(0xFFC9C09E), Color(0xFFA89F80), Color(0xFF7A7358),
            Color(0xFF3DDC84), Color(0xFFFFD93D), Color(0xFFFFE9A0), Color(0xFFFF6B6B), Color(0xFF4D9FFF),
            Color(0xFFFFD93D), Color(0xFF111111),
        ) else Skin(
            Color(0xFFFFF4D6), Color(0xFFFFF4D6), clear, clear, clear,
            Color(0xFFFFD93D), White, Color(0xFFFFFBEA), Color(0x14111111),
            White, White, Color(0x14111111),
            Color(0xFF111111), Color(0xFF111111), clear, Color(0x99111111),
            Color(0xFF111111), 0.25f, 1f, 1f, 0.9f, 0.35f,
            Color(0xFF111111), Color(0xFF3A3629), Color(0xFF4B4636), Color(0xFF6B6552), Color(0xFF9A937A),
            Color(0xFF16A34A), Color(0xFFB45309), Color(0xFF78350F), Color(0xFFD10037), Color(0xFF2563EB),
            Color(0xFFFFD93D), Color(0xFF111111),
        )
    }
}

private fun build(style: UiStyle, dark: Boolean, accentChoice: WrtAccent): WrtPalette {
    val accent = if (dark) accentChoice.onDark else accentChoice.onLight
    val k = skinOf(style, dark, accent)
    val id = style.id + (if (dark) "-dark-" else "-light-") + accentChoice.id
    val label = style.label + (if (dark) " · Dark · " else " · Light · ") + accentChoice.label
    val lt = !dark
    return WrtPalette(
        id = id, label = label, isLight = lt,
        auroraTop = k.top, auroraBottom = k.bottom,
        blobA = k.blobA, blobB = k.blobB, blobC = k.blobC,
        bgScreen = Color.Transparent,
        bgSolid = lerp(k.top, k.bottom, 0.5f),
        bgBar = k.bar, bgDeep = k.deep, bgCard = k.card, bgCardDim = k.cardDim,
        bgSheet = k.sheet, bgDialog = k.dialog, bgCode = k.code,
        bgPendingBar = accent.copy(alpha = 0.12f),
        glassEdgeHi = k.edgeHi, glassEdgeLo = k.edgeLo, glassSheen = k.sheen,
        scrim = k.scrim,
        borderHair = k.line.copy(alpha = k.aHair),
        borderCard = k.line.copy(alpha = k.aCard),
        borderInput = k.line.copy(alpha = k.aInput),
        borderIcon = k.line.copy(alpha = k.aIcon),
        borderRow = k.line.copy(alpha = k.aRow),
        borderFaint = k.line.copy(alpha = k.aCard),
        textPrimary = k.tp, textSecondary = k.ts, textTertiary = k.tt, textDim = k.td, textFaint = k.tf,
        textLogToken = k.tp,
        accent = accent, accent2 = k.accent2, onAccent = k.onAccent,
        green = k.green, amber = k.amber, amberText = k.amberText, red = k.red, blue = k.blue,
        knobOff = k.td,
        trackOff = k.line.copy(alpha = if (lt) 0.10f else 0.09f),
        trackOffBorder = k.line.copy(alpha = if (lt) 0.18f else 0.16f),
        dotOff = k.line.copy(alpha = 0.20f),
        progressTrack = k.line.copy(alpha = if (style.surface.heavy) 0.14f else 0.10f),
        sparkDim = k.line.copy(alpha = 0.10f),
        termBg = Color(0xFF000000), termBarBg = Color(0xFF050505), termBorder = Color(0xFF161616),
        termText = Color(0xFFD7E4DE), termTabActive = Color(0xFF141D1A), termTabBorder = Color(0xFF1E1E1E),
        termKeyBg = Color(0xFF141414), termKeyAltBg = Color(0xFF1D1D1D), termExtraKeyBg = Color(0xFF151515),
        termExtraKeyBorder = Color(0xFF242424), termKeyText = Color(0xFF9DB0A8),
        termExtraKeyText = Color(0xFFC3D2CC), termRowBg = Color(0xFF0A0A0A), termRowBorder = Color(0xFF1C1C1C),
        dangerBg = if (dark) Color(0xFF150D0B) else Color(0xFFFCEFEC),
        dangerCode = if (dark) Color(0xFF100B0A) else Color(0xFFF6DDD8),
        dangerCodeBg = if (dark) Color(0xFF0A0706) else Color(0xFFF3D3CD),
        dangerCodeBorder = if (dark) Color(0xFF241512) else Color(0xFFE5B3AA),
        dangerText = if (dark) Color(0xFFF0E4E1) else Color(0xFF3A1511),
        dangerBody = if (dark) Color(0xFFC9ACA6) else Color(0xFF6B3A33),
        dangerDim = if (dark) Color(0xFF8A716B) else Color(0xFF946A63),
        dangerMono = if (dark) Color(0xFFB9A29C) else Color(0xFF7A4F48),
        dangerSub = if (dark) Color(0xFF9B7A74) else Color(0xFF8A5A53),
        dangerOutlineText = if (dark) Color(0xFFD9938A) else Color(0xFFB2392B),
        dangerLoss = if (dark) Color(0xFFD9B8B2) else Color(0xFF6B3A33),
        accentBody = if (dark) lerp(accent, White, 0.55f) else lerp(accent, Ink, 0.45f),
        onRed = if (dark) Color(0xFF2A0C08) else White,
    )
}

/** The colours on offer. Light or dark is chosen separately, in [ThemeStore]. */
object WrtThemes {
    val accents: List<WrtAccent> = listOf(
        WrtAccent("orbit", "Orbit", Color(0xFFFF4FD8), Color(0xFFC026D3)),
        WrtAccent("cyan", "Sonar Cyan", Color(0xFF35E0FF), Color(0xFF0891B2)),
        WrtAccent("violet", "Violet", Color(0xFF9B7CFF), Color(0xFF6D28D9)),
        WrtAccent("mint", "Mint", Color(0xFF3CF2A5), Color(0xFF059669)),
        WrtAccent("solar", "Solar", Color(0xFFFFB000), Color(0xFFB45309)),
        WrtAccent("rose", "Rose", Color(0xFFFF6B9D), Color(0xFFE11D48)),
        WrtAccent("azure", "Azure", Color(0xFF6C8CFF), Color(0xFF3B63E0)),
        WrtAccent("ember", "Ember", Color(0xFFFF7A2F), Color(0xFFEA580C)),
        WrtAccent("chalk", "Chalk", Color(0xFFFFE066), Color(0xFF0B3D91)),
        WrtAccent("signal", "Signal", Color(0xFFFF5238), Color(0xFFE11D00)),
        WrtAccent("arcade", "Arcade", Color(0xFFFFE14D), Color(0xFFFF4DA6)),
    )

    fun accentById(id: String?): WrtAccent = accents.firstOrNull { it.id == id } ?: accents.first()

    private val cache = HashMap<String, WrtPalette>()

    /** One palette per (style, mode, accent), built once. */
    fun palette(style: UiStyle, dark: Boolean, accent: WrtAccent): WrtPalette =
        cache.getOrPut(style.id + (if (dark) "d-" else "l-") + accent.id) { build(style, dark, accent) }
}
