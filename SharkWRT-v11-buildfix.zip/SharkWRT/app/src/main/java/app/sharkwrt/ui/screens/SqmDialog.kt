package app.sharkwrt.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import app.sharkwrt.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.sharkwrt.data.RouterOps
import app.sharkwrt.ops.NetUsage
import app.sharkwrt.ops.Sqm
import app.sharkwrt.ui.GhostButton
import app.sharkwrt.ui.PrimaryButton
import app.sharkwrt.ui.WToggle
import app.sharkwrt.ui.glassBorder
import app.sharkwrt.ui.mono
import app.sharkwrt.ui.sans
import app.sharkwrt.ui.theme.Wrt
import kotlinx.coroutines.launch

/**
 * Speed control (SQM): shapes the WAN to a bit under the line's real speed so a download or
 * a video call does not make everything else lag. Installs sqm-scripts + cake if missing.
 */
@Composable
fun SqmDialog(ops: RouterOps, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<Sqm.Status?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var ifaces by remember { mutableStateOf<List<NetUsage.IfaceInfo>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var tick by remember { mutableStateOf(0) }

    var dev by remember { mutableStateOf("") }
    var down by remember { mutableStateOf("") }
    var up by remember { mutableStateOf("") }
    var script by remember { mutableStateOf("piece_of_cake.qos") }
    var enabled by remember { mutableStateOf(true) }

    LaunchedEffect(ops, tick) {
        ops.sqmStatus().onSuccess { s ->
            status = s
            loadError = null
            s.config?.let { c ->
                dev = c.iface
                down = if (c.downKbit > 0) (c.downKbit / 1000.0).toString().removeSuffix(".0") else ""
                up = if (c.upKbit > 0) (c.upKbit / 1000.0).toString().removeSuffix(".0") else ""
                script = c.script
                enabled = c.enabled
            }
        }.onFailure { loadError = it.message ?: "Could not read the router." }
        ifaces = ops.interfaces()
        if (dev.isBlank()) dev = (ifaces.firstOrNull { it.name == "wan" } ?: ifaces.firstOrNull())?.device.orEmpty()
    }

    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(
            Modifier
                .fillMaxWidth()
                .glassBorder(RoundedCornerShape(Wrt.r(16f)))
                .background(Wrt.BgDialog, RoundedCornerShape(Wrt.r(16f)))
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("Speed control (SQM)", style = sans(15f, 650))
            val s = status
            when {
                loadError != null -> Text(loadError!!, style = sans(12f, 400, Wrt.Red), modifier = Modifier.padding(top = 10.dp))
                s == null -> Text("Checking the router…", style = sans(12f, 400, Wrt.TextDim), modifier = Modifier.padding(top = 10.dp))
                !s.installed || !s.cakeAvailable -> {
                    Text(
                        "SQM keeps the connection responsive while it is busy. It needs ${Sqm.PACKAGES.joinToString(" and ")}, " +
                            "which ${if (!s.installed) "are not" else "are only partly"} on this router. " +
                            "They are installed with ${s.packageManager} — the router needs internet.",
                        style = sans(12f, 400, Wrt.TextSecondary, lineHeight = 18.sp),
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    message?.let { (ok, t) ->
                        Text(t, style = mono(10.5f, 500, if (ok) Wrt.Green else Wrt.Red, lineHeight = 16.sp), modifier = Modifier.padding(top = 10.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton(if (busy) "Installing…" else "Install SQM packages") {
                        if (!busy) scope.launch {
                            busy = true; message = null
                            val (ok, tail) = ops.sqmInstall()
                            message = ok to (if (ok) "Installed." else tail)
                            busy = false
                            if (ok) tick++
                        }
                    }
                }
                else -> {
                    val c = s.config
                    Text(
                        when {
                            c == null -> "Not set up yet. Enter your plan's speeds — SQM works best a little below them (about 90–95%)."
                            s.active && c.enabled -> "Running on ${c.iface}."
                            c.enabled -> "Switched on, but no shaper is showing on ${c.iface}. Check the interface name."
                            else -> "Switched off."
                        },
                        style = sans(12f, 500, if (s.active && c?.enabled == true) Wrt.Green else Wrt.TextSecondary, lineHeight = 18.sp),
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Row(Modifier.padding(top = 12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Enabled", style = sans(13f, 600), modifier = Modifier.weight(1f))
                        WToggle(enabled) { enabled = !enabled }
                    }
                    FieldLabel("INTERFACE (THE ONE FACING THE INTERNET)")
                    if (ifaces.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ifaces.forEach { i ->
                                val on = i.device == dev
                                Text(
                                    "${i.name} · ${i.device}",
                                    style = mono(11f, 600, if (on) Wrt.Accent else Wrt.TextSecondary),
                                    modifier = Modifier
                                        .border(1.dp, if (on) Wrt.Accent else Wrt.BorderCard, RoundedCornerShape(Wrt.r(9f)))
                                        .clickable { dev = i.device }
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }
                        }
                    }
                    FormTextField(dev, { dev = it })
                    FieldLabel("DOWNLOAD LIMIT (MBIT/S)")
                    FormTextField(down, { down = it.filter { ch -> ch.isDigit() || ch == '.' } })
                    FieldLabel("UPLOAD LIMIT (MBIT/S)")
                    FormTextField(up, { up = it.filter { ch -> ch.isDigit() || ch == '.' } })
                    FieldLabel("QUEUE SCRIPT")
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Sqm.SCRIPTS.forEach { sc ->
                            val on = sc == script
                            Text(
                                sc.removeSuffix(".qos"),
                                style = mono(11f, 600, if (on) Wrt.Accent else Wrt.TextSecondary),
                                modifier = Modifier
                                    .border(1.dp, if (on) Wrt.Accent else Wrt.BorderCard, RoundedCornerShape(Wrt.r(9f)))
                                    .clickable { script = sc }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                            )
                        }
                    }
                    Text(
                        "piece_of_cake is the simple choice for most homes. 0 means no limit in that direction.",
                        style = sans(10f, 400, Wrt.TextDim, lineHeight = 14.sp),
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    message?.let { (ok, t) ->
                        Text(t, style = sans(11.5f, 500, if (ok) Wrt.Green else Wrt.Red, lineHeight = 16.sp), modifier = Modifier.padding(top = 10.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton(if (busy) "Applying…" else "Apply") {
                        if (busy) return@PrimaryButton
                        val d = Sqm.mbitToKbit(down.ifBlank { "0" })
                        val u = Sqm.mbitToKbit(up.ifBlank { "0" })
                        when {
                            !Sqm.valid(dev) -> message = false to "Enter the interface name, such as eth1 or pppoe-wan."
                            d == null || u == null -> message = false to "Speeds must be numbers in Mbit/s."
                            else -> scope.launch {
                                busy = true; message = null
                                val err = ops.sqmApply(
                                    c?.section ?: Sqm.SECTION,
                                    Sqm.Config(c?.section ?: Sqm.SECTION, enabled, dev, d, u, script),
                                )
                                message = if (err == null) true to (if (enabled) "SQM applied." else "SQM switched off.") else false to err
                                busy = false
                                if (err == null) tick++
                            }
                        }
                    }
                    if (s.tc.isNotBlank()) {
                        Text(s.tc, style = mono(9.5f, 400, Wrt.TextDim, lineHeight = 14.sp), modifier = Modifier.padding(top = 10.dp))
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            GhostButton("Close", onClick = { if (!busy) onDismiss() })
        }
    }
}
