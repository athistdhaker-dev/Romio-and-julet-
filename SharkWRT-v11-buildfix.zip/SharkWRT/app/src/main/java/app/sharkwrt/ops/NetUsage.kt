package app.sharkwrt.ops

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * Usage history that survives reboots, read from the NetUsage tracker (see assets/netusage.sh).
 *
 * The tracker keeps vnstat's database on flash (`/etc/vnstat`, saved every 15 minutes and at
 * shutdown) and its settings in `/etc/config/netusage` — which interface to count, the monthly
 * cap and the day the billing cycle starts. This file asks the router for those and turns
 * vnstat's JSON into numbers. No Android types, so it is testable on the JVM.
 */
object NetUsage {
    const val SCRIPT_ASSET = "netusage.sh"

    /**
     * One command: the settings, the router's date, then vnstat's daily and monthly figures for
     * the configured interface. `NONE` when the tracker is not set up, `NOVNSTAT` when it is but
     * vnstat is gone.
     */
    val READ: String =
        "I=\$(uci -q get netusage.main.iface 2>/dev/null); " +
            "if [ -z \"\$I\" ]; then echo NONE; exit 0; fi; " +
            "if ! command -v vnstat >/dev/null 2>&1; then echo NOVNSTAT; exit 0; fi; " +
            "echo \"CFG \$(uci -q get netusage.main.cap_gb) \$(uci -q get netusage.main.cycle_day)\"; " +
            "echo \"NOW \$(date +%Y-%m-%d)\"; echo \"IFACE \$I\"; " +
            "echo DAYS; vnstat -i \"\$I\" --json d 62 2>/dev/null; echo; " +
            "echo MONTHS; vnstat -i \"\$I\" --json m 12 2>/dev/null; echo; echo END"

    /** One interface as netifd has it — what the per-interface usage picker lists. */
    data class IfaceInfo(val name: String, val device: String, val up: Boolean, val proto: String)

    const val IFACES = "ubus call network.interface dump 2>/dev/null"

    /** `ubus call network.interface dump` → the interfaces that have a device to count on. */
    fun parseIfaces(json: String): List<IfaceInfo> {
        val arr = try {
            JSONObject(json.trim()).optJSONArray("interface")
        } catch (e: JSONException) {
            null
        } ?: return emptyList()
        val out = ArrayList<IfaceInfo>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("interface")
            if (name.isBlank() || name == "loopback") continue
            val dev = o.optString("l3_device").ifBlank { o.optString("device") }
            if (dev.isBlank() || dev == "lo") continue
            out.add(IfaceInfo(name, dev, o.optBoolean("up", false), o.optString("proto")))
        }
        return out
    }

    /** Names that go into a shell command are checked first: interface names are [A-Za-z0-9._-]. */
    fun safeDevice(dev: String): Boolean = dev.isNotEmpty() && dev.length <= 15 && dev.all { it.isLetterOrDigit() || it in "._-" }

    /**
     * [READ], but for any device: vnstat is asked to start counting it first if it is not
     * already. The monthly cap only applies to the interface the tracker was set up for.
     */
    fun readFor(dev: String): String =
        "I='$dev'; command -v vnstat >/dev/null 2>&1 || { echo NOVNSTAT; exit 0; }; " +
            "vnstat -i \"\$I\" --json d 1 >/dev/null 2>&1 || vnstat --add -i \"\$I\" >/dev/null 2>&1 || vnstat -u -i \"\$I\" >/dev/null 2>&1; " +
            "C=\$(uci -q get netusage.main.iface 2>/dev/null); CAP=0; [ \"\$C\" = \"\$I\" ] && CAP=\$(uci -q get netusage.main.cap_gb); " +
            "echo \"CFG \$CAP \$(uci -q get netusage.main.cycle_day)\"; " +
            "echo \"NOW \$(date +%Y-%m-%d)\"; echo \"IFACE \$I\"; " +
            "echo DAYS; vnstat -i \"\$I\" --json d 62 2>/dev/null; echo; " +
            "echo MONTHS; vnstat -i \"\$I\" --json m 12 2>/dev/null; echo; echo END"

    /** Runs the bundled installer from standard input. Its `$1` is empty, so it installs. */
    const val INSTALL = "sh -s"

    data class Day(val key: Int, val label: String, val rx: Long, val tx: Long)
    data class Month(val label: String, val rx: Long, val tx: Long)

    data class Summary(
        val iface: String,
        val todayRx: Long,
        val todayTx: Long,
        val cycleRx: Long,
        val cycleTx: Long,
        /** 0 means no cap. */
        val capGb: Int,
        val cycleDay: Int,
        val cycleElapsedDays: Int,
        val cycleLengthDays: Int,
        val totalRx: Long,
        val totalTx: Long,
        /** When vnstat began counting, as "2026-10-01", if it says. */
        val since: String?,
        val recentDays: List<Day>,
        val recentMonths: List<Month>,
    ) {
        val cycleBytes: Long get() = cycleRx + cycleTx
        val capBytes: Long get() = capGb * 1_000_000_000L

        /** Where the cycle will end up at its current pace. */
        val projectedBytes: Long
            get() = if (cycleElapsedDays <= 0) cycleBytes else cycleBytes * cycleLengthDays / cycleElapsedDays

        /** The cycle starts on the 1st: it is simply the calendar month. */
        val isCalendarMonth: Boolean get() = cycleDay == 1
    }

    sealed class Read {
        data object NotInstalled : Read()
        data object NoVnstat : Read()
        data class Ok(val summary: Summary) : Read()
        data class Bad(val message: String) : Read()
    }

    fun parse(stdout: String): Read {
        val lines = stdout.lines().map { it.trim() }
        if (lines.any { it == "NONE" }) return Read.NotInstalled
        if (lines.any { it == "NOVNSTAT" }) return Read.NoVnstat

        val cfg = lines.firstOrNull { it.startsWith("CFG") }?.split(Regex("\\s+")).orEmpty()
        val capGb = cfg.getOrNull(1)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val cycleDay = (cfg.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 28)
        val iface = lines.firstOrNull { it.startsWith("IFACE ") }?.removePrefix("IFACE ")?.trim().orEmpty()
        val today = lines.firstOrNull { it.startsWith("NOW ") }?.removePrefix("NOW ")?.trim()
            ?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            ?: return Read.Bad("The router's date could not be read.")

        val days = section(lines, "DAYS", "MONTHS")
        val months = section(lines, "MONTHS", "END")
        if (days == null) return Read.Bad("vnstat has no daily data yet. Give it a few minutes.")

        val dayObj = interfaceOf(days) ?: return Read.Bad("vnstat returned nothing for $iface.")
        val multiplier = if ((days.optString("jsonversion", "2").toIntOrNull() ?: 2) >= 2) 1L else 1024L
        val allDays = dayEntries(dayObj, multiplier)

        val monthList = months?.let { m ->
            interfaceOf(m)?.let { monthEntries(it, if ((m.optString("jsonversion", "2").toIntOrNull() ?: 2) >= 2) 1L else 1024L) }
        }.orEmpty()

        val nowKey = today.year * 10000 + today.monthValue * 100 + today.dayOfMonth
        val todayEntry = allDays.firstOrNull { it.key == nowKey }

        // The cycle began on cycleDay of this month, or of last month if that day has not come.
        val start = if (today.dayOfMonth >= cycleDay) today.withDayOfMonth(cycleDay)
        else today.minusMonths(1).withDayOfMonth(cycleDay)
        val startKey = start.year * 10000 + start.monthValue * 100 + start.dayOfMonth
        val inCycle = allDays.filter { it.key >= startKey }
        val elapsed = (ChronoUnit.DAYS.between(start, today) + 1).toInt()
        val length = ChronoUnit.DAYS.between(start, start.plusMonths(1)).toInt()

        val total = dayObj.optJSONObject("traffic")?.optJSONObject("total")
        val created = dayObj.optJSONObject("created")?.optJSONObject("date")
        return Read.Ok(
            Summary(
                iface = iface.ifBlank { dayObj.optString("name") },
                todayRx = todayEntry?.rx ?: 0L,
                todayTx = todayEntry?.tx ?: 0L,
                cycleRx = inCycle.sumOf { it.rx },
                cycleTx = inCycle.sumOf { it.tx },
                capGb = capGb,
                cycleDay = cycleDay,
                cycleElapsedDays = elapsed,
                cycleLengthDays = length,
                totalRx = (total?.optLong("rx", 0L) ?: 0L) * multiplier,
                totalTx = (total?.optLong("tx", 0L) ?: 0L) * multiplier,
                since = created?.let { dateLabel(it) },
                recentDays = allDays.takeLast(14),
                recentMonths = monthList.takeLast(6),
            ),
        )
    }

    /** The JSON object between a marker line and the next one. */
    private fun section(lines: List<String>, from: String, to: String): JSONObject? {
        val start = lines.indexOf(from)
        if (start < 0) return null
        val end = lines.indexOf(to).let { if (it < 0) lines.size else it }
        val text = lines.subList(start + 1, maxOf(start + 1, end)).firstOrNull { it.startsWith("{") } ?: return null
        return try {
            JSONObject(text)
        } catch (e: JSONException) {
            null
        }
    }

    private fun interfaceOf(root: JSONObject): JSONObject? = root.optJSONArray("interfaces")?.optJSONObject(0)

    private fun dayEntries(iface: JSONObject, multiplier: Long): List<Day> {
        val arr: JSONArray = iface.optJSONObject("traffic")?.optJSONArray("day") ?: return emptyList()
        val out = ArrayList<Day>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val d = o.optJSONObject("date") ?: continue
            val key = d.optInt("year") * 10000 + d.optInt("month") * 100 + d.optInt("day")
            out.add(Day(key, dateLabel(d), o.optLong("rx", 0L) * multiplier, o.optLong("tx", 0L) * multiplier))
        }
        return out.sortedBy { it.key }
    }

    private fun monthEntries(iface: JSONObject, multiplier: Long): List<Month> {
        val arr: JSONArray = iface.optJSONObject("traffic")?.optJSONArray("month") ?: return emptyList()
        val out = ArrayList<Pair<Int, Month>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val d = o.optJSONObject("date") ?: continue
            val key = d.optInt("year") * 100 + d.optInt("month")
            out.add(key to Month("%04d-%02d".format(d.optInt("year"), d.optInt("month")),
                o.optLong("rx", 0L) * multiplier, o.optLong("tx", 0L) * multiplier))
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    private fun dateLabel(d: JSONObject): String =
        "%04d-%02d-%02d".format(d.optInt("year"), d.optInt("month"), d.optInt("day").coerceAtLeast(1))

    /** The installer's own closing banner is the only reliable sign it finished. */
    fun installSucceeded(output: String): Boolean = output.contains("installed successfully")

    /** The last few lines of what the installer printed, for the dialog. */
    fun tail(output: String, lines: Int = 8): String =
        output.lines().map { it.trim() }.filter { it.isNotEmpty() }.takeLast(lines).joinToString("\n")
}
