package app.sharkwrt.ui.screens

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import app.sharkwrt.ui.glassBg

import app.sharkwrt.ui.glassBorder

import androidx.compose.animation.core.Animatable
import app.sharkwrt.ui.rememberHoldHaptics
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import app.sharkwrt.ui.Text
import androidx.compose.runtime.Composable
import kotlinx.coroutines.delay
import app.sharkwrt.data.UsageState
import app.sharkwrt.ui.FilterChip
import app.sharkwrt.data.OoklaOutcome
import app.sharkwrt.data.OoklaState
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.sharkwrt.data.Demo
import app.sharkwrt.data.Inventory
import app.sharkwrt.data.LiveTicker
import app.sharkwrt.data.RouterOps
import app.sharkwrt.data.SpeedPhase
import app.sharkwrt.data.SpeedResult
import app.sharkwrt.data.Ssid
import app.sharkwrt.data.Telemetry
import app.sharkwrt.ops.Commands
import app.sharkwrt.ui.ConnectionTopBar
import app.sharkwrt.ui.FlexSpacer
import app.sharkwrt.ui.GhostButton
import app.sharkwrt.ui.MonoTag
import app.sharkwrt.ui.PrimaryButton
import app.sharkwrt.ui.SectionLabel
import app.sharkwrt.ui.Sparkline
import app.sharkwrt.ui.StatusDot
import app.sharkwrt.ui.ThroughputChart
import app.sharkwrt.ui.WToggle
import app.sharkwrt.ui.WrtIcons
import app.sharkwrt.ui.mono
import app.sharkwrt.ui.sans
import app.sharkwrt.ui.theme.Wrt
import kotlinx.coroutines.launch

private val cpuSpark = listOf(13f, 11f, 14f, 9f, 12f, 7f, 11f, 5f, 10f, 8f, 12f, 9f)
private val ramSpark = listOf(10f, 9f, 10f, 8f, 9f, 8f, 7f, 8f, 7f, 8f, 7f, 7f)

@Composable
fun DashboardScreen(
    ticker: LiveTicker,
    live: Telemetry?,
    inventory: Inventory?,
    ops: RouterOps? = null,
    guest: app.sharkwrt.data.GuestStore? = null,
    /** The same store, told to be the IoT network. */
    iot: app.sharkwrt.data.GuestStore? = null,
    board: app.sharkwrt.ops.BoardInfo? = null,
    /** Set when this router is a mesh node: guest and IoT Wi-Fi are the primary's to run. */
    nodeOf: NodeOf? = null,
    routerName: String,
    onRouterTap: () -> Unit,
) {
    var rebootOpen by remember { mutableStateOf(false) }
    var speedOpen by remember { mutableStateOf(false) }
    var ifaceUsageOpen by remember { mutableStateOf(false) }
    var sqmOpen by remember { mutableStateOf(false) }
    var guestOpen by remember { mutableStateOf(false) }
    var iotOpen by remember { mutableStateOf(false) }
    // Usage history kept on the router; re-read each minute, and straight away after a setup.
    var usage by remember(ops) { mutableStateOf<UsageState>(UsageState.Loading) }
    var usageSetupOpen by remember { mutableStateOf(false) }
    var usageTick by remember { mutableStateOf(0) }
    LaunchedEffect(ops, usageTick) {
        if (ops != null) {
            while (true) {
                usage = ops.usageHistory()
                delay(60_000)
            }
        }
    }
    if (usageSetupOpen && ops != null) {
        UsageSetupDialog(
            ops,
            onDismiss = { usageSetupOpen = false },
            onDone = { usageSetupOpen = false; usage = UsageState.Loading; usageTick++ },
        )
    }
    if (rebootOpen && ops != null) {
        RebootDialog(ops, routerName, onDismiss = { rebootOpen = false })
    }
    if (ifaceUsageOpen && ops != null) InterfaceUsageDialog(ops, onDismiss = { ifaceUsageOpen = false })
    if (sqmOpen && ops != null) SqmDialog(ops, onDismiss = { sqmOpen = false })
    if (speedOpen && ops != null) {
        SpeedtestDialog(ops, onDismiss = { speedOpen = false })
    }
  Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().background(Wrt.BgScreen)) {
        ConnectionTopBar(
            routerName = routerName,
            latencyMs = live?.latencyMs ?: ticker.latencyMs,
            pollMs = live?.tickMs,
            onRouterTap = onRouterTap,
        )
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard(Modifier.weight(1f), "UPTIME", live?.uptimeLabel ?: "18d 04:12")
                StatCard(
                    Modifier.weight(1f),
                    "LOAD 1M",
                    String.format("%.2f", live?.load1 ?: ticker.load),
                    suffix = live?.let { String.format("%.2f %.2f", it.load5, it.load15) } ?: "0.38 0.31",
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GaugeCard(Modifier.weight(1f), "CPU", "${live?.cpuPct ?: ticker.cpuPct}") {
                    Sparkline(
                        live?.cpuSpark ?: cpuSpark,
                        Wrt.Accent,
                        Modifier.fillMaxWidth().height(18.dp).padding(top = 4.dp),
                        maxY = if (live != null) 100f else 18f,
                    )
                }
                GaugeCard(Modifier.weight(1f), "RAM", "${live?.ramPct ?: ticker.ramPct}") {
                    Sparkline(
                        live?.ramSpark ?: ramSpark,
                        Wrt.TextTertiary,
                        Modifier.fillMaxWidth().height(18.dp).padding(top = 4.dp),
                        maxY = if (live != null) 100f else 18f,
                    )
                }
                GaugeCard(Modifier.weight(1f), "FLASH", "${live?.flashPct ?: 34}") {
                    Box(Modifier.fillMaxWidth().padding(top = 11.dp).height(3.dp).background(Wrt.ProgressTrack, RoundedCornerShape(Wrt.r(2f)))) {
                        Box(
                            Modifier
                                .fillMaxWidth(((live?.flashPct ?: 34) / 100f).coerceIn(0.02f, 1f))
                                .height(3.dp)
                                .background(Wrt.TextTertiary, RoundedCornerShape(Wrt.r(2f)))
                        )
                    }
                }
            }
            LiveSpeedCard(
                down = live?.down ?: ticker.down,
                up = live?.up ?: ticker.up,
                live = live != null,
                stale = live?.stale == true,
            )
            DataUsageCard(live, live?.upstream?.name, usage, onSetup = { usageSetupOpen = true })
            if (ops != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton("Usage by interface", Modifier.weight(1f)) { ifaceUsageOpen = true }
                    GhostButton("Speed control (SQM)", Modifier.weight(1f)) { sqmOpen = true }
                }
            }
            WanCard(ticker, live)
            SsidCard(if (inventory != null) inventory.ssids.toList() else null)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction(
                    Modifier.weight(1f), WrtIcons.Reboot, "Reboot",
                    onClick = if (ops != null) ({ rebootOpen = true }) else null,
                )
                QuickAction(
                    Modifier.weight(1f), WrtIcons.GuestWifi, "Guest Wi-Fi",
                    onClick = if (guest != null) ({ guestOpen = true }) else null,
                )
                QuickAction(
                    Modifier.weight(1f), WrtIcons.IotWifi, "IoT Wi-Fi",
                    onClick = if (iot != null) ({ iotOpen = true }) else null,
                )
                QuickAction(
                    Modifier.weight(1f), WrtIcons.Speedtest, "Speedtest",
                    onClick = if (ops != null) ({ speedOpen = true }) else null,
                )
            }
        }
    }
    SheetHost(visible = guestOpen, onDismiss = { guestOpen = false }) {
        GuestSheet(guest, board?.hostname, onDismiss = { guestOpen = false }, node = nodeOf)
    }
    SheetHost(visible = iotOpen, onDismiss = { iotOpen = false }) {
        GuestSheet(iot, board?.hostname, onDismiss = { iotOpen = false }, node = nodeOf)
    }
  }
}

@Composable
private fun StatCard(modifier: Modifier, label: String, value: String, suffix: String? = null) {
    Column(
        modifier
            .glassBorder(RoundedCornerShape(Wrt.r(16f)))
            .glassBg(RoundedCornerShape(Wrt.r(16f)))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        SectionLabel(label, size = 9.5f)
        Row(Modifier.padding(top = 5.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(value, style = mono(15f, 600))
            if (suffix != null) Text(suffix, style = mono(10.5f, 500, Wrt.TextDim))
        }
    }
}

@Composable
private fun GaugeCard(modifier: Modifier, label: String, value: String, chart: @Composable () -> Unit) {
    Column(
        modifier
            .glassBorder(RoundedCornerShape(Wrt.r(16f)))
            .glassBg(RoundedCornerShape(Wrt.r(16f)))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        SectionLabel(label, size = 9.5f)
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.Bottom) {
            Text(value, style = mono(16f, 600))
            Text("%", style = mono(10.5f, 500, Wrt.TextDim), modifier = Modifier.padding(bottom = 1.dp))
        }
        chart()
    }
}

@Composable
private fun WanCard(ticker: LiveTicker, live: Telemetry?) {
    Column(
        Modifier
            .fillMaxWidth()
            .glassBorder(RoundedCornerShape(Wrt.r(28f)))
            .glassBg(RoundedCornerShape(Wrt.r(28f)))
            .padding(start = 13.dp, end = 13.dp, top = 12.dp, bottom = 10.dp)
    ) {
        val up = live?.upstream
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Named after whatever holds the default route, not a fixed "wan" — a router
            // upstreamed through a Wi-Fi client has neither the name nor the device.
            SectionLabel(
                "UPSTREAM · ${(up?.name ?: if (live != null) "—" else "wan").uppercase()}",
                size = 9.5f,
            )
            if (up?.wireless == true) MonoTag("CLIENT", color = Wrt.Blue, border = Wrt.Blue.copy(alpha = 0.5f))
            FlexSpacer()
            val isStale = live?.stale == true
            StatusDot(if (isStale) Wrt.Amber else Wrt.Accent, 5.dp, pulse = !isStale)
            Text(
                if (isStale) "WAITING" else "LIVE",
                style = mono(9f, 600, if (isStale) Wrt.Amber else Wrt.Accent, letterSpacing = 0.14.em),
            )
        }
        Row(
            Modifier.padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(live?.wanIp ?: (if (live != null) "—" else "82.44.19.7"), style = mono(16f, 600))
            Icon(WrtIcons.Copy, "copy upstream IP", Modifier.size(14.dp), tint = Wrt.TextDim)
            FlexSpacer()
            Text("↓ ${String.format("%.1f", (live?.down ?: ticker.down).last())}", style = mono(12.5f, 600, Wrt.Accent))
            Text("↑ ${String.format("%.1f", (live?.up ?: ticker.up).last())}", style = mono(12.5f, 600, Wrt.Blue))
            Text("Mbps", style = mono(9.5f, 500, Wrt.TextDim))
        }
        // The chart scales the series itself now; both sources hand it raw values.
        ThroughputChart(
            down = live?.down ?: ticker.down,
            up = live?.up ?: ticker.up,
            modifier = Modifier.fillMaxWidth().height(88.dp).padding(top = 6.dp),
        )
        // What the upstream actually is, under the numbers it produces.
        up?.let { u ->
            // The metric only explains anything when the links disagree about it.
            val several = live?.upstreams.orEmpty().map { it.metric }.distinct().size > 1
            Text(
                listOfNotNull(
                    u.ssid?.let { "via $it" },
                    u.device.ifBlank { null },
                    u.proto.ifBlank { null },
                    // Only worth showing when there is another link to compare it against.
                    if (several) "metric ${u.metric}" else null,
                ).joinToString(" · "),
                style = mono(10f, 500, if (u.wireless) Wrt.Blue else Wrt.TextDim),
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        Row(Modifier.padding(top = 6.dp)) {
            Text("60 s window", style = mono(10f, 500, Wrt.TextDim))
            FlexSpacer()
            Text(
                live?.totals ?: (if (live != null) "" else "since 09:12 · ↓ 214 GB · ↑ 38 GB"),
                style = mono(10f, 500, Wrt.TextDim),
            )
        }
        // A second link with its own default route is a real thing on a failover setup, and
        // the chart can only follow one of them. The rest get a line each.
        val others = live?.upstreams?.drop(1).orEmpty()
        if (others.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 10.dp).height(1.dp).background(Wrt.BorderHair))
            Text(
                "ALSO UP",
                style = mono(9f, 600, Wrt.TextDim, letterSpacing = 0.14.em),
                modifier = Modifier.padding(top = 9.dp),
            )
            val ranked = live?.upstreams.orEmpty().map { it.metric }.distinct().size > 1
            others.forEach { link -> OtherUpstreamRow(link, live?.rates?.get(link.device), ranked) }
        }
    }
}

/** One extra upstream: what it is, where it goes, and what it is carrying. */
@Composable
private fun OtherUpstreamRow(
    link: app.sharkwrt.ops.Upstream,
    rate: Pair<Float, Float>?,
    showMetric: Boolean,
) {
    Row(
        Modifier.fillMaxWidth().padding(top = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(link.name.uppercase(), style = mono(11f, 600))
                if (link.wireless) {
                    MonoTag("CLIENT", color = Wrt.Blue, border = Wrt.Blue.copy(alpha = 0.5f), size = 8.5f)
                }
                if (!link.hasV4) MonoTag("IPv6", size = 8.5f)
            }
            Text(
                listOfNotNull(
                    link.ssid?.let { "via $it" } ?: link.address,
                    link.device.ifBlank { null },
                    if (showMetric) "metric ${link.metric}" else null,
                ).joinToString(" · "),
                style = mono(9.5f, 500, Wrt.TextDim),
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                softWrap = false,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        Text(
            "↓ ${String.format("%.1f", rate?.first ?: 0f)}",
            style = mono(11f, 600, Wrt.Accent.copy(alpha = 0.75f)),
        )
        Text(
            "↑ ${String.format("%.1f", rate?.second ?: 0f)}",
            style = mono(11f, 600, Wrt.Blue.copy(alpha = 0.75f)),
        )
    }
}

@Composable
private fun SsidCard(liveSsids: List<Ssid>?) {
    val ssids = liveSsids ?: Demo.ssids
    // Local visual state only — real toggling ships with the uci staging flow.
    val enabled = remember(ssids.map { it.name to it.enabled }) {
        androidx.compose.runtime.mutableStateListOf(*ssids.map { it.enabled }.toTypedArray())
    }
    Column(
        Modifier
            .fillMaxWidth()
            .glassBorder(RoundedCornerShape(Wrt.r(28f)))
            .glassBg(RoundedCornerShape(Wrt.r(28f)))
            .padding(horizontal = 13.dp, vertical = 4.dp)
    ) {
        if (ssids.isEmpty()) {
            Text(
                "Waiting for wireless status…",
                style = mono(10.5f, 500, Wrt.TextDim),
                modifier = Modifier.padding(vertical = 14.dp),
            )
        }
        ssids.forEachIndexed { i, ssid ->
            val on = enabled[i]
            val active = on
            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(ssid.name, style = sans(13.5f, 650, if (active) Wrt.TextPrimary else Wrt.TextSecondary))
                    ssid.bands.forEach { b ->
                        MonoTag(b, color = if (active) Wrt.TextTertiary else Wrt.TextDim, border = if (active) Wrt.BorderInput else Wrt.BorderFaint)
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("${ssid.clients}", style = mono(11.5f, 500, if (active) Wrt.TextTertiary else Wrt.TextDim))
                    Text("cl", style = mono(11.5f, 500, Wrt.TextDim))
                }
                WToggle(on) { enabled[i] = !enabled[i] }
            }
            if (i < ssids.lastIndex) Box(Modifier.fillMaxWidth().height(1.dp).background(Wrt.BorderHair))
        }
    }
}

/** Rebooting cuts the network for everyone, so it takes a deliberate 3 s hold. */
@Composable
private fun RebootDialog(ops: RouterOps, routerName: String, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<String?>(null) }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .border(1.dp, Wrt.Red.copy(alpha = 0.4f), RoundedCornerShape(Wrt.r(16f)))
                .background(Wrt.BgDialog, RoundedCornerShape(Wrt.r(16f)))
                .padding(18.dp)
        ) {
            Text("Reboot $routerName?", style = sans(15f, 650, Wrt.Red))
            Text(
                "Wi-Fi and internet drop for a minute or two while it restarts. " +
                    "The app reconnects on its own once it is back.",
                style = sans(12f, 400, Wrt.TextSecondary, lineHeight = 18.sp),
                modifier = Modifier.padding(top = 6.dp),
            )
            if (result != null) {
                Text(
                    result!!,
                    style = mono(10.5f, 500, if (result!!.startsWith("Failed")) Wrt.Red else Wrt.Accent),
                    modifier = Modifier.padding(top = 12.dp),
                )
                Spacer(Modifier.height(14.dp))
                PrimaryButton("Done", onClick = onDismiss)
            } else {
                Spacer(Modifier.height(16.dp))
                HoldToConfirm("Hold to reboot") {
                    scope.launch { result = ops.reboot() }
                }
                Text(
                    "Hold 3 s to confirm",
                    style = sans(10.5f, 400, Wrt.TextDim),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(6.dp))
                GhostButton("Cancel", onClick = onDismiss)
            }
        }
    }
}

/** A speed test leaves the house, so it says where it goes and how much it pulls. */
private enum class SpeedEngine { Ookla, Quick }

@Composable
private fun SpeedtestDialog(ops: RouterOps, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var engine by remember { mutableStateOf(SpeedEngine.Ookla) }

    // Quick test (Cloudflare, no install).
    var running by remember { mutableStateOf(false) }
    var phase by remember { mutableStateOf(SpeedPhase.Download) }
    var result by remember { mutableStateOf<SpeedResult?>(null) }

    // Ookla's own client, on the router.
    var okState by remember { mutableStateOf<OoklaState>(OoklaState.Checking) }
    var okBusy by remember { mutableStateOf(false) }
    var okOutcome by remember { mutableStateOf<OoklaOutcome?>(null) }
    var okStatus by remember { mutableStateOf("") }
    LaunchedEffect(engine) {
        if (engine == SpeedEngine.Ookla && okState == OoklaState.Checking) okState = ops.ooklaStatus()
    }
    val working = running || okBusy

    Dialog(onDismissRequest = { if (!working) onDismiss() }) {
        Column(
            Modifier
                .fillMaxWidth()
                .glassBorder(RoundedCornerShape(Wrt.r(16f)))
                .background(Wrt.BgDialog, RoundedCornerShape(Wrt.r(16f)))
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Text("Speed test", style = sans(15f, 650))
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip("Ookla", selected = engine == SpeedEngine.Ookla, onClick = { if (!working) engine = SpeedEngine.Ookla })
                FilterChip("Quick", selected = engine == SpeedEngine.Quick, onClick = { if (!working) engine = SpeedEngine.Quick })
            }
            if (engine == SpeedEngine.Ookla) {
                OoklaPanel(
                    state = okState,
                    busy = okBusy,
                    status = okStatus,
                    outcome = okOutcome,
                    onSwitchToQuick = { engine = SpeedEngine.Quick },
                    onRecheck = { okState = OoklaState.Checking; okOutcome = null },
                    onGo = {
                        if (!okBusy) {
                            okBusy = true
                            okOutcome = null
                            scope.launch {
                                var current = okState
                                if (current is OoklaState.NeedsInstall) {
                                    okStatus = "Downloading the Ookla client…"
                                    current = ops.ooklaInstall(current.build)
                                    okState = current
                                }
                                if (current is OoklaState.Ready) {
                                    okStatus = "Testing — ping, download, upload…"
                                    okOutcome = ops.ooklaRun(current.path)
                                }
                                okBusy = false
                            }
                        }
                    },
                    onClose = { if (!okBusy) onDismiss() },
                )
            } else {
                Text(
                    "The router downloads up to ${Commands.SPEEDTEST_UP_BYTES / 1_000_000} MB from " +
                        "${Commands.SPEEDTEST_HOST} and uploads up to the same back, " +
                        "${Commands.SPEEDTEST_SECONDS} s each at most. This uses your internet data. " +
                        "Nothing is installed.",
                    style = sans(12f, 400, Wrt.TextSecondary, lineHeight = 18.sp),
                    modifier = Modifier.padding(top = 10.dp),
                )
                val outcome = result
                if (outcome != null) QuickResultBox(outcome)
                Spacer(Modifier.height(16.dp))
                PrimaryButton(
                    when {
                        running && phase == SpeedPhase.Download -> "Downloading…"
                        running -> "Uploading…"
                        result != null -> "Run again"
                        else -> "Run test"
                    },
                    onClick = {
                        if (!running) {
                            running = true
                            scope.launch {
                                phase = SpeedPhase.Download
                                result = ops.speedtest(onPhase = { phase = it })
                                running = false
                            }
                        }
                    },
                )
                Spacer(Modifier.height(6.dp))
                GhostButton(if (result != null) "Close" else "Cancel", onClick = { if (!running) onDismiss() })
            }
        }
    }
}

/** What the quick (Cloudflare) test measured. */
@Composable
private fun QuickResultBox(outcome: SpeedResult) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
            .border(1.dp, Wrt.BorderHair, RoundedCornerShape(Wrt.r(15f)))
            .background(Wrt.BgDeep, RoundedCornerShape(Wrt.r(15f)))
            .padding(horizontal = 13.dp, vertical = 12.dp)
    ) {
        if (outcome.error != null) {
            Text(outcome.error, style = sans(12f, 500, Wrt.Red))
        } else {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "↓ ${String.format("%.1f", outcome.downMbps)}",
                        style = mono(18f, 600, Wrt.Accent),
                        maxLines = 1,
                        softWrap = false,
                    )
                    Text(
                        "${Telemetry.bytesLabel(outcome.downBytes)} · " +
                            "${String.format("%.1f", outcome.downSeconds)} s",
                        style = mono(10f, 500, Wrt.TextDim),
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                Column(Modifier.weight(1f)) {
                    if (outcome.hasUpload) {
                        Text(
                            "↑ ${String.format("%.1f", outcome.upMbps)}",
                            style = mono(18f, 600, Wrt.Blue),
                            maxLines = 1,
                            softWrap = false,
                        )
                        Text(
                            "${Telemetry.bytesLabel(outcome.upBytes)} · " +
                                "${String.format("%.1f", outcome.upSeconds)} s",
                            style = mono(10f, 500, Wrt.TextDim),
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    } else {
                        Text("↑ —", style = mono(18f, 600, Wrt.TextDim), maxLines = 1)
                    }
                }
                Text("Mbps", style = mono(10.5f, 500, Wrt.TextDim), modifier = Modifier.padding(bottom = 3.dp))
            }
            outcome.uploadError?.let {
                Text(it, style = sans(10f, 400, Wrt.Amber), modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

/** The Ookla half of the dialog: where the client stands, the numbers, and the one button. */
@Composable
private fun OoklaPanel(
    state: OoklaState,
    busy: Boolean,
    status: String,
    outcome: OoklaOutcome?,
    onSwitchToQuick: () -> Unit,
    onRecheck: () -> Unit,
    onGo: () -> Unit,
    onClose: () -> Unit,
) {
    val uri = LocalUriHandler.current
    Text(
        "Ookla's Speedtest runs on the router, picks a nearby server, and measures ping, " +
            "download and upload. It uses your internet data.",
        style = sans(12f, 400, Wrt.TextSecondary, lineHeight = 18.sp),
        modifier = Modifier.padding(top = 10.dp),
    )
    when (state) {
        OoklaState.Checking ->
            Text("Checking the router…", style = sans(11.5f, 400, Wrt.TextDim), modifier = Modifier.padding(top = 10.dp))
        is OoklaState.NeedsInstall ->
            Text(
                "Ookla's client is not on this router yet. The app can download it (about 5 MB, from " +
                    "install.speedtest.net) into the router's memory — nothing is written to flash, and " +
                    "it is gone after a reboot. Running it means you accept Ookla's licence and privacy policy.",
                style = sans(11.5f, 400, Wrt.Amber, lineHeight = 17.sp),
                modifier = Modifier.padding(top = 10.dp),
            )
        is OoklaState.Unsupported ->
            Text(
                "Ookla publishes no client for this router's CPU (${state.machine}) — MIPS routers are the " +
                    "usual case. The Quick test works on any router.",
                style = sans(11.5f, 400, Wrt.Amber, lineHeight = 17.sp),
                modifier = Modifier.padding(top = 10.dp),
            )
        is OoklaState.Failed ->
            Text(state.message, style = sans(11.5f, 500, Wrt.Red, lineHeight = 17.sp), modifier = Modifier.padding(top = 10.dp))
        is OoklaState.Ready -> Unit
    }
    if (busy) {
        Text(status, style = mono(10.5f, 500, Wrt.Accent), modifier = Modifier.padding(top = 12.dp))
    }
    when (outcome) {
        is OoklaOutcome.Done -> {
            val r = outcome.result
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp)
                    .border(1.dp, Wrt.BorderHair, RoundedCornerShape(Wrt.r(15f)))
                    .background(Wrt.BgDeep, RoundedCornerShape(Wrt.r(15f)))
                    .padding(horizontal = 13.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(Modifier.weight(1f)) {
                        val (v, u) = speedParts(r.downMbps)
                        Text("↓ DOWNLOAD", style = mono(9f, 600, Wrt.Accent, letterSpacing = 0.12.em))
                        Text(v, style = mono(22f, 600), maxLines = 1, softWrap = false, modifier = Modifier.padding(top = 3.dp))
                        Text(u, style = mono(10f, 500, Wrt.TextDim))
                    }
                    Column(Modifier.weight(1f)) {
                        val (v, u) = speedParts(r.upMbps)
                        Text("↑ UPLOAD", style = mono(9f, 600, Wrt.Blue, letterSpacing = 0.12.em))
                        Text(v, style = mono(22f, 600), maxLines = 1, softWrap = false, modifier = Modifier.padding(top = 3.dp))
                        Text(u, style = mono(10f, 500, Wrt.TextDim))
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("PING", style = mono(9f, 600, Wrt.TextDim, letterSpacing = 0.12.em))
                        Text(String.format("%.1f ms", r.pingMs), style = mono(12.5f, 600), modifier = Modifier.padding(top = 2.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("JITTER", style = mono(9f, 600, Wrt.TextDim, letterSpacing = 0.12.em))
                        Text(
                            r.jitterMs?.let { String.format("%.1f ms", it) } ?: "—",
                            style = mono(12.5f, 600), modifier = Modifier.padding(top = 2.dp),
                        )
                    }
                    r.packetLossPct?.let { loss ->
                        Column(Modifier.weight(1f)) {
                            Text("LOSS", style = mono(9f, 600, Wrt.TextDim, letterSpacing = 0.12.em))
                            Text(String.format("%.1f%%", loss), style = mono(12.5f, 600), modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                }
                Text(
                    listOfNotNull(r.server, r.isp, r.externalIp).joinToString(" · "),
                    style = mono(10f, 500, Wrt.TextDim, lineHeight = 15.sp),
                )
                r.resultUrl?.let { url ->
                    Text(
                        "Open this result on speedtest.net",
                        style = sans(11.5f, 600, Wrt.Accent),
                        modifier = Modifier.clickable { runCatching { uri.openUri(url) } },
                    )
                }
            }
        }
        is OoklaOutcome.Error ->
            Text(outcome.message, style = sans(11.5f, 500, Wrt.Red, lineHeight = 17.sp), modifier = Modifier.padding(top = 12.dp))
        null -> Unit
    }
    Spacer(Modifier.height(16.dp))
    when (state) {
        is OoklaState.Unsupported -> PrimaryButton("Use the Quick test", onClick = onSwitchToQuick)
        is OoklaState.Failed -> if (outcome == null) PrimaryButton("Check again", onClick = onRecheck) else PrimaryButton("Run again", onClick = onGo)
        else -> PrimaryButton(
            when {
                busy -> "Working…"
                state == OoklaState.Checking -> "Checking…"
                state is OoklaState.NeedsInstall -> "Download Ookla and run"
                outcome != null -> "Run again"
                else -> "Run Ookla test"
            },
            onClick = { if (state !is OoklaState.Checking) onGo() },
        )
    }
    Spacer(Modifier.height(6.dp))
    GhostButton(if (outcome != null) "Close" else "Cancel", onClick = onClose)
}

/** Fills over a 3 s hold; letting go early cancels. Shared with the firmware flash. */
@Composable
fun HoldToConfirm(label: String, onConfirm: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptics = rememberHoldHaptics()
    var done by remember { mutableStateOf(false) }
    // True from press until release or completion: the release pulse belongs only to a hold
    // that was actually under way, and the pointer loop below can report a release more than once.
    var live by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(RoundedCornerShape(Wrt.r(16f)))
            .border(1.dp, Wrt.Red.copy(alpha = 0.5f), RoundedCornerShape(Wrt.r(16f)))
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        awaitPointerEvent()
                        val pressed = currentEvent.changes.any { it.pressed }
                        if (pressed && !done && !progress.isRunning) {
                            live = true
                            scope.launch {
                                // The feel runs as a child of the hold, so stopping the fill stops it too.
                                val train = launch { haptics.train { progress.value } }
                                progress.animateTo(
                                    1f,
                                    tween(((1f - progress.value) * 3000).toInt(), easing = LinearEasing),
                                )
                                train.cancel()
                                if (progress.value >= 1f) {
                                    done = true
                                    live = false
                                    haptics.confirm()
                                    onConfirm()
                                }
                            }
                        } else if (!pressed && !done) {
                            val wasLive = live
                            live = false
                            scope.launch {
                                progress.stop()
                                if (wasLive) haptics.release()
                                progress.animateTo(0f, tween(180))
                            }
                        }
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth(progress.value)
                .height(46.dp)
                .background(Wrt.Red.copy(alpha = 0.3f))
        )
        Text(label, style = sans(13.5f, 650, Wrt.Red))
    }
}

@Composable
private fun QuickAction(modifier: Modifier, icon: ImageVector, label: String, onClick: (() -> Unit)? = null) {
    Column(
        modifier.let { if (onClick != null) it.clickable(onClick = onClick) else it },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(56.dp)
                .background(Wrt.TextPrimary.copy(alpha = 0.07f), Wrt.iconShape())
                .border(1.dp, Wrt.BorderCard, Wrt.iconShape()),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, label, Modifier.size(22.dp), tint = Wrt.Blue) }
        Spacer(Modifier.height(6.dp))
        Text(label, style = sans(10.5f, 600, Wrt.TextPrimary), maxLines = 1, softWrap = false)
    }
}
