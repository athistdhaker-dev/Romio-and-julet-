package app.sharkwrt.i18n

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** The Indian languages the interface can be shown in. The code `en` means the strings as written. */
enum class AppLang(val code: String, val native: String) {
    En("en", "English"), Hi("hi", "हिन्दी"), Bn("bn", "বাংলা"), Mr("mr", "मराठी"), Ta("ta", "தமிழ்"),
    Te("te", "తెలుగు"), Gu("gu", "ગુજરાતી"), Kn("kn", "ಕನ್ನಡ"), Ml("ml", "മലയാളം"), Pa("pa", "ਪੰਜਾਬੀ"),
    Or("or", "ଓଡ଼ିଆ"), Ur("ur", "اردو"), As("as", "অসমীয়া");

    companion object { fun byCode(c: String?) = entries.firstOrNull { it.code == c } ?: En }
}

/**
 * Looks a string up in [TABLE] for the chosen language. [lang] is Compose state, so every `Text`
 * that calls [tr] repaints when the language changes. Anything not in the table stays English.
 */
object L10n {
    private const val PREFS = "sharkwrt_lang"
    var lang: AppLang by mutableStateOf(AppLang.En)
        private set

    private val index: Map<String, List<String>> by lazy {
        val map = HashMap<String, List<String>>()
        TABLE.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val p = line.split('|')
            if (p.size >= 2) map[p[0].trim().lowercase()] = p.drop(1)
        }
        map
    }
    private val order: List<String> by lazy { TABLE_ORDER.split(',') }

    fun load(context: Context) {
        val code = runCatching { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lang", null) }.getOrNull()
        lang = AppLang.byCode(code)
    }

    fun set(context: Context, value: AppLang) {
        lang = value
        runCatching { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lang", value.code).apply() }
    }

    fun tr(text: String): String {
        val l = lang
        if (l == AppLang.En || text.isEmpty()) return text
        val col = order.indexOf(l.code)
        if (col < 0) return text
        val row = index[text.trim().lowercase()] ?: return text
        val t = row.getOrNull(col)?.takeIf { it.isNotBlank() } ?: return text
        val lead = text.takeWhile { it.isWhitespace() }
        val tail = text.takeLastWhile { it.isWhitespace() }
        return lead + t + tail
    }
}
