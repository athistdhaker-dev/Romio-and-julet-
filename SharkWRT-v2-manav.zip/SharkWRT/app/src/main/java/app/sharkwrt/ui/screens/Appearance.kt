package app.sharkwrt.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import app.sharkwrt.ui.GhostButton
import app.sharkwrt.ui.glassBorder
import app.sharkwrt.ui.sans
import app.sharkwrt.ui.theme.ThemeMode
import app.sharkwrt.ui.theme.ThemeStore
import app.sharkwrt.ui.theme.Wrt
import app.sharkwrt.ui.theme.WrtAccent
import app.sharkwrt.ui.theme.WrtThemes

/** A short label for the current choice, e.g. "Dark · Teal" or "System · Blue". */
@Composable
fun appearanceSummary(): String {
    val mode = ThemeStore.mode
    val accent = ThemeStore.accent
    return "${mode.label} · ${accent.label}"
}

/**
 * The appearance controls: light / dark / follow the phone, then the accent colour. Changes
 * apply at once and are remembered. Used inline on the About screen and inside the dialog.
 */
@Composable
fun AppearanceControls(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val mode = ThemeStore.mode
    val accent = ThemeStore.accent
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Mode", style = sans(12f, 600, Wrt.TextSecondary))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { m ->
                    ModeOption(m.label, selected = m == mode, Modifier.weight(1f)) { ThemeStore.setMode(context, m) }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Accent colour", style = sans(12f, 600, Wrt.TextSecondary))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                WrtThemes.accents.forEach { a ->
                    AccentDot(a, selected = a.id == accent.id) { ThemeStore.setAccent(context, a) }
                }
            }
        }
    }
}

@Composable
private fun ModeOption(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .clip(shape)
            .let {
                if (selected) it.background(Wrt.Accent.copy(alpha = 0.16f), shape).border(1.dp, Wrt.Accent, shape)
                else it.border(1.dp, Wrt.BorderInput, shape)
            }
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = sans(12.5f, if (selected) 650 else 500, if (selected) Wrt.Accent else Wrt.TextSecondary))
    }
}

@Composable
private fun AccentDot(accent: WrtAccent, selected: Boolean, onClick: () -> Unit) {
    val colour = if (Wrt.palette.isLight) accent.onLight else accent.onDark
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(colour)
                .border(if (selected) 3.dp else 1.dp, if (selected) Wrt.TextPrimary else Wrt.BorderCard, CircleShape)
        )
        Text(accent.label, style = sans(10f, if (selected) 650 else 500, if (selected) Wrt.TextPrimary else Wrt.TextDim))
    }
}

/** The same controls as a dialog, for the places that have no room for them inline. */
@Composable
fun AppearanceDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .glassBorder(RoundedCornerShape(16.dp))
                .background(Wrt.BgDialog, RoundedCornerShape(16.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Appearance", style = sans(15f, 650))
            AppearanceControls()
            GhostButton("Done", onClick = onDismiss)
        }
    }
}
