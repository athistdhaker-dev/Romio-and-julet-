package app.sharkwrt.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import app.sharkwrt.R

val SansFamily = FontFamily(
    Font(R.font.rajdhani_400regular, FontWeight.Normal),
    Font(R.font.rajdhani_500medium, FontWeight.Medium),
    Font(R.font.rajdhani_600semibold, FontWeight.SemiBold),
    Font(R.font.rajdhani_600semibold, FontWeight(650)),
    Font(R.font.rajdhani_700bold, FontWeight.Bold),
)

/** Headings, wordmark and HUD labels. */
val DisplayFamily = FontFamily(
    Font(R.font.orbitron_600semibold, FontWeight.SemiBold),
    Font(R.font.orbitron_700bold, FontWeight.Bold),
)

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
private fun mono(weight: FontWeight) = Font(
    R.font.red_hat_mono_var,
    weight = weight,
    variationSettings = FontVariation.Settings(FontVariation.weight(weight.weight)),
)

val MonoFamily = FontFamily(
    mono(FontWeight.Normal),
    mono(FontWeight.Medium),
    mono(FontWeight.SemiBold),
    mono(FontWeight.Bold),
)

val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = SansFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = SansFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 20.sp,
    ),
    titleLarge = TextStyle(
        fontFamily = SansFamily,
        fontWeight = FontWeight(650),
        fontSize = 24.sp,
        letterSpacing = (-0.24).sp,
    ),
)
