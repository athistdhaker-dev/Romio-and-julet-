package app.sharkwrt.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/**
 * Every colour the UI paints with, for one theme.
 *
 * The screens never read this directly: they read [Wrt], whose properties forward to the
 * palette that is current. [Wrt.palette] is Compose state, so switching theme repaints whatever
 * read a colour, with no screen having to be told.
 *
 * All themes are "liquid glass": the surfaces are translucent whites (or inks, on the light
 * theme) laid over the aurora backdrop that [SharkWrtTheme] paints, so what shows through a card
 * is the theme's own colour. The solid `bgSolid`, `bgSheet` and `bgDialog` exist for the few
 * places that must not show what is behind them.
 */
@Immutable
class WrtPalette(
    val id: String,
    val label: String,
    val isLight: Boolean,
    val auroraTop: Color,
    val auroraBottom: Color,
    val blobA: Color,
    val blobB: Color,
    val blobC: Color,
    val bgScreen: Color,
    val bgSolid: Color,
    val bgBar: Color,
    val bgDeep: Color,
    val bgCard: Color,
    val bgCardDim: Color,
    val bgSheet: Color,
    val bgDialog: Color,
    val bgCode: Color,
    val bgPendingBar: Color,
    val glassEdgeHi: Color,
    val glassEdgeLo: Color,
    val glassSheen: Color,
    val scrim: Color,
    val borderHair: Color,
    val borderCard: Color,
    val borderInput: Color,
    val borderIcon: Color,
    val borderRow: Color,
    val borderFaint: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val textDim: Color,
    val textFaint: Color,
    val textLogToken: Color,
    val accent: Color,
    val onAccent: Color,
    val green: Color,
    val amber: Color,
    val amberText: Color,
    val red: Color,
    val blue: Color,
    val knobOff: Color,
    val trackOff: Color,
    val trackOffBorder: Color,
    val dotOff: Color,
    val progressTrack: Color,
    val sparkDim: Color,
    val termBg: Color,
    val termBarBg: Color,
    val termBorder: Color,
    val termText: Color,
    val termTabActive: Color,
    val termTabBorder: Color,
    val termKeyBg: Color,
    val termKeyAltBg: Color,
    val termExtraKeyBg: Color,
    val termExtraKeyBorder: Color,
    val termKeyText: Color,
    val termExtraKeyText: Color,
    val termRowBg: Color,
    val termRowBorder: Color,
    val dangerBg: Color,
    val dangerCode: Color,
    val dangerCodeBg: Color,
    val dangerCodeBorder: Color,
    val dangerText: Color,
    val dangerBody: Color,
    val dangerDim: Color,
    val dangerMono: Color,
    val dangerSub: Color,
    val dangerOutlineText: Color,
    val dangerLoss: Color,
    val accentBody: Color,
    val onRed: Color,
)

/** The colour the current theme paints with. Properties keep the names the screens already use. */
object Wrt {
    /**
     * The palette in force: the mode (light / dark / follow the system) and the accent the user
     * chose. It reads Compose state inside [ThemeStore], so a change recomposes every reader.
     */
    val palette: WrtPalette get() = ThemeStore.current()

    val AuroraTop: Color get() = palette.auroraTop
    val AuroraBottom: Color get() = palette.auroraBottom
    val BlobA: Color get() = palette.blobA
    val BlobB: Color get() = palette.blobB
    val BlobC: Color get() = palette.blobC
    val BgScreen: Color get() = palette.bgScreen
    val BgSolid: Color get() = palette.bgSolid
    val BgBar: Color get() = palette.bgBar
    val BgDeep: Color get() = palette.bgDeep
    val BgCard: Color get() = palette.bgCard
    val BgCardDim: Color get() = palette.bgCardDim
    val BgSheet: Color get() = palette.bgSheet
    val BgDialog: Color get() = palette.bgDialog
    val BgCode: Color get() = palette.bgCode
    val BgPendingBar: Color get() = palette.bgPendingBar
    val GlassEdgeHi: Color get() = palette.glassEdgeHi
    val GlassEdgeLo: Color get() = palette.glassEdgeLo
    val GlassSheen: Color get() = palette.glassSheen
    val Scrim: Color get() = palette.scrim
    val BorderHair: Color get() = palette.borderHair
    val BorderCard: Color get() = palette.borderCard
    val BorderInput: Color get() = palette.borderInput
    val BorderIcon: Color get() = palette.borderIcon
    val BorderRow: Color get() = palette.borderRow
    val BorderFaint: Color get() = palette.borderFaint
    val TextPrimary: Color get() = palette.textPrimary
    val TextSecondary: Color get() = palette.textSecondary
    val TextTertiary: Color get() = palette.textTertiary
    val TextDim: Color get() = palette.textDim
    val TextFaint: Color get() = palette.textFaint
    val TextLogToken: Color get() = palette.textLogToken
    val Accent: Color get() = palette.accent
    val OnAccent: Color get() = palette.onAccent
    val Green: Color get() = palette.green
    val Amber: Color get() = palette.amber
    val AmberText: Color get() = palette.amberText
    val Red: Color get() = palette.red
    val Blue: Color get() = palette.blue
    val KnobOff: Color get() = palette.knobOff
    val TrackOff: Color get() = palette.trackOff
    val TrackOffBorder: Color get() = palette.trackOffBorder
    val DotOff: Color get() = palette.dotOff
    val ProgressTrack: Color get() = palette.progressTrack
    val SparkDim: Color get() = palette.sparkDim
    val TermBg: Color get() = palette.termBg
    val TermBarBg: Color get() = palette.termBarBg
    val TermBorder: Color get() = palette.termBorder
    val TermText: Color get() = palette.termText
    val TermTabActive: Color get() = palette.termTabActive
    val TermTabBorder: Color get() = palette.termTabBorder
    val TermKeyBg: Color get() = palette.termKeyBg
    val TermKeyAltBg: Color get() = palette.termKeyAltBg
    val TermExtraKeyBg: Color get() = palette.termExtraKeyBg
    val TermExtraKeyBorder: Color get() = palette.termExtraKeyBorder
    val TermKeyText: Color get() = palette.termKeyText
    val TermExtraKeyText: Color get() = palette.termExtraKeyText
    val TermRowBg: Color get() = palette.termRowBg
    val TermRowBorder: Color get() = palette.termRowBorder
    val DangerBg: Color get() = palette.dangerBg
    val DangerCode: Color get() = palette.dangerCode
    val DangerCodeBg: Color get() = palette.dangerCodeBg
    val DangerCodeBorder: Color get() = palette.dangerCodeBorder
    val DangerText: Color get() = palette.dangerText
    val DangerBody: Color get() = palette.dangerBody
    val DangerDim: Color get() = palette.dangerDim
    val DangerMono: Color get() = palette.dangerMono
    val DangerSub: Color get() = palette.dangerSub
    val DangerOutlineText: Color get() = palette.dangerOutlineText
    val DangerLoss: Color get() = palette.dangerLoss
    val AccentBody: Color get() = palette.accentBody
    val OnRed: Color get() = palette.onRed
}

// ---- building a glass palette -------------------------------------------------------------

private val Ink = Color(0xFF0F172A)
private val White = Color.White
private val Black = Color.Black

/** One accent colour, in the shade that suits each mode (the dark mode's is brighter). */
@Immutable
class WrtAccent(val id: String, val label: String, val onDark: Color, val onLight: Color)

private fun build(dark: Boolean, accentChoice: WrtAccent): WrtPalette {
    val accent = if (dark) accentChoice.onDark else accentChoice.onLight
    val id = (if (dark) "dark-" else "light-") + accentChoice.id
    val label = (if (dark) "Dark · " else "Light · ") + accentChoice.label
    return if (dark) {
        val top = Color(0xFF061224)
        val bottom = Color(0xFF02060D)
        WrtPalette(
            id = id, label = label, isLight = false,
            auroraTop = top, auroraBottom = bottom,
            blobA = accent.copy(alpha = 0.26f),
            blobB = Color(0xFF8B5CF6).copy(alpha = 0.16f),
            blobC = accent.copy(alpha = 0.12f),
            bgScreen = Color.Transparent,
            bgSolid = lerp(top, bottom, 0.5f),
            bgBar = Color(0xFF040C18).copy(alpha = 0.72f),
            bgDeep = Black.copy(alpha = 0.28f),
            bgCard = Color(0xFFBFE9FF).copy(alpha = 0.06f),
            bgCardDim = White.copy(alpha = 0.03f),
            bgSheet = Color(0xFF0A1626).copy(alpha = 0.98f),
            bgDialog = Color(0xFF0C1A2D).copy(alpha = 0.99f),
            bgCode = Black.copy(alpha = 0.36f),
            bgPendingBar = accent.copy(alpha = 0.12f),
            glassEdgeHi = lerp(White, accent, 0.45f).copy(alpha = 0.42f),
            glassEdgeLo = accent.copy(alpha = 0.05f),
            glassSheen = lerp(White, accent, 0.3f).copy(alpha = 0.07f),
            scrim = Color(0xB3020409),
            borderHair = White.copy(alpha = 0.07f),
            borderCard = White.copy(alpha = 0.10f),
            borderInput = White.copy(alpha = 0.16f),
            borderIcon = White.copy(alpha = 0.13f),
            borderRow = White.copy(alpha = 0.06f),
            borderFaint = White.copy(alpha = 0.10f),
            textPrimary = Color(0xFFEAF6FF),
            textSecondary = Color(0xFFA9C3D8),
            textTertiary = Color(0xFF9AA7B9),
            textDim = Color(0xFF7886A0),
            textFaint = Color(0xFF52607A),
            textLogToken = Color(0xFFE2E8F0),
            accent = accent, onAccent = Color(0xFF04121A),
            green = Color(0xFF3CF2A5), amber = Color(0xFFFFC857), amberText = Color(0xFFEBD9B0),
            red = Color(0xFFFF5C7A), blue = Color(0xFF5AA9FF),
            knobOff = Color(0xFF7886A0),
            trackOff = White.copy(alpha = 0.09f),
            trackOffBorder = White.copy(alpha = 0.16f),
            dotOff = White.copy(alpha = 0.20f),
            progressTrack = White.copy(alpha = 0.09f),
            sparkDim = White.copy(alpha = 0.10f),
            termBg = Color(0xFF000000), termBarBg = Color(0xFF050505), termBorder = Color(0xFF161616),
            termText = Color(0xFFD7E4DE), termTabActive = Color(0xFF141D1A), termTabBorder = Color(0xFF1E1E1E),
            termKeyBg = Color(0xFF141414), termKeyAltBg = Color(0xFF1D1D1D), termExtraKeyBg = Color(0xFF151515),
            termExtraKeyBorder = Color(0xFF242424), termKeyText = Color(0xFF9DB0A8),
            termExtraKeyText = Color(0xFFC3D2CC), termRowBg = Color(0xFF0A0A0A), termRowBorder = Color(0xFF1C1C1C),
            dangerBg = Color(0xFF150D0B), dangerCode = Color(0xFF100B0A), dangerCodeBg = Color(0xFF0A0706),
            dangerCodeBorder = Color(0xFF241512), dangerText = Color(0xFFF0E4E1), dangerBody = Color(0xFFC9ACA6),
            dangerDim = Color(0xFF8A716B), dangerMono = Color(0xFFB9A29C), dangerSub = Color(0xFF9B7A74),
            dangerOutlineText = Color(0xFFD9938A), dangerLoss = Color(0xFFD9B8B2),
            accentBody = lerp(accent, White, 0.55f),
            onRed = Color(0xFF2A0C08),
        )
    } else {
        val top = Color(0xFFF5F7FB)
        val bottom = Color(0xFFE8EDF5)
        WrtPalette(
            id = id, label = label, isLight = true,
            auroraTop = top, auroraBottom = bottom,
            blobA = accent.copy(alpha = 0.14f),
            blobB = accent.copy(alpha = 0.07f),
            blobC = Color(0xFF3B82F6).copy(alpha = 0.08f),
            bgScreen = Color.Transparent,
            bgSolid = lerp(top, bottom, 0.5f),
            bgBar = White.copy(alpha = 0.80f),
            bgDeep = Ink.copy(alpha = 0.045f),
            bgCard = White.copy(alpha = 0.78f),
            bgCardDim = White.copy(alpha = 0.50f),
            bgSheet = Color(0xFFFAFBFE).copy(alpha = 0.99f),
            bgDialog = Color(0xFFFFFFFF).copy(alpha = 0.99f),
            bgCode = Ink.copy(alpha = 0.06f),
            bgPendingBar = accent.copy(alpha = 0.12f),
            glassEdgeHi = White.copy(alpha = 1f),
            glassEdgeLo = Ink.copy(alpha = 0.07f),
            glassSheen = White.copy(alpha = 0.30f),
            scrim = Color(0x590F172A),
            borderHair = Ink.copy(alpha = 0.07f),
            borderCard = Ink.copy(alpha = 0.10f),
            borderInput = Ink.copy(alpha = 0.18f),
            borderIcon = Ink.copy(alpha = 0.14f),
            borderRow = Ink.copy(alpha = 0.06f),
            borderFaint = Ink.copy(alpha = 0.10f),
            textPrimary = Color(0xFF0F172A),
            textSecondary = Color(0xFF334155),
            textTertiary = Color(0xFF475569),
            textDim = Color(0xFF64748B),
            textFaint = Color(0xFF94A3B8),
            textLogToken = Color(0xFF0F172A),
            accent = accent, onAccent = White,
            green = Color(0xFF16A34A), amber = Color(0xFFB45309), amberText = Color(0xFF78350F),
            red = Color(0xFFDC2626), blue = Color(0xFF2563EB),
            knobOff = Color(0xFF94A3B8),
            trackOff = Ink.copy(alpha = 0.10f),
            trackOffBorder = Ink.copy(alpha = 0.16f),
            dotOff = Ink.copy(alpha = 0.20f),
            progressTrack = Ink.copy(alpha = 0.09f),
            sparkDim = Ink.copy(alpha = 0.10f),
            termBg = Color(0xFF000000), termBarBg = Color(0xFF050505), termBorder = Color(0xFF161616),
            termText = Color(0xFFD7E4DE), termTabActive = Color(0xFF141D1A), termTabBorder = Color(0xFF1E1E1E),
            termKeyBg = Color(0xFF141414), termKeyAltBg = Color(0xFF1D1D1D), termExtraKeyBg = Color(0xFF151515),
            termExtraKeyBorder = Color(0xFF242424), termKeyText = Color(0xFF9DB0A8),
            termExtraKeyText = Color(0xFFC3D2CC), termRowBg = Color(0xFF0A0A0A), termRowBorder = Color(0xFF1C1C1C),
            dangerBg = Color(0xFFFCEFEC), dangerCode = Color(0xFFF6DDD8), dangerCodeBg = Color(0xFFF3D3CD),
            dangerCodeBorder = Color(0xFFE5B3AA), dangerText = Color(0xFF3A1511), dangerBody = Color(0xFF6B3A33),
            dangerDim = Color(0xFF946A63), dangerMono = Color(0xFF7A4F48), dangerSub = Color(0xFF8A5A53),
            dangerOutlineText = Color(0xFFB2392B), dangerLoss = Color(0xFF6B3A33),
            accentBody = lerp(accent, Ink, 0.45f),
            onRed = White,
        )
    }
}

/** The colours on offer. Light or dark is chosen separately, in [ThemeStore]. */
object WrtThemes {
    val accents: List<WrtAccent> = listOf(
        WrtAccent("cyan", "Sonar Cyan", Color(0xFF22E5FF), Color(0xFF0891B2)),
        WrtAccent("plasma", "Plasma", Color(0xFFB57BFF), Color(0xFF7C3AED)),
        WrtAccent("reef", "Reef", Color(0xFF3CF2A5), Color(0xFF059669)),
        WrtAccent("solar", "Solar", Color(0xFFFFA24A), Color(0xFFEA580C)),
        WrtAccent("coral", "Coral", Color(0xFFFF5C8A), Color(0xFFE11D48)),
        WrtAccent("ice", "Ice", Color(0xFF6AA8FF), Color(0xFF2563EB)),
    )

    fun accentById(id: String?): WrtAccent = accents.firstOrNull { it.id == id } ?: accents.first()

    private val cache = HashMap<String, WrtPalette>()

    /** One palette per (mode, accent) pair, built once. */
    fun palette(dark: Boolean, accent: WrtAccent): WrtPalette =
        cache.getOrPut((if (dark) "d-" else "l-") + accent.id) { build(dark, accent) }
}
