#!/usr/bin/env python3
"""Patch the flutter-created android/ folder for Romeo & Juliet (mobile).

Run from the project root AFTER `flutter create`:   python3 tools/patch_manifest.py mobile

 * restarts from AndroidManifest.xml.orig (safe to run repeatedly)
 * sets android:label
 * copies launcher icons into android/app/src/main/res
 * writes MainActivity.kt (MethodChannel "app/native": lowEnd, getString, setString)
 * removes any <uses-permission> from the main manifest (app is fully offline)
"""
import glob
import os
import re
import shutil
import sys

APP_LABEL = "Romeo & Juliet"
PACKAGE = "com.maraj.romeo_juliet"

ROOT = os.getcwd()
MAIN = os.path.join(ROOT, "android", "app", "src", "main")
MANIFEST = os.path.join(MAIN, "AndroidManifest.xml")
ORIG = MANIFEST + ".orig"
ICONS = os.path.join(ROOT, "assets", "android_icons")

KOTLIN = """package %s

import android.app.ActivityManager
import android.content.Context
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val prefs = getSharedPreferences("rj", Context.MODE_PRIVATE)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "app/native")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "lowEnd" -> {
                        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                        result.success(am.isLowRamDevice || am.memoryClass < 192)
                    }
                    "getString" -> {
                        val key = call.argument<String>("key") ?: ""
                        result.success(prefs.getString(key, null))
                    }
                    "setString" -> {
                        val key = call.argument<String>("key") ?: ""
                        val value = call.argument<String>("value") ?: ""
                        prefs.edit().putString(key, value).apply()
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
""" % PACKAGE


def main():
    if not os.path.isfile(MANIFEST) and not os.path.isfile(ORIG):
        sys.exit("android/ not found - run `flutter create` first")

    # 1. repeat-safe: always start from the pristine manifest
    if not os.path.isfile(ORIG):
        shutil.copyfile(MANIFEST, ORIG)
    with open(ORIG, encoding="utf-8") as f:
        xml = f.read()

    # 2. label (the main manifest has exactly one <application>)
    xml, n = re.subn(r'android:label="[^"]*"', 'android:label="%s"' % APP_LABEL.replace("&", "&amp;"), xml, count=1)
    if n != 1:
        sys.exit("could not find android:label in the manifest")

    # 3. zero permissions
    xml = re.sub(r"[ \t]*<uses-permission[^>]*/>\s*\n?", "", xml)

    with open(MANIFEST, "w", encoding="utf-8") as f:
        f.write(xml)

    # 4. icons
    res = os.path.join(MAIN, "res")
    for d in sorted(glob.glob(os.path.join(ICONS, "mipmap-*"))):
        dst = os.path.join(res, os.path.basename(d))
        os.makedirs(dst, exist_ok=True)
        for png in glob.glob(os.path.join(d, "*.png")):
            shutil.copy(png, dst)
        # drop any adaptive-icon xml that would shadow our png
    for p in glob.glob(os.path.join(res, "mipmap-anydpi*", "ic_launcher*.xml")):
        os.remove(p)

    # 5. MainActivity.kt (remove any generated MainActivity first)
    for p in glob.glob(os.path.join(MAIN, "**", "MainActivity.*"), recursive=True):
        os.remove(p)
    kt_dir = os.path.join(MAIN, "kotlin", *PACKAGE.split("."))
    os.makedirs(kt_dir, exist_ok=True)
    with open(os.path.join(kt_dir, "MainActivity.kt"), "w", encoding="utf-8") as f:
        f.write(KOTLIN)

    print("patched: label=%s package=%s" % (APP_LABEL, PACKAGE))


if __name__ == "__main__":
    main()
