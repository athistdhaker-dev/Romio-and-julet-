import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core.dart';
import 'engine.dart';
import 'game_view.dart';
import 'glass.dart';
import 'levels.dart';
import 'legal.dart';
import 'pages.dart';
import 'ui.dart';

/// Home: glass bottom navigation with Levels and About tabs.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            const OrbBackground(),
            Scaffold(
              backgroundColor: Colors.transparent,
              extendBody: true,
              body: SafeArea(
                bottom: false,
                child: IndexedStack(
                  index: _tab,
                  children: const <Widget>[LevelsPage(), AboutPage()],
                ),
              ),
              bottomNavigationBar: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: GlassPanel(
                    radius: 28,
                    child: NavigationBar(
                      height: 68,
                      backgroundColor: Colors.transparent,
                      elevation: 0,
                      indicatorColor: const Color(0x33FFFFFF),
                      selectedIndex: _tab,
                      onDestinationSelected: (i) => setState(() => _tab = i),
                      destinations: const <NavigationDestination>[
                        NavigationDestination(
                          icon: Icon(Icons.favorite_border_rounded),
                          selectedIcon: Icon(Icons.favorite_rounded),
                          label: 'Levels',
                        ),
                        NavigationDestination(
                          icon: Icon(Icons.info_outline_rounded),
                          selectedIcon: Icon(Icons.info_rounded),
                          label: 'About',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class LevelsPage extends StatelessWidget {
  const LevelsPage({super.key});

  void _open(BuildContext context, int index) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => GameScreen(levelIndex: index)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = AppState.instance.progress;
    return LayoutBuilder(
      builder: (context, box) {
        final cols = math.max(3, math.min(8, box.maxWidth ~/ 110));
        return CustomScrollView(
          slivers: <Widget>[
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const GradientTitle(kAppName),
                    const SizedBox(height: 4),
                    Text(
                      'Bring the lovers together  -  ${progress.completed}/${kLevels.length} done',
                      style: kBodyStyle,
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
              sliver: SliverGrid(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: cols,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.9,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, i) => _LevelTile(
                    index: i,
                    unlocked: progress.isUnlocked(i),
                    best: progress.best[i],
                    onTap: () => _open(context, i),
                  ),
                  childCount: kLevels.length,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _LevelTile extends StatelessWidget {
  const _LevelTile({
    required this.index,
    required this.unlocked,
    required this.best,
    required this.onTap,
  });

  final int index;
  final bool unlocked;
  final int best;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final level = kLevels[index];
    return GlassButton(
      enabled: unlocked,
      active: best > 0,
      radius: 22,
      onPressed: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (unlocked)
            Text(
              '${index + 1}',
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white),
            )
          else
            const Icon(Icons.lock_rounded, color: Colors.white70, size: 26),
          const SizedBox(height: 6),
          StarsRow(stars: best > 0 ? starsFor(level.par, best) : 0, size: 16),
        ],
      ),
    );
  }
}

/// The game screen: HUD, board and controls. Adapts to portrait / landscape.
class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.levelIndex});

  final int levelIndex;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late final GameController _c = GameController(widget.levelIndex);
  final FocusNode _focus = FocusNode();

  @override
  void dispose() {
    _c.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _move(Dir d) {
    final moved = _c.move(d);
    if (!moved) {
      HapticFeedback.lightImpact();
      return;
    }
    final status = _c.state.status;
    if (status == GameStatus.won) {
      HapticFeedback.mediumImpact();
    } else if (status == GameStatus.lost) {
      HapticFeedback.heavyImpact();
    } else {
      HapticFeedback.selectionClick();
    }
  }

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (e is! KeyDownEvent && e is! KeyRepeatEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    if (k == LogicalKeyboardKey.arrowUp) {
      _move(Dir.up);
    } else if (k == LogicalKeyboardKey.arrowDown) {
      _move(Dir.down);
    } else if (k == LogicalKeyboardKey.arrowLeft) {
      _move(Dir.left);
    } else if (k == LogicalKeyboardKey.arrowRight) {
      _move(Dir.right);
    } else if (k == LogicalKeyboardKey.keyZ || k == LogicalKeyboardKey.backspace) {
      _c.undo();
    } else if (k == LogicalKeyboardKey.keyR) {
      _c.restart();
    } else {
      return KeyEventResult.ignored;
    }
    return KeyEventResult.handled;
  }

  void _next() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => GameScreen(levelIndex: widget.levelIndex + 1)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Focus(
      focusNode: _focus,
      autofocus: true,
      onKeyEvent: _onKey,
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          const OrbBackground(),
          Scaffold(
            backgroundColor: Colors.transparent,
            body: SafeArea(
              child: ListenableBuilder(
                listenable: _c,
                builder: (context, _) => LayoutBuilder(
                  builder: (context, box) {
                    final wide = box.maxWidth > box.maxHeight * 1.15;
                    final hud = _Hud(controller: _c, onBack: () => Navigator.of(context).maybePop());
                    final board = Padding(
                      padding: const EdgeInsets.all(12),
                      child: GameBoard(controller: _c, onMove: _move),
                    );
                    final controls = _Controls(
                      vertical: wide,
                      canUndo: _c.canUndo,
                      onMove: _move,
                      onUndo: _c.undo,
                      onRestart: _c.restart,
                    );
                    final content = wide
                        ? Row(
                            children: <Widget>[
                              Expanded(
                                child: Column(
                                  children: <Widget>[hud, Expanded(child: board)],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 12),
                                child: Center(child: controls),
                              ),
                            ],
                          )
                        : Column(
                            children: <Widget>[
                              hud,
                              Expanded(child: board),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                                child: controls,
                              ),
                            ],
                          );
                    final over = _c.state.status != GameStatus.playing;
                    return Stack(
                      fit: StackFit.expand,
                      children: <Widget>[
                        content,
                        if (over)
                          _EndOverlay(
                            controller: _c,
                            onNext: _next,
                            onLevels: () => Navigator.of(context).maybePop(),
                          ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Hud extends StatelessWidget {
  const _Hud({required this.controller, required this.onBack});

  final GameController controller;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final level = controller.level;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              GlassButton(
                width: 48,
                height: 48,
                radius: 24,
                onPressed: onBack,
                child: const Icon(Icons.arrow_back_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Level ${controller.levelIndex + 1}  -  ${level.name}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
                    ),
                    Text(
                      'Moves ${controller.state.moves}   Best possible ${level.par}',
                      style: const TextStyle(fontSize: 13, color: Color(0xBBFFFFFF)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (level.hint.isNotEmpty && controller.state.moves == 0)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                level.hint,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, color: Color(0xCCFFFFFF)),
              ),
            ),
        ],
      ),
    );
  }
}

/// D-pad plus Undo/Restart inside ONE glass panel (one blur).
class _Controls extends StatelessWidget {
  const _Controls({
    required this.vertical,
    required this.canUndo,
    required this.onMove,
    required this.onUndo,
    required this.onRestart,
  });

  final bool vertical;
  final bool canUndo;
  final void Function(Dir) onMove;
  final VoidCallback onUndo;
  final VoidCallback onRestart;

  Widget _arrow(IconData icon, Dir d) {
    return GlassButton(
      width: 58,
      height: 58,
      radius: 18,
      repeat: true,
      onPressed: () => onMove(d),
      child: Icon(icon, color: Colors.white, size: 32),
    );
  }

  @override
  Widget build(BuildContext context) {
    const gap = SizedBox(width: 58, height: 58);
    final dpad = Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[gap, _arrow(Icons.keyboard_arrow_up_rounded, Dir.up), gap],
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            _arrow(Icons.keyboard_arrow_left_rounded, Dir.left),
            const SizedBox(
              width: 58,
              height: 58,
              child: Icon(Icons.favorite_rounded, color: Color(0x66FFFFFF), size: 22),
            ),
            _arrow(Icons.keyboard_arrow_right_rounded, Dir.right),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[gap, _arrow(Icons.keyboard_arrow_down_rounded, Dir.down), gap],
        ),
      ],
    );
    final actions = <Widget>[
      GlassButton(
        width: 58,
        height: 58,
        radius: 18,
        enabled: canUndo,
        onPressed: onUndo,
        child: const Icon(Icons.undo_rounded, color: Colors.white),
      ),
      const SizedBox(width: 12, height: 12),
      GlassButton(
        width: 58,
        height: 58,
        radius: 18,
        onPressed: onRestart,
        child: const Icon(Icons.refresh_rounded, color: Colors.white),
      ),
    ];
    return GlassPanel(
      radius: 28,
      padding: const EdgeInsets.all(14),
      child: vertical
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                dpad,
                const SizedBox(height: 12),
                Row(mainAxisSize: MainAxisSize.min, children: actions),
              ],
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                dpad,
                Column(mainAxisSize: MainAxisSize.min, children: actions),
              ],
            ),
    );
  }
}

class _EndOverlay extends StatelessWidget {
  const _EndOverlay({
    required this.controller,
    required this.onNext,
    required this.onLevels,
  });

  final GameController controller;
  final VoidCallback onNext;
  final VoidCallback onLevels;

  @override
  Widget build(BuildContext context) {
    final s = controller.state;
    final won = s.status == GameStatus.won;
    return ColoredBox(
      color: const Color(0x88000000),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 340),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: GlassPanel(
              radius: 28,
              padding: const EdgeInsets.all(22),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: won
                    ? <Widget>[
                        const Icon(Icons.favorite_rounded, color: Color(0xFFFF4D7A), size: 44),
                        const SizedBox(height: 8),
                        const Text(
                          'They are together!',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
                        ),
                        const SizedBox(height: 10),
                        Center(child: StarsRow(stars: controller.stars, size: 34)),
                        const SizedBox(height: 6),
                        Text(
                          '${s.moves} moves  (best possible ${controller.level.par})',
                          textAlign: TextAlign.center,
                          style: kBodyStyle,
                        ),
                        const SizedBox(height: 18),
                        if (controller.hasNextLevel) ...<Widget>[
                          GlassTextButton(
                            label: 'Next level',
                            icon: Icons.arrow_forward_rounded,
                            primary: true,
                            onPressed: onNext,
                          ),
                          const SizedBox(height: 10),
                        ],
                        GlassTextButton(
                          label: 'Play again',
                          icon: Icons.refresh_rounded,
                          onPressed: controller.restart,
                        ),
                        const SizedBox(height: 10),
                        GlassTextButton(
                          label: 'All levels',
                          icon: Icons.grid_view_rounded,
                          onPressed: onLevels,
                        ),
                      ]
                    : <Widget>[
                        const Icon(Icons.warning_amber_rounded, color: Color(0xFFFFB86B), size: 44),
                        const SizedBox(height: 8),
                        const Text(
                          'Ouch, thorns!',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white),
                        ),
                        const SizedBox(height: 18),
                        GlassTextButton(
                          label: 'Undo',
                          icon: Icons.undo_rounded,
                          primary: true,
                          onPressed: controller.undo,
                        ),
                        const SizedBox(height: 10),
                        GlassTextButton(
                          label: 'Restart',
                          icon: Icons.refresh_rounded,
                          onPressed: controller.restart,
                        ),
                      ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
