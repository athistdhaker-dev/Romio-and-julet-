// Pure Dart save-data model: best move count per level (0 = not completed).

class Progress {
  const Progress(this.best);

  factory Progress.empty(int levels) =>
      Progress(List<int>.filled(levels, 0));

  factory Progress.decode(String? text, int levels) {
    final out = List<int>.filled(levels, 0);
    if (text != null && text.isNotEmpty) {
      final parts = text.split(',');
      for (var i = 0; i < parts.length && i < levels; i++) {
        final v = int.tryParse(parts[i]) ?? 0;
        out[i] = v < 0 ? 0 : v;
      }
    }
    return Progress(out);
  }

  final List<int> best;

  bool isDone(int i) => i >= 0 && i < best.length && best[i] > 0;

  bool isUnlocked(int i) => i == 0 || isDone(i - 1);

  int get completed {
    var n = 0;
    for (final b in best) {
      if (b > 0) n++;
    }
    return n;
  }

  /// Returns a new Progress with [moves] stored if it beats the old best.
  Progress record(int i, int moves) {
    if (i < 0 || i >= best.length || moves <= 0) return this;
    final old = best[i];
    if (old > 0 && old <= moves) return this;
    final copy = List<int>.from(best);
    copy[i] = moves;
    return Progress(copy);
  }

  String encode() => best.join(',');
}
