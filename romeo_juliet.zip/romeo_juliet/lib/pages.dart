import 'package:flutter/material.dart';

import 'glass.dart';
import 'legal.dart';
import 'ui.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  void _showText(BuildContext context, String title, String body) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(child: Text(body)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Close')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 110),
      children: <Widget>[
        const GradientTitle('About'),
        const SizedBox(height: 4),
        const Text('$kAppName  v$kVersion', style: kBodyStyle),
        const SizedBox(height: 16),
        const GlassPanel(
          padding: EdgeInsets.all(18),
          child: Text(kHowToPlay, style: kBodyStyle),
        ),
        const SizedBox(height: 16),
        GlassTextButton(
          label: 'Privacy Policy',
          icon: Icons.privacy_tip_outlined,
          onPressed: () => _showText(context, 'Privacy Policy', kPrivacyPolicy),
        ),
        const SizedBox(height: 10),
        GlassTextButton(
          label: 'Terms & Conditions',
          icon: Icons.gavel_outlined,
          onPressed: () => _showText(context, 'Terms & Conditions', kTerms),
        ),
        const SizedBox(height: 10),
        GlassTextButton(
          label: 'Open-source licenses',
          icon: Icons.article_outlined,
          onPressed: () => showLicensePage(
            context: context,
            applicationName: kAppName,
            applicationVersion: kVersion,
          ),
        ),
      ],
    );
  }
}
