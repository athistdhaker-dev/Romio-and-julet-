// App identity and legal text. Edit the placeholders here, in one place.

const String kAppName = 'Romeo & Juliet';
const String kVersion = '1.0.0'; // keep in sync with pubspec.yaml
const String kLastUpdated = '6 October 2026';

// TODO: fill these in before publishing to any store.
const String kContactName = '<your name>';
const String kContactEmail = '<your email>';

const String kPrivacyPolicy = '''
Privacy Policy (last updated $kLastUpdated)

$kAppName is an offline puzzle game. It does not collect, store or share any personal information, does not use the internet, and contains no ads, analytics or third-party SDKs.

The only data stored is your level progress (best move count per level), which is kept privately on your device and is removed when you uninstall the app.

Contact: $kContactName, $kContactEmail
''';

const String kTerms = '''
Terms & Conditions (last updated $kLastUpdated)

This game is provided "as is", without warranty of any kind. You may use it for personal, non-commercial entertainment. The game is an original work inspired by the classic story of Romeo and Juliet and is not affiliated with any other game.

Contact: $kContactName, $kContactEmail
''';

const String kHowToPlay = '''
How to play

- Romeo moves in the direction you choose.
- Juliet moves the same way up and down, but MIRRORED left and right.
- A hero blocked by a wall stays put while the other keeps moving.
- Thorns end the level, so use Undo or Restart.
- Get Romeo and Juliet onto the same tile (or let them cross) to win.

Controls: on-screen D-pad, swipe on the board, or arrow keys. Fewer moves earn more stars.
''';
