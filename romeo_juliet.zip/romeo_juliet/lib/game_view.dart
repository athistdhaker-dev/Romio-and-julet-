import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'core.dart';
import 'engine.dart';
import 'glass.dart';

/// Draws the level and both heroes. Positions animate from [fromR]/[fromJ]
/// to [toR]/[toJ] as [t] goes 0 -> 1.
class BoardPainter extends CustomPainter {
  BoardPainter({
    required this.level,
    required this.fromR,
    required this.fromJ,
    required this.toR,
    required this.toJ,
    required this.t,
    required this.status,
  });

  final Level level;
  final Pos fromR;
  final Pos fromJ;
  final Pos toR;
  final Pos toJ;
  final double t;
  final GameStatus status;

  @override
  void paint(Canvas canvas, Size size) {
    final cs = math.min(size.width / level.width, size.height / level.height);
    final ox = (size.width - cs * level.width) / 2;
    final oy = (size.height - cs * level.height) / 2;

    final floorA = Paint()..color = const Color(0x16FFFFFF);
    final floorB = Paint()..color = const Color(0x0DFFFFFF);
    final wall = Paint()..color = const Color(0xFF2E2358);
    final wallTop = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.0, cs * 0.04)
      ..color = const Color(0x55FFFFFF);
    final thornTint = Paint()..color = const Color(0x22EC5678);
    final spike = Paint()..color = kPink;

    for (var y = 0; y < level.height; y++) {
      for (var x = 0; x < level.width; x++) {
        final rect = Rect.fromLTWH(ox + x * cs, oy + y * cs, cs, cs).deflate(cs * 0.04);
        final rr = RRect.fromRectAndRadius(rect, Radius.circular(cs * 0.18));
        if (level.isWall(x, y)) {
          canvas.drawRRect(rr, wall);
          canvas.drawLine(
            Offset(rect.left + cs * 0.14, rect.top + cs * 0.06),
            Offset(rect.right - cs * 0.14, rect.top + cs * 0.06),
            wallTop,
          );
        } else {
          canvas.drawRRect(rr, (x + y).isEven ? floorA : floorB);
          if (level.isThorn(x, y)) {
            canvas.drawRRect(rr, thornTint);
            final p = Path();
            const n = 3;
            final w = rect.width / n;
            for (var i = 0; i < n; i++) {
              final bx = rect.left + i * w;
              p.moveTo(bx + w * 0.08, rect.bottom - rect.height * 0.18);
              p.lineTo(bx + w / 2, rect.top + rect.height * 0.22);
              p.lineTo(bx + w * 0.92, rect.bottom - rect.height * 0.18);
              p.close();
            }
            canvas.drawPath(p, spike);
          }
        }
      }
    }

    final e = Curves.easeOutCubic.transform(math.min(1.0, math.max(0.0, t)));
    Offset centerOf(Pos a, Pos b) => Offset(
          ox + (a.x + (b.x - a.x) * e + 0.5) * cs,
          oy + (a.y + (b.y - a.y) * e + 0.5) * cs,
        );
    final rc = centerOf(fromR, toR);
    final jc = centerOf(fromJ, toJ);
    final r = cs * 0.34;
    final lost = status == GameStatus.lost;

    _hero(canvas, rc, r, kBlue, false, lost);
    _hero(canvas, jc, r, kPink, true, lost);

    if (status == GameStatus.won) {
      final mid = Offset((rc.dx + jc.dx) / 2, (rc.dy + jc.dy) / 2 - r * 1.7);
      final heart = _heart(mid, r * 0.7);
      canvas.drawPath(heart, Paint()..color = const Color(0xFFFF4D7A));
      canvas.drawPath(
        heart,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * 0.08
          ..color = Colors.white,
      );
    }
  }

  void _hero(Canvas canvas, Offset c, double r, Color color, bool juliet, bool dead) {
    canvas.drawOval(
      Rect.fromCenter(center: c + Offset(0, r * 0.9), width: r * 1.7, height: r * 0.4),
      Paint()..color = const Color(0x55000000),
    );
    final body = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.4, -0.5),
        colors: <Color>[Color.lerp(color, Colors.white, 0.45)!, color],
      ).createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r, body);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = r * 0.08
        ..color = const Color(0x99FFFFFF),
    );

    // Accessory: Romeo wears a cap, Juliet a little heart.
    if (juliet) {
      canvas.drawPath(_heart(c + Offset(0, -r * 1.12), r * 0.32), Paint()..color = const Color(0xFFFFC2D1));
    } else {
      final cap = Path()
        ..moveTo(c.dx - r * 0.7, c.dy - r * 0.55)
        ..lineTo(c.dx, c.dy - r * 1.35)
        ..lineTo(c.dx + r * 0.7, c.dy - r * 0.55)
        ..close();
      canvas.drawPath(cap, Paint()..color = const Color(0xFF1F4FA3));
    }

    final ink = Paint()..color = const Color(0xFF1B1530);
    canvas.drawCircle(c + Offset(-r * 0.32, -r * 0.05), r * 0.11, ink);
    canvas.drawCircle(c + Offset(r * 0.32, -r * 0.05), r * 0.11, ink);
    final mouth = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = r * 0.09
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF1B1530);
    canvas.drawArc(
      Rect.fromCenter(center: c + Offset(0, r * (dead ? 0.38 : 0.22)), width: r * 0.6, height: r * 0.4),
      dead ? math.pi : 0,
      math.pi,
      false,
      mouth,
    );
  }

  Path _heart(Offset c, double s) {
    final p = Path();
    p.moveTo(c.dx, c.dy + s * 0.9);
    p.cubicTo(c.dx - s * 1.6, c.dy - s * 0.1, c.dx - s * 0.9, c.dy - s * 1.2, c.dx, c.dy - s * 0.4);
    p.cubicTo(c.dx + s * 0.9, c.dy - s * 1.2, c.dx + s * 1.6, c.dy - s * 0.1, c.dx, c.dy + s * 0.9);
    p.close();
    return p;
  }

  @override
  bool shouldRepaint(BoardPainter old) => true;
}

/// The animated, swipe-aware game board.
class GameBoard extends StatefulWidget {
  const GameBoard({super.key, required this.controller, required this.onMove});

  final GameController controller;
  final void Function(Dir) onMove;

  @override
  State<GameBoard> createState() => _GameBoardState();
}

class _GameBoardState extends State<GameBoard> with SingleTickerProviderStateMixin {
  late final AnimationController _anim = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 150),
    value: 1,
  );
  late Pos _fromR;
  late Pos _fromJ;
  late Pos _toR;
  late Pos _toJ;
  Offset _acc = Offset.zero;

  @override
  void initState() {
    super.initState();
    final s = widget.controller.state;
    _fromR = s.romeo;
    _toR = s.romeo;
    _fromJ = s.juliet;
    _toJ = s.juliet;
    widget.controller.addListener(_onChange);
  }

  void _onChange() {
    final s = widget.controller.state;
    setState(() {
      _fromR = _toR;
      _fromJ = _toJ;
      _toR = s.romeo;
      _toJ = s.juliet;
    });
    _anim.forward(from: 0);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onChange);
    _anim.dispose();
    super.dispose();
  }

  void _swipe(Offset d) {
    _acc += d;
    if (_acc.distance < 36) return;
    if (_acc.dx.abs() > _acc.dy.abs()) {
      widget.onMove(_acc.dx > 0 ? Dir.right : Dir.left);
    } else {
      widget.onMove(_acc.dy > 0 ? Dir.down : Dir.up);
    }
    _acc = Offset.zero;
  }

  @override
  Widget build(BuildContext context) {
    final level = widget.controller.level;
    final status = widget.controller.state.status;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onPanStart: (_) => _acc = Offset.zero,
      onPanUpdate: (d) => _swipe(d.delta),
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _anim,
          builder: (context, _) => CustomPaint(
            size: Size.infinite,
            painter: BoardPainter(
              level: level,
              fromR: _fromR,
              fromJ: _fromJ,
              toR: _toR,
              toJ: _toJ,
              t: _anim.value,
              status: status,
            ),
          ),
        ),
      ),
    );
  }
}
