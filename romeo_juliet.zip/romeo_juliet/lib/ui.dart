import 'package:flutter/material.dart';

import 'glass.dart';

const TextStyle kTitleStyle = TextStyle(
  fontSize: 30,
  fontWeight: FontWeight.w800,
  letterSpacing: 0.3,
  color: Colors.white,
);

const TextStyle kBodyStyle = TextStyle(
  fontSize: 15,
  height: 1.4,
  color: Color(0xDDFFFFFF),
);

class StarsRow extends StatelessWidget {
  const StarsRow({super.key, required this.stars, this.size = 18});

  final int stars;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        for (var i = 0; i < 3; i++)
          Icon(
            i < stars ? Icons.star_rounded : Icons.star_border_rounded,
            size: size,
            color: i < stars ? const Color(0xFFFFD36E) : const Color(0x66FFFFFF),
          ),
      ],
    );
  }
}

class GradientTitle extends StatelessWidget {
  const GradientTitle(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (Rect r) => const LinearGradient(
        colors: <Color>[kBlue, kPink],
      ).createShader(r),
      child: Text(text, style: kTitleStyle),
    );
  }
}

/// Wide text button in glass style.
class GlassTextButton extends StatelessWidget {
  const GlassTextButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.primary = false,
  });

  final String label;
  final VoidCallback onPressed;
  final IconData? icon;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return GlassButton(
      onPressed: onPressed,
      active: primary,
      height: 52,
      radius: 26,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (icon != null) ...<Widget>[
              Icon(icon, color: Colors.white, size: 20),
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
