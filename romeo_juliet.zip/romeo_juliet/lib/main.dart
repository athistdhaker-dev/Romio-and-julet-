import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core.dart';
import 'glass.dart';
import 'legal.dart';
import 'mobile.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  await AppState.instance.init();
  runApp(const RomeoJulietApp());
}

class RomeoJulietApp extends StatelessWidget {
  const RomeoJulietApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: kPurple, brightness: Brightness.dark),
      ),
      home: const HomeShell(),
    );
  }
}
