import 'dart:async';
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import 'core.dart';

const Color kPurple = Color(0xFF7B2FF7);
const Color kPink = Color(0xFFEC5678);
const Color kBlue = Color(0xFF2FA8F7);
const Color kTeal = Color(0xFF2ED3B7);

/// Dark gradient with soft colour orbs (no blur filters, so it is cheap).
class OrbBackground extends StatelessWidget {
  const OrbBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF16102E), Color(0xFF0A0A18)],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          _Orb(alignment: Alignment(-1.0, -0.85), color: kPurple, size: 380),
          _Orb(alignment: Alignment(1.1, -0.2), color: kPink, size: 320),
          _Orb(alignment: Alignment(-0.9, 0.6), color: kBlue, size: 300),
          _Orb(alignment: Alignment(0.9, 1.0), color: kTeal, size: 340),
        ],
      ),
    );
  }
}

class _Orb extends StatelessWidget {
  const _Orb({required this.alignment, required this.color, required this.size});

  final Alignment alignment;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: alignment,
      child: IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: <Color>[color.withAlpha(120), color.withAlpha(0)],
            ),
          ),
        ),
      ),
    );
  }
}

/// Gradient specular rim plus a soft highlight line along the top edge.
class RimPainter extends CustomPainter {
  const RimPainter({required this.radius, this.strong = false});

  final double radius;
  final bool strong;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final rrect = RRect.fromRectAndRadius(rect.deflate(0.6), Radius.circular(radius));
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strong ? 1.8 : 1.2
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: <Color>[
          Color(strong ? 0xEEFFFFFF : 0x99FFFFFF),
          const Color(0x14FFFFFF),
          const Color(0x0AFFFFFF),
          const Color(0x55FFFFFF),
        ],
        stops: const <double>[0, 0.35, 0.65, 1],
      ).createShader(rect);
    canvas.drawRRect(rrect, rim);

    final lineWidth = size.width - 2 * radius;
    if (lineWidth > 4) {
      final lineRect = Rect.fromLTWH(radius, 0, lineWidth, 1);
      final hl = Paint()
        ..strokeWidth = 1
        ..shader = const LinearGradient(
          colors: <Color>[Color(0x00FFFFFF), Color(0x99FFFFFF), Color(0x00FFFFFF)],
        ).createShader(lineRect);
      canvas.drawLine(Offset(radius, 1.2), Offset(radius + lineWidth, 1.2), hl);
    }
  }

  @override
  bool shouldRepaint(RimPainter old) => old.radius != radius || old.strong != strong;
}

/// A glass panel. Exactly ONE BackdropFilter per panel; children inside should
/// use [GlassButton] / plain translucent fills (no further blur).
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.radius = 24,
    this.padding = EdgeInsets.zero,
    this.blur,
  });

  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final double? blur;

  @override
  Widget build(BuildContext context) {
    final sigma = blur ?? AppState.instance.panelBlur;
    final fill = DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0x33FFFFFF), Color(0x0FFFFFFF)],
        ),
      ),
      child: CustomPaint(
        foregroundPainter: RimPainter(radius: radius),
        child: Padding(padding: padding, child: child),
      ),
    );
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: sigma > 0
          ? BackdropFilter(
              filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
              child: fill,
            )
          : fill,
    );
  }
}

/// Translucent glass button without blur. Supports press-and-hold repeat.
class GlassButton extends StatefulWidget {
  const GlassButton({
    super.key,
    required this.onPressed,
    required this.child,
    this.width,
    this.height,
    this.radius = 20,
    this.repeat = false,
    this.enabled = true,
    this.active = false,
  });

  final VoidCallback onPressed;
  final Widget child;
  final double? width;
  final double? height;
  final double radius;
  final bool repeat;
  final bool enabled;
  final bool active;

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool _down = false;
  Timer? _timer;

  void _start() {
    if (!widget.enabled) return;
    setState(() => _down = true);
    widget.onPressed();
    if (widget.repeat) {
      _timer?.cancel();
      _timer = Timer.periodic(const Duration(milliseconds: 170), (_) {
        if (widget.enabled) widget.onPressed();
      });
    }
  }

  void _stop() {
    _timer?.cancel();
    _timer = null;
    if (_down && mounted) setState(() => _down = false);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final constraints = BoxConstraints(
      minWidth: widget.width ?? 48,
      maxWidth: widget.width ?? double.infinity,
      minHeight: widget.height ?? 48,
      maxHeight: widget.height ?? double.infinity,
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => _start(),
      onTapUp: (_) => _stop(),
      onTapCancel: _stop,
      child: Opacity(
        opacity: widget.enabled ? 1 : 0.4,
        child: AnimatedScale(
          scale: _down ? 0.93 : 1,
          duration: const Duration(milliseconds: 90),
          child: ConstrainedBox(
            constraints: constraints,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(widget.radius),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: _down || widget.active
                      ? const <Color>[Color(0x66FFFFFF), Color(0x26FFFFFF)]
                      : const <Color>[Color(0x2EFFFFFF), Color(0x0EFFFFFF)],
                ),
              ),
              child: CustomPaint(
                foregroundPainter: RimPainter(
                  radius: widget.radius,
                  strong: _down || widget.active,
                ),
                child: Center(child: widget.child),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
