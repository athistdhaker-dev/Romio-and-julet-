// Pure Dart game rules. No Flutter imports, so it can be unit-tested directly.
//
// Rules:
//  * Romeo moves in the pressed direction.
//  * Juliet moves vertically the same way, but horizontally MIRRORED.
//  * A hero blocked by a wall stays in place; the other one still moves.
//  * Stepping on a thorn loses the level (undo or restart).
//  * They meet when they land on the same cell or swap places.

enum Dir { up, down, left, right }

enum GameStatus { playing, won, lost }

class Pos {
  const Pos(this.x, this.y);

  final int x;
  final int y;

  @override
  bool operator ==(Object other) => other is Pos && other.x == x && other.y == y;

  @override
  int get hashCode => x * 1009 + y;

  @override
  String toString() => 'Pos($x,$y)';
}

class Level {
  Level({required this.name, required this.rows, this.hint = ''})
      : width = _maxLen(rows),
        height = rows.length,
        romeoStart = _find(rows, 'R'),
        julietStart = _find(rows, 'J');

  final String name;
  final String hint;
  final List<String> rows;
  final int width;
  final int height;
  final Pos romeoStart;
  final Pos julietStart;

  late final List<String> _grid = _normalize(rows, width);

  /// Minimum number of moves needed to solve the level (BFS), -1 if unsolvable.
  late final int par = solveLevel(this);

  String cell(int x, int y) {
    if (x < 0 || y < 0 || x >= width || y >= height) return '#';
    return _grid[y][x];
  }

  bool isWall(int x, int y) => cell(x, y) == '#';

  bool isThorn(int x, int y) => cell(x, y) == '^';

  static int _maxLen(List<String> rows) {
    var w = 0;
    for (final r in rows) {
      if (r.length > w) w = r.length;
    }
    return w;
  }

  static Pos _find(List<String> rows, String ch) {
    for (var y = 0; y < rows.length; y++) {
      final x = rows[y].indexOf(ch);
      if (x >= 0) return Pos(x, y);
    }
    throw StateError('Level has no "$ch"');
  }

  static List<String> _normalize(List<String> rows, int width) {
    final out = <String>[];
    for (final r in rows) {
      final padded = r.padRight(width, '#');
      out.add(padded.replaceAll('R', '.').replaceAll('J', '.').replaceAll(' ', '.'));
    }
    return out;
  }
}

class GameState {
  const GameState({
    required this.romeo,
    required this.juliet,
    required this.moves,
    required this.status,
  });

  factory GameState.initial(Level level) => GameState(
        romeo: level.romeoStart,
        juliet: level.julietStart,
        moves: 0,
        status: GameStatus.playing,
      );

  final Pos romeo;
  final Pos juliet;
  final int moves;
  final GameStatus status;
}

class _Target {
  const _Target(this.pos, this.dead);

  final Pos pos;
  final bool dead;
}

_Target _target(Level level, Pos from, int dx, int dy) {
  final nx = from.x + dx;
  final ny = from.y + dy;
  if (level.isWall(nx, ny)) return _Target(from, false);
  if (level.isThorn(nx, ny)) return _Target(Pos(nx, ny), true);
  return _Target(Pos(nx, ny), false);
}

/// Applies one move. Returns the SAME [state] instance when nothing changes
/// (both heroes blocked, or the game is already over).
GameState step(Level level, GameState state, Dir dir) {
  if (state.status != GameStatus.playing) return state;
  final dx = dir == Dir.left ? -1 : (dir == Dir.right ? 1 : 0);
  final dy = dir == Dir.up ? -1 : (dir == Dir.down ? 1 : 0);
  final r = _target(level, state.romeo, dx, dy);
  final j = _target(level, state.juliet, -dx, dy);
  if (r.pos == state.romeo && j.pos == state.juliet) return state;

  var status = GameStatus.playing;
  if (r.dead || j.dead) {
    status = GameStatus.lost;
  } else if (r.pos == j.pos || (r.pos == state.juliet && j.pos == state.romeo)) {
    status = GameStatus.won;
  }
  return GameState(
    romeo: r.pos,
    juliet: j.pos,
    moves: state.moves + 1,
    status: status,
  );
}

/// Breadth-first search for the shortest solution. Returns -1 if unsolvable.
int solveLevel(Level level) {
  final w = level.width;
  final h = level.height;
  int key(Pos r, Pos j) => ((r.x * h + r.y) * w + j.x) * h + j.y;

  final start = GameState.initial(level);
  final seen = <int>{key(start.romeo, start.juliet)};
  var frontier = <GameState>[start];
  var depth = 0;
  while (frontier.isNotEmpty) {
    depth++;
    final next = <GameState>[];
    for (final s in frontier) {
      for (final d in Dir.values) {
        final n = step(level, s, d);
        if (identical(n, s)) continue;
        if (n.status == GameStatus.won) return depth;
        if (n.status == GameStatus.lost) continue;
        if (seen.add(key(n.romeo, n.juliet))) next.add(n);
      }
    }
    frontier = next;
  }
  return -1;
}

/// 3 stars for a perfect (par) solution, 2 for par+3, otherwise 1.
int starsFor(int par, int moves) {
  if (moves <= par) return 3;
  if (moves <= par + 3) return 2;
  return 1;
}
