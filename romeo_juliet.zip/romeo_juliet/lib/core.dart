import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'engine.dart';
import 'levels.dart';
import 'progress.dart';

/// Thin bridge to the generated MainActivity (see tools/patch_manifest.py).
/// Every call is safe: failures simply return defaults.
class Native {
  static const MethodChannel _ch = MethodChannel('app/native');

  static Future<bool> lowEnd() async {
    try {
      return (await _ch.invokeMethod<bool>('lowEnd')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<String?> getString(String key) async {
    try {
      return await _ch.invokeMethod<String>('getString', <String, dynamic>{'key': key});
    } catch (_) {
      return null;
    }
  }

  static Future<void> setString(String key, String value) async {
    try {
      await _ch.invokeMethod<bool>('setString', <String, dynamic>{'key': key, 'value': value});
    } catch (_) {}
  }
}

/// App-wide state: device class and saved progress.
class AppState extends ChangeNotifier {
  AppState._();

  static final AppState instance = AppState._();

  bool lowEnd = false;
  Progress progress = Progress.empty(kLevels.length);

  /// Blur radius for glass panels; 0 on low-end devices.
  double get panelBlur => lowEnd ? 0 : 16;

  Future<void> init() async {
    lowEnd = await Native.lowEnd();
    progress = Progress.decode(await Native.getString('progress'), kLevels.length);
    notifyListeners();
  }

  void completeLevel(int index, int moves) {
    final p = progress.record(index, moves);
    if (identical(p, progress)) return;
    progress = p;
    Native.setString('progress', p.encode());
    notifyListeners();
  }
}

/// Holds one play session of one level, with undo history.
class GameController extends ChangeNotifier {
  GameController(this.levelIndex)
      : level = kLevels[levelIndex],
        _state = GameState.initial(kLevels[levelIndex]);

  final int levelIndex;
  final Level level;
  GameState _state;
  final List<GameState> _history = <GameState>[];

  GameState get state => _state;

  bool get canUndo => _history.isNotEmpty;

  bool get hasNextLevel => levelIndex + 1 < kLevels.length;

  int get stars => starsFor(level.par, _state.moves);

  /// Returns true if something moved.
  bool move(Dir d) {
    final n = step(level, _state, d);
    if (identical(n, _state)) return false;
    _history.add(_state);
    _state = n;
    if (n.status == GameStatus.won) {
      AppState.instance.completeLevel(levelIndex, n.moves);
    }
    notifyListeners();
    return true;
  }

  void undo() {
    if (_history.isEmpty) return;
    _state = _history.removeLast();
    notifyListeners();
  }

  void restart() {
    _history.clear();
    _state = GameState.initial(level);
    notifyListeners();
  }
}
