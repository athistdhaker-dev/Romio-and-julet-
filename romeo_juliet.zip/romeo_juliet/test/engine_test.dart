import 'package:flutter_test/flutter_test.dart';
import 'package:romeo_juliet/engine.dart';
import 'package:romeo_juliet/levels.dart';
import 'package:romeo_juliet/progress.dart';

Level _lv(List<String> rows) => Level(name: 't', rows: rows);

void main() {
  group('engine', () {
    test('mirrored horizontal movement and meeting', () {
      final l = _lv(['#######', '#R...J#', '#######']);
      var s = GameState.initial(l);
      s = step(l, s, Dir.right);
      expect(s.romeo, const Pos(2, 1));
      expect(s.juliet, const Pos(4, 1));
      expect(s.status, GameStatus.playing);
      s = step(l, s, Dir.right);
      expect(s.status, GameStatus.won);
      expect(s.moves, 2);
    });

    test('swapping places counts as meeting', () {
      final l = _lv(['#######', '#R..J.#', '#######']);
      var s = GameState.initial(l);
      s = step(l, s, Dir.right);
      expect(s.status, GameStatus.playing);
      s = step(l, s, Dir.right);
      expect(s.status, GameStatus.won);
    });

    test('blocked hero stays, other one moves', () {
      final l = _lv(['#####', '#R..#', '#..J#', '#####']);
      final s = step(l, GameState.initial(l), Dir.up);
      expect(s.romeo, const Pos(1, 1));
      expect(s.juliet, const Pos(3, 1));
      expect(s.moves, 1);
    });

    test('both blocked returns the same state', () {
      final l = _lv(['#######', '#R...J#', '#######']);
      final s0 = GameState.initial(l);
      expect(identical(step(l, s0, Dir.up), s0), isTrue);
    });

    test('thorn loses the level and ends input', () {
      final l = _lv(['#####', '#R^J#', '#####']);
      final s = step(l, GameState.initial(l), Dir.right);
      expect(s.status, GameStatus.lost);
      final again = step(l, s, Dir.left);
      expect(identical(again, s), isTrue);
    });

    test('outside the grid counts as wall', () {
      final l = _lv(['R.J']);
      expect(l.isWall(-1, 0), isTrue);
      expect(l.isWall(0, 5), isTrue);
    });

    test('solver and stars', () {
      final l = _lv(['#######', '#R...J#', '#######']);
      expect(l.par, 2);
      expect(solveLevel(_lv(['#####', '#R#J#', '#####'])), -1);
      expect(starsFor(5, 5), 3);
      expect(starsFor(5, 8), 2);
      expect(starsFor(5, 9), 1);
    });
  });

  group('levels', () {
    test('every level is solvable', () {
      for (final l in kLevels) {
        expect(l.par, greaterThan(0), reason: l.name);
      }
    });

    test('par values match offline verification', () {
      expect(
        kLevels.map((l) => l.par).toList(),
        <int>[2, 2, 4, 6, 8, 10, 13, 15, 17, 20, 24, 28],
      );
    });
  });

  group('progress', () {
    test('unlock and record', () {
      var p = Progress.empty(3);
      expect(p.isUnlocked(0), isTrue);
      expect(p.isUnlocked(1), isFalse);
      p = p.record(0, 7);
      expect(p.isUnlocked(1), isTrue);
      p = p.record(0, 9);
      expect(p.best[0], 7);
      p = p.record(0, 5);
      expect(p.best[0], 5);
      expect(p.completed, 1);
    });

    test('encode and decode', () {
      final p = Progress.empty(4).record(1, 6).record(2, 3);
      final q = Progress.decode(p.encode(), 4);
      expect(q.best, <int>[0, 6, 3, 0]);
      expect(Progress.decode('x,5', 3).best, <int>[0, 5, 0]);
      expect(Progress.decode(null, 2).best, <int>[0, 0]);
    });
  });
}
