# Romeo & Juliet (Flutter, Android mobile)

Original mirrored-movement puzzle game. Romeo moves where you press; Juliet moves
the same vertically but MIRRORED horizontally. Get them onto the same tile (or let
them cross) to win. Thorns end the level. Fewer moves = more stars.

Controls: on-screen D-pad (hold to repeat), swipe on the board, Undo, Restart
(arrow keys / Z / R on emulator). 12 levels, progress saved on device.

- Zero third-party packages, zero Android permissions, fully offline.
- Game rules and level solver are pure Dart (`lib/engine.dart`, `lib/progress.dart`),
  unit-tested in `test/engine_test.dart`.
- `android/` is NOT stored: CI runs `flutter create` then `tools/patch_manifest.py mobile`.
- applicationId: `com.maraj.romeo_juliet`. Keep `pubspec.yaml` version and `kVersion` in `lib/legal.dart` equal.
- Fill `kContactName` / `kContactEmail` in `lib/legal.dart` before publishing.
