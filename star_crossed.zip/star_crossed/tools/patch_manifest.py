#!/usr/bin/env python3
"""Patch the freshly generated Android project (run from the app dir).

Usage: python3 tools/patch_manifest.py mobile

- starts from AndroidManifest.xml.orig (repeat-safe)
- sets android:label
- removes any <uses-permission> (this app needs zero permissions)
- copies launcher icons into android/app/src/main/res
- writes MainActivity.kt (MethodChannel "env": lowEnd, filesDir)
"""
import glob
import os
import re
import shutil
import sys

APP_LABEL = "Star Crossed"
APP_ID = "com.maraj.star_crossed"

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAIN = os.path.join(ROOT, "android", "app", "src", "main")
MANIFEST = os.path.join(MAIN, "AndroidManifest.xml")
ORIG = MANIFEST + ".orig"

KOTLIN = """package %(pkg)s

import android.app.ActivityManager
import android.content.Context
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "env")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "lowEnd" -> {
                        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                        result.success(am.isLowRamDevice || am.memoryClass < 192)
                    }
                    "filesDir" -> result.success(filesDir.absolutePath)
                    else -> result.notImplemented()
                }
            }
    }
}
"""


def main():
    target = sys.argv[1] if len(sys.argv) > 1 else "mobile"
    if target != "mobile":
        sys.exit("only the 'mobile' target exists in this project")
    if not os.path.exists(MANIFEST):
        sys.exit("android/ not found - run flutter create first")

    if os.path.exists(ORIG):
        shutil.copyfile(ORIG, MANIFEST)
    else:
        shutil.copyfile(MANIFEST, ORIG)

    with open(MANIFEST, encoding="utf-8") as f:
        xml = f.read()
    xml = re.sub(r"\s*<uses-permission[^>]*/>", "", xml)
    if re.search(r'android:label="[^"]*"', xml):
        xml = re.sub(r'android:label="[^"]*"', 'android:label="%s"' % APP_LABEL,
                     xml, count=1)
    else:
        xml = xml.replace("<application", '<application android:label="%s"' % APP_LABEL, 1)
    with open(MANIFEST, "w", encoding="utf-8") as f:
        f.write(xml)

    # icons
    for d in sorted(glob.glob(os.path.join(ROOT, "assets", "android_icons", "mipmap-*"))):
        dest = os.path.join(MAIN, "res", os.path.basename(d))
        os.makedirs(dest, exist_ok=True)
        for png in glob.glob(os.path.join(d, "*.png")):
            shutil.copyfile(png, os.path.join(dest, os.path.basename(png)))

    # MainActivity.kt (remove whatever flutter create generated first)
    for old in glob.glob(os.path.join(MAIN, "**", "MainActivity.*"), recursive=True):
        os.remove(old)
    kdir = os.path.join(MAIN, "kotlin", *APP_ID.split("."))
    os.makedirs(kdir, exist_ok=True)
    with open(os.path.join(kdir, "MainActivity.kt"), "w", encoding="utf-8") as f:
        f.write(KOTLIN % {"pkg": APP_ID})

    print("patched manifest, icons and MainActivity for", target)


if __name__ == "__main__":
    main()
