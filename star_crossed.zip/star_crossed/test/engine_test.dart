import 'package:flutter_test/flutter_test.dart';
import 'package:star_crossed/engine.dart';
import 'package:star_crossed/progress.dart';

void main() {
  test('levels are deterministic and well formed', () {
    for (var i = 0; i < kLevelCount; i++) {
      final a = Level.generate(i);
      final b = Level.generate(i);
      expect(a.tops, b.tops);
      expect(a.width, greaterThan(60));
      for (var c = 0; c < 8; c++) {
        expect(a.tops[c], 8, reason: 'start zone must be flat');
      }
      for (var c = a.width - 9; c < a.width; c++) {
        expect(a.tops[c], greaterThanOrEqualTo(0), reason: 'goal zone solid');
      }
      var run = 0;
      for (final t in a.tops) {
        if (t < 0) {
          run++;
          expect(run, lessThanOrEqualTo(3));
        } else {
          run = 0;
        }
      }
      for (final f in a.fires) {
        expect(a.tops[f], greaterThanOrEqualTo(0));
      }
    }
  });

  test('player lands, walks and jumps', () {
    final w = World(Level.generate(0));
    for (var i = 0; i < 30; i++) {
      w.update(1 / 60);
    }
    expect(w.onGround, true);
    expect(w.state, GameState.playing);
    final x0 = w.x;
    w.input.right = true;
    for (var i = 0; i < 30; i++) {
      w.update(1 / 60);
    }
    expect(w.x, greaterThan(x0 + 1));
    w.input.right = false;
    final y0 = w.y;
    w.input.jump = true;
    for (var i = 0; i < 6; i++) {
      w.update(1 / 60);
    }
    expect(w.y, lessThan(y0 - 0.2));
  });

  test('reaching the goal completes the level', () {
    final w = World(Level.generate(0));
    w.x = w.level.goalX - kPlayerW + 0.1;
    w.y = w.level.tops[w.x.floor()] - kPlayerH - 0.001;
    w.update(1 / 60);
    expect(w.state, GameState.complete);
    expect(w.score, greaterThanOrEqualTo(100));
  });

  test('falling into a pit costs a life', () {
    final w = World(Level.generate(0));
    final pit = w.level.tops.indexOf(-1);
    expect(pit, greaterThan(0));
    w.x = pit + 0.2;
    w.y = 8;
    for (var i = 0; i < 120 && w.state == GameState.playing; i++) {
      w.update(1 / 60);
    }
    expect(w.state, GameState.dying);
    expect(w.lives, 2);
  });

  test('progress json round trip and unlocking', () {
    final p = Progress();
    p.recordWin(0, 250);
    expect(p.unlocked, 2);
    final q = Progress.fromJson(p.toJson());
    expect(q.best[0], 250);
    expect(q.unlocked, 2);
    expect(Progress.fromJson('garbage').unlocked, 1);
  });
}
