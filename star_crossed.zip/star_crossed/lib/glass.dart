import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import 'core.dart';

class _RimPainter extends CustomPainter {
  final double radius;
  final bool strong;
  const _RimPainter(this.radius, this.strong);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius))
        .deflate(0.75);
    final a = strong ? 0.9 : 0.55;
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strong ? 2.0 : 1.2
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withValues(alpha: a),
          Colors.white.withValues(alpha: 0.05),
          Colors.white.withValues(alpha: a * 0.45),
        ],
        stops: const [0.0, 0.55, 1.0],
      ).createShader(rect);
    canvas.drawRRect(rrect, rim);
    final hl = Paint()
      ..strokeWidth = 1.2
      ..shader = LinearGradient(colors: [
        Colors.white.withValues(alpha: 0.0),
        Colors.white.withValues(alpha: 0.45),
        Colors.white.withValues(alpha: 0.0),
      ]).createShader(rect);
    canvas.drawLine(
        Offset(radius * 0.8, 1.5), Offset(size.width - radius * 0.8, 1.5), hl);
  }

  @override
  bool shouldRepaint(_RimPainter old) =>
      old.radius != radius || old.strong != strong;
}

BoxDecoration _glassFill(double radius, Color tint, double boost) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [
        Color.alphaBlend(tint.withValues(alpha: 0.10 + boost),
            Colors.white.withValues(alpha: 0.20 + boost)),
        Color.alphaBlend(tint.withValues(alpha: 0.04 + boost),
            Colors.white.withValues(alpha: 0.05 + boost)),
      ],
    ),
  );
}

/// A glass panel. Only ONE panel per screen should use [blur] = true.
class GlassPanel extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsets padding;
  final bool blur;
  final Color tint;

  const GlassPanel({
    super.key,
    required this.child,
    this.radius = 24,
    this.padding = const EdgeInsets.all(16),
    this.blur = true,
    this.tint = const Color(0xFF7B2FF7),
  });

  @override
  Widget build(BuildContext context) {
    Widget body = DecoratedBox(
      decoration: _glassFill(radius, tint, 0),
      child: CustomPaint(
        foregroundPainter: _RimPainter(radius, false),
        child: Padding(padding: padding, child: child),
      ),
    );
    final sigma = Env.panelBlur;
    if (blur && sigma > 0) {
      body = BackdropFilter(
        filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
        child: body,
      );
    }
    return ClipRRect(borderRadius: BorderRadius.circular(radius), child: body);
  }
}

/// Translucent glass key/tile (never blurs). Supports tap and hold.
class GlassButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final ValueChanged<bool>? onHold;
  final double? width;
  final double? height;
  final double radius;
  final Color tint;
  final bool enabled;

  const GlassButton({
    super.key,
    required this.child,
    this.onTap,
    this.onHold,
    this.width,
    this.height,
    this.radius = 20,
    this.tint = const Color(0xFF2FA8F7),
    this.enabled = true,
  });

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool _down = false;

  void _set(bool v) {
    if (_down == v) return;
    setState(() => _down = v);
    widget.onHold?.call(v);
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.radius;
    return Listener(
      onPointerDown: widget.enabled ? (_) => _set(true) : null,
      onPointerUp: widget.enabled
          ? (_) {
              final was = _down;
              _set(false);
              if (was) widget.onTap?.call();
            }
          : null,
      onPointerCancel: widget.enabled ? (_) => _set(false) : null,
      child: AnimatedScale(
        scale: _down ? 0.94 : 1.0,
        duration: const Duration(milliseconds: 80),
        child: Opacity(
          opacity: widget.enabled ? 1 : 0.4,
          child: Container(
            width: widget.width,
            height: widget.height,
            alignment: Alignment.center,
            decoration: _glassFill(r, widget.tint, _down ? 0.14 : 0.0),
            foregroundDecoration: const BoxDecoration(),
            child: CustomPaint(
              foregroundPainter: _RimPainter(r, _down),
              child: Center(child: widget.child),
            ),
          ),
        ),
      ),
    );
  }
}
