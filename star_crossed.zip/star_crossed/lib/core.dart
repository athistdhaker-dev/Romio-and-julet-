import 'dart:io';

import 'package:flutter/services.dart';

import 'progress.dart';

/// Device info coming from MainActivity.kt (written by tools/patch_manifest.py).
class Env {
  static const MethodChannel _ch = MethodChannel('env');
  static bool lowEnd = false;
  static String? _dir;

  /// Blur sigma for the single glass panel on a screen. 0 = no blur.
  static double get panelBlur => lowEnd ? 0 : 18;

  static Future<void> init() async {
    try {
      lowEnd = (await _ch.invokeMethod<bool>('lowEnd')) ?? false;
    } catch (_) {
      lowEnd = false;
    }
    try {
      _dir = await _ch.invokeMethod<String>('filesDir');
    } catch (_) {
      _dir = null;
    }
  }

  static File? get saveFile =>
      _dir == null ? null : File('$_dir/progress.json');
}

/// Local-only save. Writes only when the device has enough free space,
/// which we approximate by catching write failures (no extra permissions).
class Store {
  static Progress progress = Progress();

  static Future<void> load() async {
    try {
      final f = Env.saveFile;
      if (f != null && await f.exists()) {
        progress = Progress.fromJson(await f.readAsString());
      }
    } catch (_) {
      progress = Progress();
    }
  }

  static Future<void> save() async {
    try {
      final f = Env.saveFile;
      if (f != null) {
        await f.writeAsString(progress.toJson(), flush: true);
      }
    } catch (_) {
      // Progress is kept in memory for this session if disk write fails.
    }
  }
}
