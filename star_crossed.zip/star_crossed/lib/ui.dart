import 'package:flutter/material.dart';

import 'glass.dart';

const Color kPurple = Color(0xFF7B2FF7);
const Color kPink = Color(0xFFEC5678);
const Color kBlue = Color(0xFF2FA8F7);
const Color kTeal = Color(0xFF2ED3B7);

/// Dark gradient with soft colour orbs (radial gradients, no blur filter).
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  Widget _orb(Alignment a, Color c, double size) {
    return Align(
      alignment: a,
      child: IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [
              c.withValues(alpha: 0.55),
              c.withValues(alpha: 0.0),
            ]),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0B0820), Color(0xFF150B2E), Color(0xFF06101F)],
        ),
      ),
      child: Stack(
        children: [
          _orb(const Alignment(-1.0, -0.9), kPurple, 420),
          _orb(const Alignment(1.0, -0.4), kPink, 360),
          _orb(const Alignment(-0.6, 1.0), kBlue, 400),
          _orb(const Alignment(1.0, 1.0), kTeal, 320),
          child,
        ],
      ),
    );
  }
}

class Label extends StatelessWidget {
  final String text;
  final double size;
  final FontWeight weight;
  final Color color;
  final TextAlign align;
  const Label(
    this.text, {
    super.key,
    this.size = 16,
    this.weight = FontWeight.w500,
    this.color = Colors.white,
    this.align = TextAlign.start,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: align,
      style: TextStyle(fontSize: size, fontWeight: weight, color: color),
    );
  }
}

class MenuButton extends StatelessWidget {
  final String text;
  final IconData? icon;
  final VoidCallback onTap;
  final Color tint;
  final double width;
  const MenuButton({
    super.key,
    required this.text,
    required this.onTap,
    this.icon,
    this.tint = kBlue,
    this.width = 260,
  });

  @override
  Widget build(BuildContext context) {
    return GlassButton(
      width: width,
      height: 54,
      tint: tint,
      onTap: onTap,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 10),
          ],
          Label(text, size: 17, weight: FontWeight.w600),
        ],
      ),
    );
  }
}
