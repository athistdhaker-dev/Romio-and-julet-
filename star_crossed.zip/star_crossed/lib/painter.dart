import 'dart:math';

import 'package:flutter/material.dart';

import 'engine.dart';

const double kViewRows = 10;

const List<List<Color>> _skies = [
  [Color(0xFF1B1446), Color(0xFF5B2A86)],
  [Color(0xFF0F2347), Color(0xFF2C5E8A)],
  [Color(0xFF241046), Color(0xFF8A2F6B)],
  [Color(0xFF14243E), Color(0xFF3B6E7A)],
  [Color(0xFF2A1238), Color(0xFF7A3A5E)],
  [Color(0xFF0C1230), Color(0xFF30305E)],
  [Color(0xFF2B1040), Color(0xFFB04A72)],
];

class GamePainter extends CustomPainter {
  final World w;
  final Paint _p = Paint();

  GamePainter(this.w, Listenable repaint) : super(repaint: repaint);

  @override
  void paint(Canvas c, Size s) {
    final ts = s.height / kViewRows;
    final viewW = s.width / ts;
    final maxCam = max(0.0, w.level.width - viewW);
    final camX = (w.x + kPlayerW / 2 - viewW / 2).clamp(0.0, maxCam).toDouble();
    final camY = (w.y - 5.0).clamp(0.0, (kRows - kViewRows) + 0.0).toDouble();

    _sky(c, s, camX, ts);
    c.save();
    c.translate(-camX * ts, -camY * ts);
    c.scale(ts, ts);
    final x0 = max(0, camX.floor() - 1);
    final x1 = min(w.level.width - 1, (camX + viewW).ceil() + 1);
    _ground(c, x0, x1);
    _fires(c, x0, x1);
    _roses(c);
    _goal(c);
    _enemies(c);
    _player(c);
    c.restore();
  }

  void _sky(Canvas c, Size s, double camX, double ts) {
    final pal = _skies[w.level.index % _skies.length];
    final rect = Offset.zero & s;
    _p
      ..style = PaintingStyle.fill
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: pal,
      ).createShader(rect);
    c.drawRect(rect, _p);
    _p.shader = null;

    for (var i = 0; i < 45; i++) {
      final dx = ((i * 97.0) % 100) / 100 * s.width;
      final px = (dx - camX * ts * 0.04) % s.width;
      final py = ((i * 53.0) % 60) / 100 * s.height;
      final a = 0.45 + 0.4 * sin(w.time * 2 + i);
      _p.color = Colors.white.withValues(alpha: a.clamp(0.1, 0.9).toDouble());
      c.drawCircle(Offset(px, py), 0.8 + (i % 3) * 0.5, _p);
    }

    final moon = Offset(s.width * 0.82, s.height * 0.2);
    _p.color = const Color(0x33FFF3C4);
    c.drawCircle(moon, s.height * 0.12, _p);
    _p.color = const Color(0xFFFFF3C4);
    c.drawCircle(moon, s.height * 0.065, _p);

    final spacing = ts * 6.0;
    final scroll = camX * ts * 0.25;
    final first = (scroll / spacing).floor();
    final off = scroll - first * spacing;
    const heights = [3.2, 4.4, 2.6, 5.0, 3.8];
    final n = (s.width / spacing).ceil() + 2;
    for (var i = 0; i < n; i++) {
      final idx = first + i;
      final bx = i * spacing - off;
      final h = heights[idx % heights.length] * ts * 0.9;
      final bw = ts * 2.0;
      final by = s.height * 0.78 - h;
      _p.color = const Color(0x55120A2A);
      c.drawRect(Rect.fromLTWH(bx, by, bw, h + s.height), _p);
      final roof = Path()
        ..moveTo(bx - ts * 0.15, by)
        ..lineTo(bx + bw / 2, by - ts * 0.9)
        ..lineTo(bx + bw + ts * 0.15, by)
        ..close();
      c.drawPath(roof, _p);
      if (idx % 2 == 0) {
        _p.color = const Color(0x66FFD27A);
        c.drawRect(
            Rect.fromLTWH(bx + bw * 0.4, by + h * 0.25, ts * 0.22, ts * 0.34),
            _p);
      }
    }
  }

  void _ground(Canvas c, int x0, int x1) {
    final hue = (250.0 + w.level.index * 18) % 360;
    final dark = HSLColor.fromAHSL(1, hue, 0.28, 0.24).toColor();
    final light = HSLColor.fromAHSL(1, hue, 0.26, 0.30).toColor();
    const grass = Color(0xFF3E9B6A);
    const grassHi = Color(0xFF7FE0A8);
    for (var cx = x0; cx <= x1; cx++) {
      final t = w.level.tops[cx];
      if (t < 0) continue;
      for (var r = t; r < kRows + 4; r++) {
        _p.color = ((cx + r) % 2 == 0) ? dark : light;
        c.drawRect(Rect.fromLTWH(cx.toDouble(), r.toDouble(), 1.02, 1.02), _p);
      }
      _p.color = grass;
      c.drawRect(Rect.fromLTWH(cx.toDouble(), t.toDouble(), 1.02, 0.22), _p);
      _p.color = grassHi;
      c.drawRect(Rect.fromLTWH(cx.toDouble(), t.toDouble(), 1.02, 0.06), _p);
    }
  }

  void _fires(Canvas c, int x0, int x1) {
    for (final cx in w.level.fires) {
      if (cx < x0 || cx > x1) continue;
      final base = w.level.tops[cx].toDouble();
      _p.color = const Color(0x22FF8A2A);
      c.drawCircle(Offset(cx + 0.5, base - 0.3), 0.8, _p);
      for (var j = 0; j < 3; j++) {
        final fx = cx + 0.22 + j * 0.28;
        final h = 0.5 + 0.22 * sin(w.time * 9 + cx * 1.7 + j * 2.0);
        final path = Path()
          ..moveTo(fx - 0.17, base)
          ..quadraticBezierTo(fx - 0.2, base - h * 0.5, fx, base - h - 0.15)
          ..quadraticBezierTo(fx + 0.2, base - h * 0.5, fx + 0.17, base)
          ..close();
        _p.color = const Color(0xFFFF6A1A);
        c.drawPath(path, _p);
        final inner = Path()
          ..moveTo(fx - 0.08, base)
          ..quadraticBezierTo(fx - 0.1, base - h * 0.35, fx, base - h * 0.7)
          ..quadraticBezierTo(fx + 0.1, base - h * 0.35, fx + 0.08, base)
          ..close();
        _p.color = const Color(0xFFFFD84A);
        c.drawPath(inner, _p);
      }
    }
  }

  void _roses(Canvas c) {
    for (final r in w.roses) {
      if (r.taken) continue;
      final bob = sin(w.time * 3 + r.x) * 0.06;
      final cx = r.x;
      final cy = r.y + bob;
      _p
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.05
        ..color = const Color(0xFF2E9E58);
      c.drawLine(Offset(cx, cy + 0.1), Offset(cx, cy + 0.38), _p);
      _p.style = PaintingStyle.fill;
      c.drawOval(
          Rect.fromCenter(
              center: Offset(cx + 0.09, cy + 0.27), width: 0.16, height: 0.08),
          _p);
      _p.color = const Color(0xFFE8274B);
      c.drawCircle(Offset(cx, cy), 0.2, _p);
      _p.color = const Color(0xFFB3123A);
      c.drawCircle(Offset(cx, cy), 0.12, _p);
      _p.color = const Color(0x66FFFFFF);
      c.drawCircle(Offset(cx - 0.07, cy - 0.07), 0.04, _p);
    }
  }

  void _goal(Canvas c) {
    final gx = w.level.width - 3.0;
    final gy = w.level.tops[w.level.width - 3].toDouble();
    _p.color = const Color(0x33EC5678);
    c.drawCircle(Offset(gx + 0.4, gy - 0.9), 1.6, _p);
    _p.color = const Color(0xFFB9A7D6);
    c.drawRect(Rect.fromLTWH(gx - 1.0, gy - 3.0, 0.3, 3.0), _p);
    c.drawRect(Rect.fromLTWH(gx + 1.6, gy - 3.0, 0.3, 3.0), _p);
    c.drawRect(Rect.fromLTWH(gx - 1.2, gy - 3.2, 3.3, 0.28), _p);
    final dress = Path()
      ..moveTo(gx + 0.4, gy - 0.95)
      ..lineTo(gx + 0.05, gy)
      ..lineTo(gx + 0.75, gy)
      ..close();
    _p.color = const Color(0xFFFF8FB3);
    c.drawPath(dress, _p);
    _p.color = const Color(0xFFF2C9A0);
    c.drawCircle(Offset(gx + 0.4, gy - 1.08), 0.15, _p);
    _p.color = const Color(0xFF5A2E1E);
    c.drawArc(Rect.fromCircle(center: Offset(gx + 0.4, gy - 1.1), radius: 0.18),
        pi, pi, true, _p);
    final hb = sin(w.time * 3) * 0.08;
    _drawHeart(c, Offset(gx + 0.4, gy - 1.8 + hb), 0.22);
  }

  void _drawHeart(Canvas c, Offset o, double r) {
    _p.color = const Color(0xFFFF3D6E);
    c.drawCircle(Offset(o.dx - r * 0.5, o.dy), r * 0.55, _p);
    c.drawCircle(Offset(o.dx + r * 0.5, o.dy), r * 0.55, _p);
    final p = Path()
      ..moveTo(o.dx - r * 1.02, o.dy + r * 0.15)
      ..lineTo(o.dx, o.dy + r * 1.3)
      ..lineTo(o.dx + r * 1.02, o.dy + r * 0.15)
      ..close();
    c.drawPath(p, _p);
  }

  void _enemies(Canvas c) {
    for (final e in w.enemies) {
      if (!e.alive) continue;
      final face = e.vx >= 0 ? 1.0 : -1.0;
      final step = sin(w.time * 10 + e.x) * 0.05;
      c.save();
      c.translate(e.x + Enemy.w / 2, e.y);
      c.scale(face, 1);
      _p.color = const Color(0xFF3A3F55);
      c.drawRect(Rect.fromLTWH(-0.26, 0.62 + step, 0.18, 0.18), _p);
      c.drawRect(Rect.fromLTWH(0.08, 0.62 - step, 0.18, 0.18), _p);
      _p.color = const Color(0xFF8A93B3);
      c.drawRRect(
          RRect.fromRectAndRadius(
              Rect.fromLTWH(-0.34, 0.3, 0.68, 0.38), const Radius.circular(0.1)),
          _p);
      _p.color = const Color(0xFFB8C0DC);
      c.drawCircle(const Offset(0, 0.26), 0.26, _p);
      _p.color = const Color(0xFF22263A);
      c.drawRect(Rect.fromLTWH(-0.02, 0.2, 0.26, 0.09), _p);
      _p.color = const Color(0xFFD83A4A);
      c.drawRect(Rect.fromLTWH(-0.05, -0.08, 0.1, 0.16), _p);
      _p.color = const Color(0xFFFFE08A);
      c.drawRect(Rect.fromLTWH(0.3, 0.12, 0.05, 0.62), _p);
      c.restore();
    }
  }

  void _player(Canvas c) {
    if (w.invuln > 0 && w.state == GameState.playing) {
      if ((w.time * 14).floor() % 2 == 0) return;
    }
    final moving = w.onGround && w.input.left != w.input.right;
    final swing = moving ? sin(w.time * 16) * 0.14 : 0.0;
    final air = !w.onGround;
    c.save();
    c.translate(w.x + kPlayerW / 2, w.y);
    if (!w.facingRight) c.scale(-1, 1);

    final sway = air ? -0.12 : swing * 0.8;
    final cape = Path()
      ..moveTo(-0.08, 0.32)
      ..quadraticBezierTo(-0.38, 0.5 + sway, -0.34, 0.78)
      ..lineTo(-0.08, 0.7)
      ..close();
    _p
      ..style = PaintingStyle.fill
      ..color = const Color(0xFFC0213F);
    c.drawPath(cape, _p);

    _p
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.13
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF2A2350);
    if (air) {
      c.drawLine(const Offset(-0.08, 0.66), const Offset(-0.16, 0.84), _p);
      c.drawLine(const Offset(0.08, 0.66), const Offset(0.18, 0.8), _p);
    } else {
      c.drawLine(const Offset(-0.08, 0.66), Offset(-0.08 + swing, 0.88), _p);
      c.drawLine(const Offset(0.08, 0.66), Offset(0.08 - swing, 0.88), _p);
    }
    _p.style = PaintingStyle.fill;

    _p.color = const Color(0xFF2F6FED);
    c.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(-0.2, 0.34, 0.4, 0.34), const Radius.circular(0.08)),
        _p);
    _p.color = const Color(0xFFFFD36B);
    c.drawRect(Rect.fromLTWH(-0.2, 0.55, 0.4, 0.05), _p);

    _p.color = const Color(0xFFF2C9A0);
    c.drawCircle(const Offset(0, 0.22), 0.17, _p);
    _p.color = const Color(0xFFC0213F);
    c.drawOval(Rect.fromLTWH(-0.2, 0.02, 0.42, 0.14), _p);
    _p.color = Colors.white;
    c.drawRect(Rect.fromLTWH(0.12, -0.08, 0.04, 0.14), _p);
    _p.color = const Color(0xFF1B1446);
    c.drawCircle(const Offset(0.07, 0.22), 0.025, _p);
    c.restore();
  }

  @override
  bool shouldRepaint(GamePainter old) => true;
}
