// Pure Dart save data (JSON), no Flutter imports.
import 'dart:convert';

import 'engine.dart';

class Progress {
  int unlocked;
  final List<int> best;

  Progress({this.unlocked = 1, List<int>? best})
      : best = best ?? List<int>.filled(kLevelCount, 0);

  void recordWin(int level, int score) {
    if (level < 0 || level >= kLevelCount) return;
    if (score > best[level]) best[level] = score;
    final next = level + 2;
    if (next > unlocked) {
      unlocked = next > kLevelCount ? kLevelCount : next;
    }
  }

  int get total => best.fold(0, (a, b) => a + b);

  String toJson() => jsonEncode({'unlocked': unlocked, 'best': best});

  static Progress fromJson(String s) {
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      final b = (m['best'] as List).map((e) => (e as num).toInt()).toList();
      while (b.length < kLevelCount) {
        b.add(0);
      }
      final u = ((m['unlocked'] as num?) ?? 1).toInt();
      return Progress(
        unlocked: u.clamp(1, kLevelCount).toInt(),
        best: b.sublist(0, kLevelCount),
      );
    } catch (_) {
      return Progress();
    }
  }
}
