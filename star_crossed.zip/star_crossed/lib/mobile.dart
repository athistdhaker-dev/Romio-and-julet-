import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import 'core.dart';
import 'engine.dart';
import 'glass.dart';
import 'legal.dart';
import 'pages.dart';
import 'painter.dart';
import 'ui.dart';

// ---------------------------------------------------------------- Home

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    Store.load().then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _open(Widget page) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
    if (mounted) setState(() {});
  }

  Widget _title(bool wide) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: wide ? CrossAxisAlignment.start : CrossAxisAlignment.center,
      children: [
        const Icon(Icons.favorite, color: kPink, size: 44),
        const SizedBox(height: 8),
        const Label(kAppName, size: 40, weight: FontWeight.w800),
        const SizedBox(height: 4),
        Label(
          'A Romeo & Juliet adventure',
          size: 16,
          color: Colors.white70,
          align: wide ? TextAlign.start : TextAlign.center,
        ),
        const SizedBox(height: 10),
        Label('Total score ${Store.progress.total}',
            size: 14, color: kTeal, weight: FontWeight.w600),
      ],
    );
  }

  Widget _menu() {
    final cont = Store.progress.unlocked - 1;
    return GlassPanel(
      padding: const EdgeInsets.all(18),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          MenuButton(
            text: Store.progress.unlocked > 1 ? 'Continue' : 'Play',
            icon: Icons.play_arrow_rounded,
            tint: kPink,
            onTap: () => _open(GameScreen(level: cont)),
          ),
          const SizedBox(height: 12),
          MenuButton(
            text: 'Levels',
            icon: Icons.grid_view_rounded,
            onTap: () => _open(const LevelSelectScreen()),
          ),
          const SizedBox(height: 12),
          MenuButton(
            text: 'About & Legal',
            icon: Icons.info_outline,
            tint: kTeal,
            onTap: () => _open(const AboutScreen()),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppBackground(
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, box) {
              final wide = box.maxWidth > box.maxHeight * 1.2;
              return Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: wide
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _title(true),
                            const SizedBox(width: 48),
                            _menu(),
                          ],
                        )
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _title(false),
                            const SizedBox(height: 32),
                            _menu(),
                          ],
                        ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------- Level select

class LevelSelectScreen extends StatelessWidget {
  const LevelSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final p = Store.progress;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Column(
              children: [
                Row(
                  children: [
                    GlassButton(
                      width: 48,
                      height: 48,
                      radius: 16,
                      onTap: () => Navigator.of(context).pop(),
                      child: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    const Label('Levels', size: 22, weight: FontWeight.w700),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: SizedBox(
                    width: double.infinity,
                    child: GlassPanel(
                      child: SingleChildScrollView(
                        child: Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          alignment: WrapAlignment.center,
                          children: [
                            for (var i = 0; i < kLevelCount; i++)
                              _tile(context, i, p.unlocked > i, p.best[i]),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, int i, bool open, int best) {
    return GlassButton(
      width: 150,
      height: 96,
      enabled: open,
      tint: open ? kPurple : kBlue,
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => GameScreen(level: i)),
        );
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Label(open ? '${i + 1}' : '🔒', size: 24, weight: FontWeight.w800),
          Label(kLevelNames[i], size: 12, align: TextAlign.center),
          if (open && best > 0)
            Label('Best $best', size: 12, color: kTeal, weight: FontWeight.w600),
        ],
      ),
    );
  }
}

// --------------------------------------------------------------- Game

class GameScreen extends StatefulWidget {
  final int level;
  const GameScreen({super.key, required this.level});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late int _level = widget.level;
  late World _world = World(Level.generate(_level));
  late final Ticker _ticker;
  final ValueNotifier<int> _frame = ValueNotifier<int>(0);
  Duration _last = Duration.zero;
  bool _paused = false;
  GameState _shown = GameState.playing;
  int _score = 0;
  int _lives = 3;
  int _roses = 0;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _ticker = createTicker(_tick)..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _frame.dispose();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _tick(Duration t) {
    final dt = (t - _last).inMicroseconds / 1000000.0;
    _last = t;
    if (_paused) return;
    final st = _world.state;
    if (st == GameState.complete || st == GameState.gameOver) return;
    _world.update(dt);
    _frame.value++;
    var dirty = false;
    if (_world.score != _score ||
        _world.lives != _lives ||
        _world.rosesTaken != _roses) {
      _score = _world.score;
      _lives = _world.lives;
      _roses = _world.rosesTaken;
      dirty = true;
    }
    if (_world.state != _shown) {
      _shown = _world.state;
      if (_shown == GameState.complete) {
        Store.progress.recordWin(_level, _world.score);
        Store.save();
      }
      dirty = true;
    }
    if (dirty && mounted) setState(() {});
  }

  void _load(int level) {
    setState(() {
      _level = level;
      _world = World(Level.generate(level));
      _paused = false;
      _shown = GameState.playing;
      _score = 0;
      _lives = _world.lives;
      _roses = 0;
    });
    _frame.value++;
  }

  void _setPaused(bool v) {
    if (v) {
      _world.input
        ..left = false
        ..right = false
        ..jump = false;
    }
    setState(() => _paused = v);
  }

  bool get _ended =>
      _world.state == GameState.complete || _world.state == GameState.gameOver;

  Widget _hud() {
    return Positioned(
      left: 0,
      right: 0,
      top: 0,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Row(
            children: [
              GlassPanel(
                blur: false,
                radius: 18,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.favorite, color: kPink, size: 20),
                    const SizedBox(width: 4),
                    Label('$_lives', size: 16, weight: FontWeight.w700),
                    const SizedBox(width: 16),
                    const Icon(Icons.local_florist, color: Colors.redAccent, size: 20),
                    const SizedBox(width: 4),
                    Label('$_roses/${_world.roses.length}',
                        size: 16, weight: FontWeight.w700),
                    const SizedBox(width: 16),
                    const Icon(Icons.star_rounded, color: Colors.amber, size: 20),
                    const SizedBox(width: 4),
                    Label('$_score', size: 16, weight: FontWeight.w700),
                  ],
                ),
              ),
              const Spacer(),
              Label('${_level + 1}. ${kLevelNames[_level]}',
                  size: 14, color: Colors.white70),
              const Spacer(),
              GlassButton(
                width: 48,
                height: 48,
                radius: 16,
                tint: kPurple,
                onTap: () => _setPaused(true),
                child: const Icon(Icons.pause_rounded, color: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _controls() {
    return Positioned.fill(
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              GlassButton(
                width: 84,
                height: 84,
                radius: 28,
                onHold: (v) => _world.input.left = v,
                child: const Icon(Icons.arrow_left_rounded,
                    color: Colors.white, size: 56),
              ),
              const SizedBox(width: 14),
              GlassButton(
                width: 84,
                height: 84,
                radius: 28,
                onHold: (v) => _world.input.right = v,
                child: const Icon(Icons.arrow_right_rounded,
                    color: Colors.white, size: 56),
              ),
              const Spacer(),
              GlassButton(
                width: 100,
                height: 100,
                radius: 50,
                tint: kPink,
                onHold: (v) => _world.input.jump = v,
                child: const Icon(Icons.keyboard_arrow_up_rounded,
                    color: Colors.white, size: 60),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _overlay() {
    String title;
    String sub = '';
    final buttons = <Widget>[];
    final w = _world;
    if (w.state == GameState.complete) {
      final last = _level + 1 >= kLevelCount;
      title = last ? 'You reached Juliet!' : 'Level complete!';
      sub = 'Score ${w.score}   Roses ${w.rosesTaken}/${w.roses.length}';
      if (!last) {
        buttons.add(MenuButton(
          text: 'Next level',
          icon: Icons.skip_next_rounded,
          tint: kPink,
          onTap: () => _load(_level + 1),
        ));
      }
      buttons.add(MenuButton(
        text: 'Play again',
        icon: Icons.replay_rounded,
        onTap: () => _load(_level),
      ));
    } else if (w.state == GameState.gameOver) {
      title = 'Game over';
      sub = 'Score ${w.score}';
      buttons.add(MenuButton(
        text: 'Try again',
        icon: Icons.replay_rounded,
        tint: kPink,
        onTap: () => _load(_level),
      ));
    } else {
      title = 'Paused';
      buttons.add(MenuButton(
        text: 'Resume',
        icon: Icons.play_arrow_rounded,
        tint: kPink,
        onTap: () => _setPaused(false),
      ));
      buttons.add(MenuButton(
        text: 'Restart',
        icon: Icons.replay_rounded,
        onTap: () => _load(_level),
      ));
    }
    buttons.add(MenuButton(
      text: 'Menu',
      icon: Icons.home_rounded,
      tint: kTeal,
      onTap: () => Navigator.of(context).pop(),
    ));
    return Positioned.fill(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {},
        child: ColoredBox(
          color: Colors.black45,
          child: Center(
            child: SingleChildScrollView(
              child: GlassPanel(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Label(title, size: 26, weight: FontWeight.w800),
                    if (sub.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Label(sub, size: 15, color: kTeal),
                    ],
                    const SizedBox(height: 14),
                    for (final b in buttons) ...[
                      b,
                      const SizedBox(height: 10),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _ended,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _setPaused(!_paused);
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Positioned.fill(
              child: RepaintBoundary(
                child: CustomPaint(painter: GamePainter(_world, _frame)),
              ),
            ),
            _controls(),
            _hud(),
            if (_paused || _ended) _overlay(),
          ],
        ),
      ),
    );
  }
}
