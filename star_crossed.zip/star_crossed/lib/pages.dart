import 'package:flutter/foundation.dart' show LicenseRegistry;
import 'package:flutter/material.dart';

import 'glass.dart';
import 'legal.dart';
import 'ui.dart';

class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {
  int _tab = 0;
  late final Future<Map<String, List<String>>> _licenses = _loadLicenses();

  static const _tabs = ['Privacy', 'Terms', 'Licenses', 'Version'];

  static Future<Map<String, List<String>>> _loadLicenses() async {
    final map = <String, List<String>>{};
    await for (final e in LicenseRegistry.licenses) {
      final text = e.paragraphs.map((p) => p.text).join('\n');
      for (final pkg in e.packages) {
        (map[pkg] ??= <String>[]).add(text);
      }
    }
    return map;
  }

  Widget _text(String t) {
    return SingleChildScrollView(
      child: Label(t, size: 14, weight: FontWeight.w400),
    );
  }

  Widget _body() {
    switch (_tab) {
      case 0:
        return _text(kPrivacy);
      case 1:
        return _text(kTerms);
      case 2:
        return FutureBuilder<Map<String, List<String>>>(
          future: _licenses,
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final keys = snap.data!.keys.toList()..sort();
            return Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ListView(
                children: [
                  for (final k in keys)
                    ExpansionTile(
                      title: Label(k, size: 15, weight: FontWeight.w600),
                      iconColor: Colors.white,
                      collapsedIconColor: Colors.white70,
                      children: [
                        for (final t in snap.data![k]!)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Label(t, size: 12, weight: FontWeight.w400),
                          ),
                      ],
                    ),
                ],
              ),
            );
          },
        );
      default:
        return _text('$kAppName\nVersion $kVersion\n\n'
            'An offline platformer inspired by Romeo and Juliet. '
            'No permissions. No internet. No ads.\n\n'
            'Developer: $kDeveloperName');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Column(
              children: [
                Row(
                  children: [
                    GlassButton(
                      width: 48,
                      height: 48,
                      radius: 16,
                      onTap: () => Navigator.of(context).pop(),
                      child: const Icon(Icons.arrow_back, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    const Label('About & Legal',
                        size: 22, weight: FontWeight.w700),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 44,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _tabs.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) => GlassButton(
                      width: 100,
                      height: 44,
                      radius: 16,
                      tint: i == _tab ? kPink : kBlue,
                      onTap: () => setState(() => _tab = i),
                      child: Label(_tabs[i],
                          size: 14,
                          weight: i == _tab ? FontWeight.w700 : FontWeight.w500),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: SizedBox(
                    width: double.infinity,
                    child: GlassPanel(child: _body()),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
