// Pure Dart game logic (no Flutter imports) so it can be unit-tested.
import 'dart:math';

const int kRows = 12;
const double kPlayerW = 0.6;
const double kPlayerH = 0.9;
const int kLevelCount = 7;
const double kSpeed = 6.0;
const double kGravity = 38.0;
const double kJump = 14.0;

const List<String> kLevelNames = [
  'Verona Streets',
  'Capulet Garden',
  'Moonlit Wall',
  'Market Square',
  "Friar's Path",
  'Crypt Road',
  'The Balcony',
];

class Rose {
  final double x;
  final double y;
  bool taken = false;
  Rose(this.x, this.y);
}

class Enemy {
  static const double w = 0.8;
  static const double h = 0.8;
  double x;
  final double y;
  double vx;
  final double minX;
  final double maxX;
  bool alive = true;
  Enemy(this.x, this.y, this.minX, this.maxX, double speed) : vx = speed;
}

/// A level is a list of ground-top rows per column (-1 = pit),
/// fire columns, enemy patrols and rose positions.
class Level {
  final int index;
  final List<int> tops;
  final Set<int> fires;
  final List<List<int>> patrols; // [minCol, maxCol, groundTop]
  final List<List<double>> roses; // [x, y] centre in tiles

  Level(this.index, this.tops, this.fires, this.patrols, this.roses);

  int get width => tops.length;
  String get name => kLevelNames[index];
  double get goalX => width - 4.0;
  double get startX => 2.0;
  double get startY => tops[2] - kPlayerH - 0.001;

  bool solid(int cx, int cy) {
    if (cx < 0 || cx >= width) return true;
    if (cy < 0 || cy >= kRows + 4) return false;
    final t = tops[cx];
    return t >= 0 && cy >= t;
  }

  bool fireAt(int cx) => cx >= 0 && cx < width && fires.contains(cx);

  /// True if standing at column [cx] is a good checkpoint (flat, no hazard).
  bool safeAt(int cx) {
    if (cx < 2 || cx + 3 >= width) return false;
    final t = tops[cx];
    for (var i = cx - 2; i <= cx + 3; i++) {
      if (tops[i] != t || fires.contains(i)) return false;
    }
    for (final p in patrols) {
      if (cx >= p[0] - 3 && cx <= p[1] + 3) return false;
    }
    return true;
  }

  static Level generate(int index) {
    final r = Random(1000 + index * 7919);
    var top = 8;
    final tops = <int>[];
    final fires = <int>{};
    final patrols = <List<int>>[];
    final roses = <List<double>>[];

    void flat(int n, {bool rose = true}) {
      final s = tops.length;
      for (var i = 0; i < n; i++) {
        tops.add(top);
      }
      if (rose && n >= 4 && r.nextInt(10) < 7) {
        final high = r.nextBool();
        roses.add([s + n / 2.0, top - (high ? 1.8 : 0.6)]);
      }
    }

    flat(8, rose: false);
    final segs = 10 + index * 3;
    final maxGap = index < 2 ? 2 : 3;
    for (var s = 0; s < segs; s++) {
      switch (r.nextInt(6)) {
        case 0:
        case 1:
          {
            final g = 2 + r.nextInt(maxGap - 1);
            final gs = tops.length;
            for (var i = 0; i < g; i++) {
              tops.add(-1);
            }
            roses.add([gs + g / 2.0, top - 2.0]);
            flat(4 + r.nextInt(3));
          }
        case 2:
          {
            if (top > 6 && (top >= 9 || r.nextBool())) {
              top--;
            } else if (top < 9) {
              top++;
            }
            flat(4 + r.nextInt(3));
          }
        case 3:
          {
            flat(3, rose: false);
            final f = 1 + r.nextInt(2);
            for (var i = 0; i < f; i++) {
              fires.add(tops.length);
              tops.add(top);
            }
            flat(3, rose: false);
          }
        case 4:
          {
            final st = tops.length;
            flat(9, rose: false);
            patrols.add([st + 2, st + 7, top]);
          }
        default:
          {
            flat(5 + r.nextInt(3));
          }
      }
    }
    flat(9, rose: false);
    return Level(index, tops, fires, patrols, roses);
  }
}

enum GameState { playing, dying, complete, gameOver }

class Input {
  bool left = false;
  bool right = false;
  bool jump = false;
}

class World {
  final Level level;
  final Input input = Input();
  final List<Rose> roses = [];
  final List<Enemy> enemies = [];

  double x = 0;
  double y = 0;
  double vx = 0;
  double vy = 0;
  bool onGround = false;
  bool facingRight = true;
  double coyote = 0;
  double jumpBuf = 0;
  double invuln = 0;
  double deathTimer = 0;
  double time = 0;
  int lives;
  int score = 0;
  GameState state = GameState.playing;

  bool _prevJump = false;
  double _checkX = 2.0;
  double _checkY = 0;

  World(this.level, {this.lives = 3}) {
    for (final r in level.roses) {
      roses.add(Rose(r[0], r[1]));
    }
    for (final p in level.patrols) {
      enemies.add(Enemy(p[0].toDouble(), p[2] - Enemy.h, p[0].toDouble(),
          p[1].toDouble(), 1.6));
    }
    _checkX = level.startX;
    _checkY = level.startY;
    _respawn();
  }

  int get rosesTaken => roses.where((r) => r.taken).length;

  void _respawn() {
    x = _checkX;
    y = _checkY;
    vx = 0;
    vy = 0;
    onGround = false;
    invuln = 1.5;
  }

  void _die() {
    if (state != GameState.playing) return;
    lives--;
    state = GameState.dying;
    deathTimer = 0.9;
    vx = 0;
    vy = -8;
  }

  void update(double dtRaw) {
    final dt = dtRaw.clamp(0.0, 1 / 30).toDouble();
    time += dt;
    if (state == GameState.complete || state == GameState.gameOver) return;
    _updateEnemies(dt);
    if (state == GameState.dying) {
      deathTimer -= dt;
      vy += kGravity * 0.8 * dt;
      y += vy * dt;
      if (deathTimer <= 0) {
        if (lives <= 0) {
          state = GameState.gameOver;
        } else {
          _respawn();
          state = GameState.playing;
        }
      }
      return;
    }
    if (invuln > 0) invuln -= dt;

    final dir = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    if (dir != 0) facingRight = dir > 0;
    vx = dir * kSpeed;
    vy = min(vy + kGravity * dt, 22.0);

    if (input.jump && !_prevJump) jumpBuf = 0.12;
    _prevJump = input.jump;
    jumpBuf = max(0.0, jumpBuf - dt);
    coyote = onGround ? 0.1 : max(0.0, coyote - dt);
    if (jumpBuf > 0 && coyote > 0) {
      vy = -kJump;
      jumpBuf = 0;
      coyote = 0;
      onGround = false;
    }
    if (!input.jump && vy < -5) vy = -5;

    x += vx * dt;
    _resolveX();
    y += vy * dt;
    onGround = false;
    _resolveY();

    if (onGround && x > _checkX + 4 && level.safeAt(x.floor())) {
      _checkX = x.floor() + 0.2;
      _checkY = y;
    }
    if (y > kRows + 1.5) {
      _die();
      return;
    }
    _hazards();
    if (state != GameState.playing) return;
    _collect();
    if (x + kPlayerW >= level.goalX) {
      state = GameState.complete;
      score += 100 + lives * 25;
    }
  }

  void _resolveX() {
    if (x < 0) x = 0;
    if (x + kPlayerW > level.width) x = level.width - kPlayerW;
    final y0 = y.floor();
    final y1 = (y + kPlayerH - 1e-4).floor();
    final x0 = x.floor();
    final x1 = (x + kPlayerW).floor();
    for (var cy = y0; cy <= y1; cy++) {
      for (var cx = x0; cx <= x1; cx++) {
        if (level.solid(cx, cy)) {
          if (vx > 0) {
            x = cx - kPlayerW - 1e-4;
          } else if (vx < 0) {
            x = cx + 1 + 1e-4;
          }
          vx = 0;
          return;
        }
      }
    }
  }

  void _resolveY() {
    final x0 = (x + 1e-4).floor();
    final x1 = (x + kPlayerW - 1e-4).floor();
    final y0 = y.floor();
    final y1 = (y + kPlayerH - 1e-4).floor();
    for (var cy = y0; cy <= y1; cy++) {
      for (var cx = x0; cx <= x1; cx++) {
        if (level.solid(cx, cy)) {
          if (vy > 0) {
            y = cy - kPlayerH - 1e-4;
            onGround = true;
          } else if (vy < 0) {
            y = cy + 1 + 1e-4;
          }
          vy = 0;
          return;
        }
      }
    }
  }

  void _updateEnemies(double dt) {
    for (final e in enemies) {
      if (!e.alive) continue;
      e.x += e.vx * dt;
      if (e.x < e.minX) {
        e.x = e.minX;
        e.vx = -e.vx;
      } else if (e.x + Enemy.w > e.maxX) {
        e.x = e.maxX - Enemy.w;
        e.vx = -e.vx;
      }
    }
  }

  bool _overlap(double ax, double ay, double aw, double ah, double bx,
      double by, double bw, double bh) {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
  }

  void _hazards() {
    if (invuln <= 0) {
      for (var cx = x.floor(); cx <= (x + kPlayerW).floor(); cx++) {
        if (level.fireAt(cx)) {
          final t = level.tops[cx];
          if (_overlap(x, y, kPlayerW, kPlayerH, cx + 0.2, t - 0.7, 0.6, 0.7)) {
            _die();
            return;
          }
        }
      }
    }
    for (final e in enemies) {
      if (!e.alive) continue;
      if (_overlap(x, y, kPlayerW, kPlayerH, e.x, e.y, Enemy.w, Enemy.h)) {
        if (vy > 0 && (y + kPlayerH) < e.y + 0.55) {
          e.alive = false;
          vy = -9;
          score += 50;
        } else if (invuln <= 0) {
          _die();
          return;
        }
      }
    }
  }

  void _collect() {
    for (final r in roses) {
      if (r.taken) continue;
      if (_overlap(x, y, kPlayerW, kPlayerH, r.x - 0.3, r.y - 0.3, 0.6, 0.6)) {
        r.taken = true;
        score += 10;
      }
    }
  }
}
