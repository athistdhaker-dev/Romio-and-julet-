# Star Crossed

Offline side-scrolling platformer inspired by Shakespeare's *Romeo and Juliet*
(public domain). Guide Romeo through 7 procedurally laid-out levels: collect
roses, jump over fire and pits, stomp guards, and reach Juliet.
All art is drawn in code. No assets, no permissions, no internet, no ads,
zero third-party packages.

- Android phones only (landscape gameplay, touch controls)
- Flutter / Dart 3, applicationId `com.maraj.star_crossed`
- Liquid-glass UI (one blurred panel per screen, blur off on low-end devices)

## Layout

- `lib/engine.dart` / `lib/progress.dart` - pure Dart game logic and save data (unit-tested)
- `lib/painter.dart` - game rendering (CustomPainter)
- `lib/mobile.dart` - Home, Level select, Game screens
- `lib/glass.dart`, `lib/ui.dart` - glass widgets and shared UI
- `lib/pages.dart`, `lib/legal.dart` - About & Legal (fill placeholders in `legal.dart`!)
- `lib/core.dart` - device info (low-end detection) and local save
- `tools/patch_manifest.py` - run by CI after `flutter create`
- `tools/star_crossed-sideload.jks` - PUBLIC sideload key (see below)

## Build

Push the zip (repo root) and `.github/workflows/build-apk.yml`; GitHub Actions
builds and signs 4 APKs (arm64-v8a, armeabi-v7a, x86_64, universal) and
publishes them under Releases.

## Signing

The bundled sideload key is public: anyone can sign an update with it. It keeps
the signature stable between builds so updates install over each other. For a
store release, add repository secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
`KEY_ALIAS` and the workflow will use your private key instead.
(Sideload key: alias `sideload`, password `sideload`.)
