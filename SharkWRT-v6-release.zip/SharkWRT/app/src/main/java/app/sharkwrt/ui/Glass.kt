package app.sharkwrt.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.sharkwrt.ui.theme.Surface
import app.sharkwrt.ui.theme.Wrt

// Every card in the app is built here, so the five styles differ in one place:
//  Glass    – translucent fill, soft sheen, hairline rim (Orbit, Aurora)
//  Brackets – glass plus a glowing accent tracing two opposite corners (Abyss)
//  Flat     – solid fill, thin outline, no sheen (Command Deck)
//  Brutal   – solid fill, thick ink outline and a hard offset shadow (Bold Paper)

fun Modifier.glassBg(shape: Shape, fill: Color = Wrt.BgCard): Modifier = when (Wrt.style.surface) {
    Surface.Flat, Surface.Brutal -> this.background(fill, shape)
    else -> this
        .background(fill, shape)
        .background(
            Brush.linearGradient(listOf(Wrt.GlassSheen, Wrt.GlassSheen.copy(alpha = 0f), Wrt.Accent.copy(alpha = 0.05f))),
            shape,
        )
}

fun Modifier.glassBorder(shape: Shape, width: Dp = 1.dp): Modifier = when (Wrt.style.surface) {
    Surface.Brutal -> this
        .drawBehind {
            val o = shape.createOutline(size, layoutDirection, this)
            translate(5.dp.toPx(), 5.dp.toPx()) { drawOutline(o, Wrt.BorderCard.copy(alpha = 1f)) }
        }
        .border(3.dp, Wrt.BorderCard.copy(alpha = 1f), shape)
    Surface.Flat -> this.border(1.dp, Wrt.BorderCard, shape)
    else -> this
        .border(
            width,
            Brush.linearGradient(listOf(Wrt.GlassEdgeHi, Wrt.GlassEdgeLo, Wrt.GlassEdgeHi.copy(alpha = Wrt.GlassEdgeHi.alpha * 0.4f))),
            shape,
        )
        .let { if (Wrt.style.surface == Surface.Brackets) it.hudCorners(shape) else it }
}

private fun Modifier.hudCorners(shape: Shape): Modifier = drawWithContent {
    drawContent()
    if (minOf(size.width, size.height) < 44.dp.toPx()) return@drawWithContent
    val o = shape.createOutline(size, layoutDirection, this)
    val r = ((o as? Outline.Rounded)?.roundRect?.topLeftCornerRadius?.x ?: 0f)
        .coerceIn(6.dp.toPx(), minOf(size.width, size.height) / 2f)
    val t = 14.dp.toPx()
    val w = size.width
    val h = size.height
    val tl = Path().apply {
        moveTo(0f, r + t); lineTo(0f, r)
        arcTo(Rect(0f, 0f, 2 * r, 2 * r), 180f, 90f, false)
        lineTo(r + t, 0f)
    }
    val br = Path().apply {
        moveTo(w, h - r - t); lineTo(w, h - r)
        arcTo(Rect(w - 2 * r, h - 2 * r, w, h), 0f, 90f, false)
        lineTo(w - r - t, h)
    }
    for (path in listOf(tl, br)) {
        drawPath(path, Wrt.Accent.copy(alpha = 0.22f), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
        drawPath(path, Wrt.Accent.copy(alpha = 0.95f), style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
    }
}

fun Modifier.glassPanel(shape: Shape, fill: Color = Wrt.BgCard): Modifier =
    this.glassBorder(shape).glassBg(shape, fill)

/** A full-width bar: translucent fill and a sheen, no corners. */
fun Modifier.glassBar(): Modifier = when (Wrt.style.surface) {
    Surface.Flat, Surface.Brutal -> this.background(Wrt.BgBar)
    else -> this
        .background(Wrt.BgBar)
        .background(Brush.verticalGradient(listOf(Wrt.GlassSheen, Wrt.GlassSheen.copy(alpha = 0f))))
}
