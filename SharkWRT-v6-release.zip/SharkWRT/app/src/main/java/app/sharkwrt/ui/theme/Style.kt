package app.sharkwrt.ui.theme

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** How the five tabs are reached. */
enum class NavKind { Dock, PillBar, Rail, Radial, Drawer }

/** How a card is built: glass, glass with glowing corners, flat outlined, or hard-shadowed. */
enum class Surface { Glass, Brackets, Flat, Brutal }

/** What is painted behind everything. */
enum class Backdrop { Grid, Pastel, Scan, Blooms, Flat }

/**
 * The five complete looks. A style decides the palette, the fonts, how round things are, how
 * cards are made, how you move between tabs and how the home screen's speed card is drawn.
 * Light / dark mode and the accent colour sit on top of it.
 */
enum class UiStyle(
    val id: String,
    val label: String,
    val blurb: String,
    val nav: NavKind,
    val surface: Surface,
    val backdrop: Backdrop,
    /** Multiplies every corner radius in the app. 0 is square. */
    val radius: Float,
    val ring: Boolean,
    val round: Boolean,
    val defaultAccent: String,
    val labelPrefix: String,
    val defaultDark: Boolean,
) {
    Abyss("abyss", "Abyss HUD", "Neon sci-fi glass, floating dock", NavKind.Dock, Surface.Brackets, Backdrop.Grid, 0.8f, false, false, "cyan", "", true),
    Aurora("aurora", "Aurora Glass", "Light liquid glass, pill tab bar", NavKind.PillBar, Surface.Glass, Backdrop.Pastel, 1.1f, false, true, "violet", "", false),
    Deck("deck", "Command Deck", "Terminal look, side rail", NavKind.Rail, Surface.Flat, Backdrop.Scan, 0f, false, false, "solar", "┤ ", true),
    Orbit("orbit", "Orbit", "Radial menu, ring gauge", NavKind.Radial, Surface.Glass, Backdrop.Blooms, 1f, true, true, "orbit", "", true),
    Paper("paper", "Bold Paper", "Hard shadows, drawer menu", NavKind.Drawer, Surface.Brutal, Backdrop.Flat, 0f, false, false, "rose", "", false);

    companion object {
        fun byId(id: String?): UiStyle = entries.firstOrNull { it.id == id } ?: Orbit
    }

    val sansFamily: FontFamily
        get() = when (this) {
            Abyss -> AbyssSans
            Aurora -> AuroraSans
            Deck -> DeckMono
            Orbit, Paper -> GroteskSans
        }
    val displayFamily: FontFamily
        get() = when (this) {
            Abyss -> AbyssDisplay
            Aurora -> AuroraDisplay
            Deck -> DeckMono
            Orbit -> SoraDisplay
            Paper -> ArchivoDisplay
        }
    val monoFamily: FontFamily get() = if (this == Deck) DeckMono else MonoFamily

    /** Rajdhani and JetBrains Mono run small next to the others. */
    val sansScale: Float get() = when (this) { Abyss -> 1.1f; Deck -> 0.94f; else -> 1f }
}

/** The current style's helpers, read like the colours: they follow the user's choice. */
val WrtStyle: UiStyle get() = ThemeStore.style

fun WrtR(n: Float): Dp = (n * ThemeStore.style.radius).dp
fun WrtPill(): Shape = if (ThemeStore.style.radius <= 0f) RectangleShape else RoundedCornerShape(50)
fun WrtIconShape(): Shape = when {
    ThemeStore.style.round -> CircleShape
    ThemeStore.style.radius > 0f -> RoundedCornerShape((12 * ThemeStore.style.radius).dp)
    else -> RectangleShape
}
