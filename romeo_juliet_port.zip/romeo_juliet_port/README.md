# Romeo and Juliet - Android port (personal use)

J2ME game (R&J, 240x320) packaged as a standalone Android app. No emulator UI: the app opens straight into the game.

## Build
1. New GitHub repo -> put `.github/workflows/build-apk.yml` in it.
2. Upload `romeo_juliet_port.zip` to the repo root. The build starts by itself.
3. Download APKs from the Releases page (or the workflow artifact).

Output names: `RomeoAndJuliet-Mobile-<abi>-build<N>.apk` (arm64-v8a, armeabi-v7a, x86_64, universal). Use arm64-v8a on most phones, universal if unsure.

## Contents
- `game/game.jar` original game, `game/MANIFEST.MF` cleaned MIDlet manifest (name without `&`)
- `tools/prepare_port.py` bundles the game into the J2ME Loader "midlet" build
- `tools/rj-sideload.jks` fixed signing key, so new builds install over old ones

Engine: J2ME Loader (Apache-2.0), pinned to one commit in the workflow.
