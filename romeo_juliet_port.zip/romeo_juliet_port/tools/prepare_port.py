"""Usage: python3 prepare_port.py <J2ME-Loader checkout> <game dir> <keystore> <store_pass> <alias>

Turns a plain J2ME-Loader checkout into a standalone Android port of game/game.jar
using J2ME-Loader's own "midlet" flavor (no emulator UI, the app opens straight into the game).
Every patch asserts that its anchor text was found, so the build fails loudly instead of silently
producing a broken APK if upstream ever changes.
"""
import pathlib
import re
import shutil
import sys
import zipfile

loader = pathlib.Path(sys.argv[1]).resolve()
game = pathlib.Path(sys.argv[2]).resolve()
ks_file, ks_pass, ks_alias = sys.argv[3], sys.argv[4], sys.argv[5]

app = loader / "app"
jar_path = game / "game.jar"
manifest_path = game / "MANIFEST.MF"
assert jar_path.exists(), f"{jar_path} not found"
assert manifest_path.exists(), f"{manifest_path} not found"

# 1) Split the JAR: classes -> libs/game-classes.jar, everything else -> midlet resources.
#    (Keeping them apart avoids "duplicate resource" errors when Gradle merges Java resources.)
res_dir = app / "src" / "midlet" / "resources"
libs_dir = app / "libs"
libs_dir.mkdir(exist_ok=True)

for old in (app / "src" / "midlet" / "java" / "com", res_dir / "com"):
    if old.exists():
        shutil.rmtree(old)  # drop the upstream HelloMidlet sample

n_cls = n_res = 0
with zipfile.ZipFile(jar_path) as zin, zipfile.ZipFile(libs_dir / "game-classes.jar", "w", zipfile.ZIP_DEFLATED) as zcls:
    for info in zin.infolist():
        name = info.filename
        if name.endswith("/") or name.startswith("META-INF/"):
            continue
        data = zin.read(name)
        if name.endswith(".class"):
            zcls.writestr(name, data)
            n_cls += 1
        elif name.lower().endswith(".ini"):
            continue  # ad/info stub shipped by the original uploader, not used by the game
        else:
            out = res_dir / name
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(data)
            n_res += 1
assert n_cls > 0, "no .class files found in game.jar"
print(f"classes: {n_cls}, resources: {n_res}")

# 2) MIDlet manifest (name sanitised: '&' would break the applicationId / string resource)
meta = res_dir / "MIDLET-META-INF"
meta.mkdir(parents=True, exist_ok=True)
shutil.copy(manifest_path, meta / "MANIFEST.MF")

# 3) app/build.gradle patches
bg = app / "build.gradle"
s = bg.read_text(encoding="utf-8")

anchor = "implementation project(':dexlib')"
assert anchor in s, "dexlib anchor missing in app/build.gradle"
s = s.replace(anchor, anchor + "\n    midletImplementation files('libs/game-classes.jar')", 1)

anchor = "vectorDrawables.useSupportLibrary = true"
assert anchor in s, "defaultConfig anchor missing in app/build.gradle"
s = s.replace(
    anchor,
    anchor
    + "\n        if (project.hasProperty('abis')) {"
    + "\n            ndk { abiFilters.addAll(project.property('abis').toString().split(',') as List) }"
    + "\n        }",
    1,
)
bg.write_text(s, encoding="utf-8")

# 4) Keep the old CLDC game code as-is (no renaming of classes that load resources by path)
pro = app / "proguard-midlet.pro"
pro.write_text(
    pro.read_text(encoding="utf-8")
    + "\n-dontobfuscate\n-dontoptimize\n-dontwarn **\n-keep public class * extends javax.microedition.midlet.MIDlet { *; }\n",
    encoding="utf-8",
)

# 5) Fixed signing key
props = loader / "app" / "keystore.properties"
props.write_text(
    f"keyAlias={ks_alias}\nkeyPassword={ks_pass}\nstoreFile={ks_file}\nstorePassword={ks_pass}\n",
    encoding="utf-8",
)
# upstream reads it from rootProject too
shutil.copy(props, loader / "keystore.properties")
print("port prepared")
